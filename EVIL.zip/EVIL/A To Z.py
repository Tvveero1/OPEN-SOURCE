#Sc Make By ASRAFUL ISLAM HASAN
#KgHasan

import os
import time
#_____Logo__[1]___#
fuckbby =(""" Ayha Ki Korlam """)
#_____Logo__[2]___#
def xudarbedi():
	print(" Pokki Mari ")
#______System Clear______#
def pokkimari():
	os.system('clear')
def soromkore():
	print(50*'_')
pokkimari()
#soromkore()
#xudarbedi()
#soromkore()
#_______Main Menu_____#
def sumaiyaxan():
	print(fuckbby)
	xudarbedi()
	soromkore()
	print('[01] Random Clone V1')
	print('[02] Random Clone V2')
	print('[03] Random Clone V3')
	print('[04] Random Clone V4')
	print('[05] Random Clone V5')
	print('[06] Hannan File Make')
	print('[07] Aking File Make')
	print('[08] Drivice Bit Chake')
	print('[09] Auto Dump File')
	print('[10] File Clone')
	print('[11] Auto Share')
	print('[12] Auto Cookie')
	print('[13] Contact Admin')
	print('[14] Join My Group')
	print('[00] Exit')
	soromkore()
	ornita=input('Choice: ')
	if ornita in ['1', '01']:
		#_____Command Laganor Example System____#
		#os.system('git clone https://github.com/KgHasan/HASAN-FIRE')
		#os.system('cd HASAN-FIRE')
		#os.system('python FIRE.py')
		#rm -rf Hasan_Firev3
#git clone https://github.com/KgHasan/Hasan_Firev3
#cd Hasan_Firev3
#python Randomv3.py
		os.system('rm -rf Hasan_Firev3')
		os.system('git clone https://github.com/KgHasan/Hasan_Firev3')
		os.system('cd Hasan_Firev3')
		os.system('python Randomv3.py')
		#sumaiyaxan()
	elif ornita in ['2', '02']:
		os.system('')
		os.system('')
		os.system('')
		#sumaiyaxan()
	elif ornita in ['3', '03']:
		os.system('')
		os.system('')
		os.system('')
		#sumaiyaxan()
	elif ornita in ['4', '04']:
		os.system('')
		os.system('')
		os.system('')
	elif ornita in ['5', '05']:
		os.system('')
		os.system('')
		os.system('')
	elif ornita in ['6', '06']:
		os.system('')
		os.system('')
		os.system('')
	elif ornita in ['7', '07']:
		os.system('')
		os.system('')
		os.system('')
		os.system('')
	elif ornita in ['8', '08']:
		os.system('')
		os.system('')
		os.system('')
	elif ornita in ['9', '09']:
		os.system('')
		os.system('')
		os.system('')
	elif ornita in ['10']:
		os.system('')
		os.system('')
		os.system('')
	elif ornita in ['11']:
		os.system('')
		os.system('')
		os.system('')
	elif ornita in ['12']:
		os.system('')
		os.system('')
		os.system('')
	elif ornita in ['13']:
		os.system('xdg-open https://www.facebook.com/copy.link.erorr404')
		pokkimari()
		sumaiyaxan()
	elif ornita in ['14']:
		os.system('xdg-open https://facebook.com/groups/551365756758487/')
		pokkimari()
		sumaiyaxan()
	elif ornita in ['0']:
		exit()
	else:
		exit() 
		
sumaiyaxan()
	
	
	


