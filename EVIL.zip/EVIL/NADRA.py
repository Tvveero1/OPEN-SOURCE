import requests,re,os
import time
import sys
from os import system
from platform import platform
from time import sleep
import os
puk = platform()[0], platform()[1],  platform()[2], platform()[3], platform()[4], platform()[5], platform()[6]

if puk == ('W', 'i', 'n', 'd', 'o', 'w', 's'):
    delet = 'cls'
    dr = '\\'
else:
    delet = 'clear'
    dr = '/'

os.system(delet)
time.sleep(1)

print("\033[0;31mloading modules...")
time.sleep(0.05)
os.system(delet)
print("lOading modules...")
time.sleep(0.05)
os.system(delet)
print("loAding modules...")
time.sleep(0.1)
os.system(delet)
print("loaDing modules...")
time.sleep(0.1)
os.system(delet)
print("loadIng modules...")
time.sleep(0.1)
os.system(delet)
print("loadiNg modules...")
time.sleep(0.1)
os.system(delet)
print("loadinG modules...")
time.sleep(0.1)
os.system(delet)
print("loading modules...")
time.sleep(0.1)
os.system(delet)
print("loading mOdules...")
time.sleep(0.1)
os.system(delet)
print("loading moDules...")
time.sleep(0.1)
os.system(delet)
print("loading modUles...")
time.sleep(0.1)
os.system(delet)
print("loading moduLes...")
time.sleep(0.1)
os.system(delet)
print("loading modulEs...")
time.sleep(0.1)
os.system(delet)
print("loading moduleS...")
time.sleep(0.1)
os.system(delet)
print("loading modules...")
time.sleep(0.1)
os.system(delet)
print("Loading modules...")
time.sleep(0.1)
os.system(delet)
print("lOading modules...")
time.sleep(0.1)
os.system(delet)
print("loAding modules...")
time.sleep(0.1)
os.system(delet)
print("loaDing modules...")
time.sleep(0.1)
os.system(delet)
print("loadIng modules...")
time.sleep(0.1)
os.system(delet)
print("loadiNg modules...")
time.sleep(0.1)
os.system(delet)
print("loadinG modules...")
time.sleep(0.1)
os.system(delet)
print("loading Modules...")
time.sleep(0.1)
os.system(delet)
print("loading mOdules...")
time.sleep(0.1)
os.system(delet)
print("loading moDules...")
time.sleep(0.1)
os.system(delet)
print("loading modUles...")
time.sleep(0.1)
os.system(delet)
print("loading moduLes...")
time.sleep(0.1)
os.system(delet)
print("loading modulEs...")
time.sleep(0.1)
os.system(delet)
print("loading moduleS...")
time.sleep(0.1)
os.system(delet)
print("loading modules...")
time.sleep(0.1)
os.system(delet)
print("""
█───█
█───█
█─█─█
█████
─█─█
""")
time.sleep(0.1)
os.system(delet)
print("""
█───█──███
█───█──█
█─█─█──███
█████──█
─█─█───███
""")
time.sleep(0.1)
os.system(delet)
print("""
█───█──███──████
█───█──█────█──██
█─█─█──███──████
█████──█────█──██
─█─█───███──████
""")
time.sleep(0.1)
os.system(delet)
print("""
█───█──███──████───█──█
█───█──█────█──██──█──█
█─█─█──███──████───████
█████──█────█──██──█──█
─█─█───███──████───█──█
""")
time.sleep(0.1)
os.system(delet)
print("""
█───█──███──████───█──█──████
█───█──█────█──██──█──█──█──█
█─█─█──███──████───████──████
█████──█────█──██──█──█──█──█
─█─█───███──████───█──█──█──█
""")
time.sleep(0.1)
os.system(delet)
print("""
█───█──███──████───█──█──████──████
█───█──█────█──██──█──█──█──█──█──█
█─█─█──███──████───████──████──█
█████──█────█──██──█──█──█──█──█──█
─█─█───███──████───█──█──█──█──████
""")
time.sleep(0.1)
os.system(delet)
print("""
█───█──███──████───█──█──████──████──█──█
█───█──█────█──██──█──█──█──█──█──█──█─█
█─█─█──███──████───████──████──█─────██
█████──█────█──██──█──█──█──█──█──█──█─█
─█─█───███──████───█──█──█──█──████──█──█
""")
time.sleep(0.3)
os.system(delet)
print("""
████
█──██
████
█──██
████
""")
time.sleep(0.1)
os.system(delet)
print("""
████───██─██
█──██───███
████─────█
█──██────█
████─────█
─────────█
""")
time.sleep(0.1)
os.system(delet)
print("""
█
""")
time.sleep(0.1)
os.system(delet)
print("""

██████╗ ██╗   ██╗     █████╗ 
██╔══██╗╚██╗ ██╔╝    ██╔══██╗
██████╔╝ ╚████╔╝     ███████║
██╔══██╗  ╚██╔╝      ██╔══██║
██████╔╝   ██║       ██║  ██║
╚═════╝    ╚═╝       ╚═╝  ╚═╝
                             
""")
time.sleep(0.1)
os.system(delet)
print("""

██████╗ ██╗   ██╗     █████╗ 
██╔══██╗╚██╗ ██╔╝    ██╔══██╗
██████╔╝ ╚████╔╝     ███████║
██╔══██╗  ╚██╔╝      ██╔══██║
██████╔╝   ██║       ██║  ██║
╚═════╝    ╚═╝       ╚═╝  ╚═╝
                             
""")
time.sleep(0.1)
os.system(delet)
print("""

██████╗ ██╗   ██╗     █████╗ ██╗  ██╗███╗   ███╗
██╔══██╗╚██╗ ██╔╝    ██╔══██╗██║  ██║████╗ ████║
██████╔╝ ╚████╔╝     ███████║███████║██╔████╔██║
██╔══██╗  ╚██╔╝      ██╔══██║██╔══██║██║╚██╔╝██║
██████╔╝   ██║       ██║  ██║██║  ██║██║ ╚═╝ ██║
╚═════╝    ╚═╝       ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝     ╚═╝
                                                
""")
time.sleep(0.1)
os.system(delet)
print("""
██████╗ ██╗   ██╗     █████╗ ██╗  ██╗███╗   ███╗███████╗
██╔══██╗╚██╗ ██╔╝    ██╔══██╗██║  ██║████╗ ████║██╔════╝
██████╔╝ ╚████╔╝     ███████║███████║██╔████╔██║█████╗  
██╔══██╗  ╚██╔╝      ██╔══██║██╔══██║██║╚██╔╝██║██╔══╝  
██████╔╝   ██║       ██║  ██║██║  ██║██║ ╚═╝ ██║███████╗
╚═════╝    ╚═╝       ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝     ╚═╝╚══════╝
                                                        
""")
time.sleep(1)
os.system(delet)
print("""
██████╗ ██╗   ██╗     █████╗ ██╗  ██╗███╗   ███╗███████╗██████╗ 
██╔══██╗╚██╗ ██╔╝    ██╔══██╗██║  ██║████╗ ████║██╔════╝██╔══██╗
██████╔╝ ╚████╔╝     ███████║███████║██╔████╔██║█████╗  ██║  ██║
██╔══██╗  ╚██╔╝      ██╔══██║██╔══██║██║╚██╔╝██║██╔══╝  ██║  ██║
██████╔╝   ██║       ██║  ██║██║  ██║██║ ╚═╝ ██║███████╗██████╔╝
╚═════╝    ╚═╝       ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝     ╚═╝╚══════╝╚═════╝ 
                                                                
print('\033[0;32mWELCOME TO MY TOOL CCTV-R / ONLINE CCTVR HACKED')

\033[0;31m  .,-:::::   .,-::::::::::::::::::::      .::. :::::::..
\033[0;32m,;;;'````' ,;;;'````';;;;;;;;''''';;,   ,;;;'  ;;;;``;;;;
\033[0;33m[[[        [[[            [[      \[[  .[[/     [[[,/[[['
\033[0;34m$$$        $$$            $$       Y$c.$$" cccc $$$$$$$
\033[0;35m`88bo,__,o,`88bo,__,o,    88,       Y88P        888b "88bo,
\033[0;36m  "YUMMMMMP" "YUMMMMMP"   MMM        MP         MMMM   "W"

                \033[0;32mCreated By: \033[0;33m𝐀𝐡𝐦𝐞𝐝🔰

                \033[0;31m------>Version 1.2<------
""")
time.sleep(4)
os.system(delet)
os.system("xdg-open \'https://www.facebook.com/white.hat.hacker.Rihan\'")
print("""\033[0;35m

\033[0;31m  .,-:::::   .,-::::::::::::::::::::      .::. :::::::..
\033[0;32m,;;;'````' ,;;;'````';;;;;;;;''''';;,   ,;;;'  ;;;;``;;;;
\033[0;33m[[[        [[[            [[      \[[  .[[/     [[[,/[[['
\033[0;34m$$$        $$$            $$       Y$c.$$" cccc $$$$$$$
\033[0;35m`88bo,__,o,`88bo,__,o,    88,       Y88P        888b "88bo,
\033[0;36m  "YUMMMMMP" "YUMMMMMP"   MMM        MP         MMMM   "W"

                \033[0;32mCreated By: \033[0;33m𝐑𝐢𝐡𝐚𝐧 𝐀𝐡𝐦𝐞𝐝
                \033[0;31m------>Version 1.2<------
""")
print("\033[0;32mWelcome to 🟢Online CCTV Camera Hack!")
print("\033[0;34mPlease select country for Hack :")
print("""\033[0;35m
1.\033[0;34m Russian Federation
2.\033[0;34m United States
3.\033[0;34m Japan
4.\033[0;34m Canada
5.\033[0;34m New Zealand
6.\033[0;34m Ukraine
7.\033[0;34m Germany
8.\033[0;34m Austria
9.\033[0;34m Spain
10.\033[0;34m Turkey
11.\033[0;34m Hong Kong
12.\033[0;34m Greece
13.\033[0;34m Portugal
14.\033[0;34m INDIA
15.\033[0;34m PAKISTAN
""")
num = int(input("\033[0;36mcountry : "))
if num == 1:
        print("\n")
        os.system(delet)
        try:
            headers = {'User-Agent': 'Mozilla/5.0 (X11; Linux i686; rv:68.0) Gecko/20100101 Firefox/68.0'}
            for page in range (0,82):

                url = ("http://www.insecam.org/en/bycountry/RU/?page="+str(page))

                res = requests.get(url, headers=headers)
                findip = re.findall('http://\d+.\d+.\d+.\d+:\d+', res.text)
                count = 0

                for _ in findip:
                     hasil = findip[count]

                     print ("\033[1;37m",hasil)

                     f = open('logs.txt' , 'a')
                     f.write(f'{findip}' + '\n')
                     f.close()

                     count += 1
        except:
            print ("")
if num == 2:
        print("\n")
        try:
            headers = {'User-Agent': 'Mozilla/5.0 (X11; Linux i686; rv:68.0) Gecko/20100101 Firefox/68.0'}
            for page in range (0,720):

                url = ("http://www.insecam.org/en/bycountry/US/?page="+str(page))

                res = requests.get(url, headers=headers)
                findip = re.findall('http://\d+.\d+.\d+.\d+:\d+', res.text)
                count = 0

                for _ in findip:
                     hasil = findip[count]

                     print ("\033[1;37m",hasil)
                     f = open('logs.txt' , 'a')
                     f.write(f'{findip}' + '\n')
                     f.close()

                     count += 1
        except:
            print (" ")
if num == 3:
        print("\n")
        try:
            headers = {'User-Agent': 'Mozilla/5.0 (X11; Linux i686; rv:68.0) Gecko/20100101 Firefox/68.0'}
            for page in range (0,232):

                url = ("http://www.insecam.org/en/bycountry/JP/?page="+str(page))

                res = requests.get(url, headers=headers)
                findip = re.findall('http://\d+.\d+.\d+.\d+:\d+', res.text)
                count = 0

                for _ in findip:
                     hasil = findip[count]

                     print ("\033[1;37m",hasil)
                     f = open('logs.txt' , 'a')
                     f.write(f'{findip}' + '\n')
                     f.close()

                     count += 1
        except:
            print (" ")
if num == 4:
        print("\n")
        try:
            headers = {'User-Agent': 'Mozilla/5.0 (X11; Linux i686; rv:68.0) Gecko/20100101 Firefox/68.0'}
            for page in range (0,38):

                url = ("http://www.insecam.org/en/bycountry/CA/?page="+str(page))

                res = requests.get(url, headers=headers)
                findip = re.findall('http://\d+.\d+.\d+.\d+:\d+', res.text)
                count = 0

                for _ in findip:
                     hasil = findip[count]

                     print ("\033[1;37m",hasil)
                     f = open('logs.txt' , 'a')
                     f.write(f'{findip}' + '\n')
                     f.close()

                     count += 1
        except:
            print (" ")
if num == 5:
        print("\n")
        try:
            headers = {'User-Agent': 'Mozilla/5.0 (X11; Linux i686; rv:68.0) Gecko/20100101 Firefox/68.0'}
            for page in range (0,5):

                url = ("http://www.insecam.org/en/bycountry/NZ/?page="+str(page))

                res = requests.get(url, headers=headers)
                findip = re.findall('http://\d+.\d+.\d+.\d+:\d+', res.text)
                count = 0

                for _ in findip:
                     hasil = findip[count]

                     print ("\033[1;37m",hasil)
                     f = open('logs.txt' , 'a')
                     f.write(f'{findip}' + '\n')
                     f.close()

                     count += 1
        except:
            print (" ")
if num == 6:
        print("\n")
        try:
            headers = {'User-Agent': 'Mozilla/5.0 (X11; Linux i686; rv:68.0) Gecko/20100101 Firefox/68.0'}
            for page in range (0,2):

                url = ("http://www.insecam.org/en/bycountry/UK/?page="+str(page))

                res = requests.get(url, headers=headers)
                findip = re.findall('http://\d+.\d+.\d+.\d+:\d+', res.text)
                count = 0

                for _ in findip:
                     hasil = findip[count]

                     print ("\033[1;37m",hasil)
                     f = open('logs.txt' , 'a')
                     f.write(f'{findip}' + '\n')
                     f.close()

                     count += 1
        except:
            print (" ")
if num == 7:
        print("\n")
        try:
            headers = {'User-Agent': 'Mozilla/5.0 (X11; Linux i686; rv:68.0) Gecko/20100101 Firefox/68.0'}
            for page in range (0,107):

                url = ("http://www.insecam.org/en/bycountry/DE/?page="+str(page))

                res = requests.get(url, headers=headers)
                findip = re.findall('http://\d+.\d+.\d+.\d+:\d+', res.text)
                count = 0

                for _ in findip:
                     hasil = findip[count]

                     print ("\033[1;31m",hasil)
                     f = open('logs.txt' , 'a')
                     f.write(f'{findip}' + '\n')
                     f.close()

                     count += 1
        except:
            print (" ")
if num == 8:
        print("\n")
        try:
            headers = {'User-Agent': 'Mozilla/5.0 (X11; Linux i686; rv:68.0) Gecko/20100101 Firefox/68.0'}
            for page in range (0,48):

                url = ("http://www.insecam.org/en/bycountry/AT/?page="+str(page))

                res = requests.get(url, headers=headers)
                findip = re.findall('http://\d+.\d+.\d+.\d+:\d+', res.text)
                count = 0

                for _ in findip:
                     hasil = findip[count]

                     print ("\033[1;31m",hasil)
                     f = open('logs.txt' , 'a')
                     f.write(f'{findip}' + '\n')
                     f.close()
                     count += 1
        except:
            print (" ")
if num == 9:
        print("\n")
        try:
            headers = {'User-Agent': 'Mozilla/5.0 (X11; Linux i686; rv:68.0) Gecko/20100101 Firefox/68.0'}
            for page in range (0,39):

                url = ("http://www.insecam.org/en/bycountry/ES/?page="+str(page))

                res = requests.get(url, headers=headers)
                findip = re.findall('http://\d+.\d+.\d+.\d+:\d+', res.text)
                count = 0

                for _ in findip:
                     hasil = findip[count]

                     print ("\033[1;31m",hasil)
                     f = open('logs.txt' , 'a')
                     f.write(f'{findip}' + '\n')
                     f.close()

                     count += 1
        except:
            print (" ")
if num == 10:
        print("\n")
        try:
            headers = {'User-Agent': 'Mozilla/5.0 (X11; Linux i686; rv:68.0) Gecko/20100101 Firefox/68.0'}
            for page in range (0,54):

                url = ("http://www.insecam.org/en/bycountry/TR/?page="+str(page))

                res = requests.get(url, headers=headers)
                findip = re.findall('http://\d+.\d+.\d+.\d+:\d+', res.text)
                count = 0

                for _ in findip:
                     hasil = findip[count]

                     print ("\033[1;31m",hasil)
                     f = open('logs.txt' , 'a')
                     f.write(f'{findip}' + '\n')
                     f.close()

                     count += 1
        except:
            print (" ")
if num == 11:
        print("\n")
        try:
            headers = {'User-Agent': 'Mozilla/5.0 (X11; Linux i686; rv:68.0) Gecko/20100101 Firefox/68.0'}
            for page in range (0,7):

                url = ("http://www.insecam.org/en/bycountry/HK/?page="+str(page))

                res = requests.get(url, headers=headers)
                findip = re.findall('http://\d+.\d+.\d+.\d+:\d+', res.text)
                count = 0

                for _ in findip:
                     hasil = findip[count]

                     print ("\033[1;31m",hasil)
                     f = open('logs.txt' , 'a')
                     f.write(f'{findip}' + '\n')
                     f.close()

                     count += 1
        except:
            print (" ")
if num == 12:
        print("\n")
        try:
            headers = {'User-Agent': 'Mozilla/5.0 (X11; Linux i686; rv:68.0) Gecko/20100101 Firefox/68.0'}
            for page in range (0,8):

                url = ("http://www.insecam.org/en/bycountry/BANGLA/?page="+str(page))

                res = requests.get(url, headers=headers)
                findip = re.findall('http://\d+.\d+.\d+.\d+:\d+', res.text)
                count = 0

                for _ in findip:
                     hasil = findip[count]

                     print ("\033[1;31m",hasil)
                     f = open('logs.txt' , 'a')
                     f.write(f'{findip}' + '\n')
                     f.close()

                     count += 1
        except:
            print (" ")
if num == 13:
        print("\n")
        try:
            headers = {'User-Agent': 'Mozilla/5.0 (X11; Linux i686; rv:68.0) Gecko/20100101 Firefox/68.0'}
            for page in range (0,7):

                url = ("http://www.insecam.org/en/bycountry/IND/?page="+str(page))

                res = requests.get(url, headers=headers)
                findip = re.findall('http://\d+.\d+.\d+.\d+:\d+', res.text)
                count = 0

                for _ in findip:
                     hasil = findip[count]

                     print ("\033[1;31m",hasil)
                     f = open('logs.txt' , 'a')
                     f.write(f'{findip}' + '\n')
                     f.close()

                     count += 1
        except:
            print (" ")
if num == 14:
        print("\n")
        try:
            headers =     'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'Accept-Language': 'en-US,en;q=0.9',
    'Cache-Control': 'max-age=0',
    'Connection': 'keep-alive',
    # 'Cookie': 'JSESSIONID=0000rtjJfP4uDCfcVpsitcByEdr:1ehke5a66; cookiesession1=678B28C75BCDAD80CEB5BD2022373DA8; _ga=GA1.3.1236827295.1712238230; _gid=GA1.3.36815811.1712238230; _gat=1; _ga_Z00ZZ16B1M=GS1.3.1712238231.1.1.1712238293.0.0.0',
    'Sec-Fetch-Dest': 'document',
    'Sec-Fetch-Mode': 'navigate',
    'Sec-Fetch-Site': 'none',
    'Sec-Fetch-User': '?1',
    'Upgrade-Insecure-Requests': '1',

                url = ("http://www.insecam.org/en/bycountry/PAK/?page="+str(page))

                res = requests.get(url, headers=headers)
                findip = re.findall('http://\d+.\d+.\d+.\d+:\d+', res.text)
                count = 0

                for _ in findip:
                     hasil = findip[count]

                     print ("\033[1;31m",hasil)
                     f = open('logs.txt' , 'a')
                     f.write(f'{findip}' + '\n')
                     f.close()

                     count += 1
        except:
            print (" ")
if num == 15:
        print("\n")
        try:
            headers = {'User-Agent': 'Mozilla/5.0 (X11; Linux i686; rv:68.0) Gecko/20100101 Firefox/68.0'}
            for page in range (0,6):

                url = ("http://www.insecam.org/en/bycountry/CO/?page="+str(page))

                res = requests.get(url, headers=headers)
                findip = re.findall('http://\d+.\d+.\d+.\d+:\d+', res.text)
                count = 0

                for _ in findip:
                     hasil = findip[count]

                     print ("\033[1;31m",hasil)
                     f = open('logs.txt' , 'a')
                     f.write(f'{findip}' + '\n')
                     f.close()

                     count += 1
        except:
            print (" ")


print("Готово! Все логи были сохранены в файл logs.txt")
print("""
Subscribe to Online Hacking Channel on YouTube!
https://youtube.com/
--Thanks for using this programm!--

MODYFIED BY JONI AHMED

------Version 10.0------
""")
