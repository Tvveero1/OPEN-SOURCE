import requests,re,os
import time
import sys
from os import system
from platform import platform
from time import sleep
import os
puk = platform()[0], platform()[1],  platform()[2], platform()[3], platform()[4], platform()[5], platform()[6]

if puk == ('W', 'i', 'n', 'd', 'o', 'w', 's'):
    delet = 'cls'
    dr = '\\'
else:
    delet = 'clear'
    dr = '/'

os.system(delet)
time.sleep(1)

print("\033[0;31mloading modules...")
time.sleep(0.05)
os.system(delet)
print("lOading modules...")
time.sleep(0.05)
os.system(delet)
print("loAding modules...")
time.sleep(0.1)
os.system(delet)
print("loaDing modules...")
time.sleep(0.1)
os.system(delet)
print("loadIng modules...")
time.sleep(0.1)
os.system(delet)
print("loadiNg modules...")
time.sleep(0.1)
os.system(delet)
print("loadinG modules...")
time.sleep(0.1)
os.system(delet)
print("loading modules...")
time.sleep(0.1)
os.system(delet)
print("loading mOdules...")
time.sleep(0.1)
os.system(delet)
print("loading moDules...")
time.sleep(0.1)
os.system(delet)
print("loading modUles...")
time.sleep(0.1)
os.system(delet)
print("loading moduLes...")
time.sleep(0.1)
os.system(delet)
print("loading modulEs...")
time.sleep(0.1)
os.system(delet)
print("loading moduleS...")
time.sleep(0.1)
os.system(delet)
print("loading modules...")
time.sleep(0.1)
os.system(delet)
print("Loading modules...")
time.sleep(0.1)
os.system(delet)
print("lOading modules...")
time.sleep(0.1)
os.system(delet)
print("loAding modules...")
time.sleep(0.1)
os.system(delet)
print("loaDing modules...")
time.sleep(0.1)
os.system(delet)
print("loadIng modules...")
time.sleep(0.1)
os.system(delet)
print("loadiNg modules...")
time.sleep(0.1)
os.system(delet)
print("loadinG modules...")
time.sleep(0.1)
os.system(delet)
print("loading Modules...")
time.sleep(0.1)
os.system(delet)
print("loading mOdules...")
time.sleep(0.1)
os.system(delet)
print("loading moDules...")
time.sleep(0.1)
os.system(delet)
print("loading modUles...")
time.sleep(0.1)
os.system(delet)
print("loading moduLes...")
time.sleep(0.1)
os.system(delet)
print("loading modulEs...")
time.sleep(0.1)
os.system(delet)
print("loading moduleS...")
time.sleep(0.1)
os.system(delet)
print("loading modules...")
time.sleep(0.1)
os.system(delet)
print("""
█───█
█───█
█─█─█
█████
─█─█
""")
time.sleep(0.1)
os.system(delet)
print("""
█───█──███
█───█──█
█─█─█──███
█████──█
─█─█───███
""")
time.sleep(0.1)
os.system(delet)
print("""
█───█──███──████
█───█──█────█──██
█─█─█──███──████
█████──█────█──██
─█─█───███──████
""")
time.sleep(0.1)
os.system(delet)
print("""
█───█──███──████───█──█
█───█──█────█──██──█──█
█─█─█──███──████───████
█████──█────█──██──█──█
─█─█───███──████───█──█
""")
time.sleep(0.1)
os.system(delet)
print("""
█───█──███──████───█──█──████
█───█──█────█──██──█──█──█──█
█─█─█──███──████───████──████
█████──█────█──██──█──█──█──█
─█─█───███──████───█──█──█──█
""")
time.sleep(0.1)
os.system(delet)
print("""
█───█──███──████───█──█──████──████
█───█──█────█──██──█──█──█──█──█──█
█─█─█──███──████───████──████──█
█████──█────█──██──█──█──█──█──█──█
─█─█───███──████───█──█──█──█──████
""")
time.sleep(0.1)
os.system(delet)
print("""
█───█──███──████───█──█──████──████──█──█
█───█──█────█──██──█──█──█──█──█──█──█─█
█─█─█──███──████───████──████──█─────██
█████──█────█──██──█──█──█──█──█──█──█─█
─█─█───███──████───█──█──█──█──████──█──█
""")
time.sleep(0.3)
os.system(delet)
print("""
████
█──██
████
█──██
████
""")
time.sleep(0.1)
os.system(delet)
print("""
████───██─██
█──██───███
████─────█
█──██────█
████─────█
─────────█
""")
time.sleep(0.1)
os.system(delet)
print("""
█
""")
time.sleep(0.1)
os.system(delet)
print("""

██████╗ ██╗   ██╗     █████╗ 
██╔══██╗╚██╗ ██╔╝    ██╔══██╗
██████╔╝ ╚████╔╝     ███████║
██╔══██╗  ╚██╔╝      ██╔══██║
██████╔╝   ██║       ██║  ██║
╚═════╝    ╚═╝       ╚═╝  ╚═╝
                             
""")
time.sleep(0.1)
os.system(delet)
print("""

██████╗ ██╗   ██╗     █████╗ 
██╔══██╗╚██╗ ██╔╝    ██╔══██╗
██████╔╝ ╚████╔╝     ███████║
██╔══██╗  ╚██╔╝      ██╔══██║
██████╔╝   ██║       ██║  ██║
╚═════╝    ╚═╝       ╚═╝  ╚═╝
                             
""")
time.sleep(0.1)
os.system(delet)
print("""

██████╗ ██╗   ██╗     █████╗ ██╗  ██╗███╗   ███╗
██╔══██╗╚██╗ ██╔╝    ██╔══██╗██║  ██║████╗ ████║
██████╔╝ ╚████╔╝     ███████║███████║██╔████╔██║
██╔══██╗  ╚██╔╝      ██╔══██║██╔══██║██║╚██╔╝██║
██████╔╝   ██║       ██║  ██║██║  ██║██║ ╚═╝ ██║
╚═════╝    ╚═╝       ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝     ╚═╝
                                                
""")
time.sleep(0.1)
os.system(delet)
print("""
██████╗ ██╗   ██╗     █████╗ ██╗  ██╗███╗   ███╗███████╗
██╔══██╗╚██╗ ██╔╝    ██╔══██╗██║  ██║████╗ ████║██╔════╝
██████╔╝ ╚████╔╝     ███████║███████║██╔████╔██║█████╗  
██╔══██╗  ╚██╔╝      ██╔══██║██╔══██║██║╚██╔╝██║██╔══╝  
██████╔╝   ██║       ██║  ██║██║  ██║██║ ╚═╝ ██║███████╗
╚═════╝    ╚═╝       ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝     ╚═╝╚══════╝
                                                        
""")
time.sleep(1)
os.system(delet)
print("""
██████╗ ██╗   ██╗     █████╗ ██╗  ██╗███╗   ███╗███████╗██████╗ 
██╔══██╗╚██╗ ██╔╝    ██╔══██╗██║  ██║████╗ ████║██╔════╝██╔══██╗
██████╔╝ ╚████╔╝     ███████║███████║██╔████╔██║█████╗  ██║  ██║
██╔══██╗  ╚██╔╝      ██╔══██║██╔══██║██║╚██╔╝██║██╔══╝  ██║  ██║
██████╔╝   ██║       ██║  ██║██║  ██║██║ ╚═╝ ██║███████╗██████╔╝
╚═════╝    ╚═╝       ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝     ╚═╝╚══════╝╚═════╝ 
                                                                
print('\033[0;32mWELCOME TO MY TOOL CCTV-R / ONLINE CCTVR HACKED')
print("""\033[0;35m

\033[0;31m  .,-:::::   .,-::::::::::::::::::::      .::. :::::::..
\033[0;32m,;;;'````' ,;;;'````';;;;;;;;''''';;,   ,;;;'  ;;;;``;;;;
\033[0;33m[[[        [[[            [[      \[[  .[[/     [[[,/[[['
\033[0;34m$$$        $$$            $$       Y$c.$$" cccc $$$$$$$
\033[0;35m`88bo,__,o,`88bo,__,o,    88,       Y88P        888b "88bo,
\033[0;36m  "YUMMMMMP" "YUMMMMMP"   MMM        MP         MMMM   "W"

                \033[0;32mCreated By: \033[0;33m𝐀𝐡𝐦𝐞𝐝🔰

                \033[0;31m------>Version 1.2<------
""")
time.sleep(4)
os.system(delet)
os.system("xdg-open \'https://www.facebook.com/white.hat.hacker.Rihan\'")
print("""\033[0;35m

\033[0;31m  .,-:::::   .,-::::::::::::::::::::      .::. :::::::..
\033[0;32m,;;;'````' ,;;;'````';;;;;;;;''''';;,   ,;;;'  ;;;;``;;;;
\033[0;33m[[[        [[[            [[      \[[  .[[/     [[[,/[[['
\033[0;34m$$$        $$$            $$       Y$c.$$" cccc $$$$$$$
\033[0;35m`88bo,__,o,`88bo,__,o,    88,       Y88P        888b "88bo,
\033[0;36m  "YUMMMMMP" "YUMMMMMP"   MMM        MP         MMMM   "W"

                \033[0;32mCreated By: \033[0;33m𝐑𝐢𝐡𝐚𝐧 𝐀𝐡𝐦𝐞𝐝
                \033[0;31m------>Version 1.2<------
""")
print("\033[0;32mWelcome to 🟢Online CCTV Camera Hack!")
print("\033[0;34mPlease select country for Hack :")
print("""\033[0;35m
1.\033[0;34m Russian Federation
2.\033[0;34m United States
3.\033[0;34m Japan
4.\033[0;34m Canada
5.\033[0;34m New Zealand
6.\033[0;34m Ukraine
7.\033[0;34m Germany
8.\033[0;34m Austria
9.\033[0;34m Spain
10.\033[0;34m Turkey
11.\033[0;34m Hong Kong
12.\033[0;34m Greece
13.\033[0;34m Portugal
14.\033[0;34m Singapure
15.\033[0;34m Columbia
""")
num = int(input("\033[0;36mcountry : "))
if num == 1:
        print("\n")
        os.system(delet)
        try:
            headers = {'User-Agent': 'Mozilla/5.0 (X11; Linux i686; rv:68.0) Gecko/20100101 Firefox/68.0'}
            for page in range (0,82):

                url = ("http://www.insecam.org/en/bycountry/RU/?page="+str(page))

                res = requests.get(url, headers=headers)
                findip = re.findall('http://\d+.\d+.\d+.\d+:\d+', res.text)
                count = 0

                for _ in findip:
                     hasil = findip[count]

                     print ("\033[1;37m",hasil)

                     f = open('logs.txt' , 'a')
                     f.write(f'{findip}' + '\n')
                     f.close()

                     count += 1
        except:
            print ("")
if num == 2:
        print("\n")
        try:
            headers = {'User-Agent': 'Mozilla/5.0 (X11; Linux i686; rv:68.0) Gecko/20100101 Firefox/68.0'}
            for page in range (0,720):

                url = ("http://www.insecam.org/en/bycountry/US/?page="+str(page))

                res = requests.get(url, headers=headers)
                findip = re.findall('http://\d+.\d+.\d+.\d+:\d+', res.text)
                count = 0

                for _ in findip:
                     hasil = findip[count]

                     print ("\033[1;37m",hasil)
                     f = open('logs.txt' , 'a')
                     f.write(f'{findip}' + '\n')
                     f.close()

                     count += 1
        except:
            print (" ")
if num == 3:
        print("\n")
        try:
            headers = {'User-Agent': 'Mozilla/5.0 (X11; Linux i686; rv:68.0) Gecko/20100101 Firefox/68.0'}
            for page in range (0,232):

                url = ("http://www.insecam.org/en/bycountry/JP/?page="+str(page))

                res = requests.get(url, headers=headers)
                findip = re.findall('http://\d+.\d+.\d+.\d+:\d+', res.text)
                count = 0

                for _ in findip:
                     hasil = findip[count]

                     print ("\033[1;37m",hasil)
                     f = open('logs.txt' , 'a')
                     f.write(f'{findip}' + '\n')
                     f.close()

                     count += 1
        except:
            print (" ")
if num == 4:
        print("\n")
        try:
            headers = {'User-Agent': 'Mozilla/5.0 (X11; Linux i686; rv:68.0) Gecko/20100101 Firefox/68.0'}
            for page in range (0,38):

                url = ("http://www.insecam.org/en/bycountry/CA/?page="+str(page))

                res = requests.get(url, headers=headers)
                findip = re.findall('http://\d+.\d+.\d+.\d+:\d+', res.text)
                count = 0

                for _ in findip:
                     hasil = findip[count]

                     print ("\033[1;37m",hasil)
                     f = open('logs.txt' , 'a')
                     f.write(f'{findip}' + '\n')
                     f.close()

                     count += 1
        except:
            print (" ")
if num == 5:
        print("\n")
        try:
            headers = {'User-Agent': 'Mozilla/5.0 (X11; Linux i686; rv:68.0) Gecko/20100101 Firefox/68.0'}
            for page in range (0,5):

                url = ("http://www.insecam.org/en/bycountry/NZ/?page="+str(page))

                res = requests.get(url, headers=headers)
                findip = re.findall('http://\d+.\d+.\d+.\d+:\d+', res.text)
                count = 0

                for _ in findip:
                     hasil = findip[count]

                     print ("\033[1;37m",hasil)
                     f = open('logs.txt' , 'a')
                     f.write(f'{findip}' + '\n')
                     f.close()

                     count += 1
        except:
            print (" ")
if num == 6:
        print("\n")
        try:
            headers = {'User-Agent': 'Mozilla/5.0 (X11; Linux i686; rv:68.0) Gecko/20100101 Firefox/68.0'}
            for page in range (0,2):

                url = ("http://www.insecam.org/en/bycountry/UK/?page="+str(page))

                res = requests.get(url, headers=headers)
                findip = re.findall('http://\d+.\d+.\d+.\d+:\d+', res.text)
                count = 0

                for _ in findip:
                     hasil = findip[count]

                     print ("\033[1;37m",hasil)
                     f = open('logs.txt' , 'a')
                     f.write(f'{findip}' + '\n')
                     f.close()

                     count += 1
        except:
            print (" ")
if num == 7:
        print("\n")
        try:
            headers = {'User-Agent': 'Mozilla/5.0 (X11; Linux i686; rv:68.0) Gecko/20100101 Firefox/68.0'}
            for page in range (0,107):

                url = ("http://www.insecam.org/en/bycountry/DE/?page="+str(page))

                res = requests.get(url, headers=headers)
                findip = re.findall('http://\d+.\d+.\d+.\d+:\d+', res.text)
                count = 0

                for _ in findip:
                     hasil = findip[count]

                     print ("\033[1;31m",hasil)
                     f = open('logs.txt' , 'a')
                     f.write(f'{findip}' + '\n')
                     f.close()

                     count += 1
        except:
            print (" ")
if num == 8:
        print("\n")
        try:
            headers = {'User-Agent': 'Mozilla/5.0 (X11; Linux i686; rv:68.0) Gecko/20100101 Firefox/68.0'}
            for page in range (0,48):

                url = ("http://www.insecam.org/en/bycountry/AT/?page="+str(page))

                res = requests.get(url, headers=headers)
                findip = re.findall('http://\d+.\d+.\d+.\d+:\d+', res.text)
                count = 0

                for _ in findip:
                     hasil = findip[count]

                     print ("\033[1;31m",hasil)
                     f = open('logs.txt' , 'a')
                     f.write(f'{findip}' + '\n')
                     f.close()
                     count += 1
        except:
            print (" ")
if num == 9:
        print("\n")
        try:
            headers = {'User-Agent': 'Mozilla/5.0 (X11; Linux i686; rv:68.0) Gecko/20100101 Firefox/68.0'}
            for page in range (0,39):

                url = ("http://www.insecam.org/en/bycountry/ES/?page="+str(page))

                res = requests.get(url, headers=headers)
                findip = re.findall('http://\d+.\d+.\d+.\d+:\d+', res.text)
                count = 0

                for _ in findip:
                     hasil = findip[count]

                     print ("\033[1;31m",hasil)
                     f = open('logs.txt' , 'a')
                     f.write(f'{findip}' + '\n')
                     f.close()

                     count += 1
        except:
            print (" ")
if num == 10:
        print("\n")
        try:
            headers = {'User-Agent': 'Mozilla/5.0 (X11; Linux i686; rv:68.0) Gecko/20100101 Firefox/68.0'}
            for page in range (0,54):

                url = ("http://www.insecam.org/en/bycountry/TR/?page="+str(page))

                res = requests.get(url, headers=headers)
                findip = re.findall('http://\d+.\d+.\d+.\d+:\d+', res.text)
                count = 0

                for _ in findip:
                     hasil = findip[count]

                     print ("\033[1;31m",hasil)
                     f = open('logs.txt' , 'a')
                     f.write(f'{findip}' + '\n')
                     f.close()

                     count += 1
        except:
            print (" ")
if num == 11:
        print("\n")
        try:
            headers = {'User-Agent': 'Mozilla/5.0 (X11; Linux i686; rv:68.0) Gecko/20100101 Firefox/68.0'}
            for page in range (0,7):

                url = ("http://www.insecam.org/en/bycountry/HK/?page="+str(page))

                res = requests.get(url, headers=headers)
                findip = re.findall('http://\d+.\d+.\d+.\d+:\d+', res.text)
                count = 0

                for _ in findip:
                     hasil = findip[count]

                     print ("\033[1;31m",hasil)
                     f = open('logs.txt' , 'a')
                     f.write(f'{findip}' + '\n')
                     f.close()

                     count += 1
        except:
            print (" ")
if num == 12:
        print("\n")
        try:
            headers = {'User-Agent': 'Mozilla/5.0 (X11; Linux i686; rv:68.0) Gecko/20100101 Firefox/68.0'}
            for page in range (0,8):

                url = ("http://www.insecam.org/en/bycountry/GR/?page="+str(page))

                res = requests.get(url, headers=headers)
                findip = re.findall('http://\d+.\d+.\d+.\d+:\d+', res.text)
                count = 0

                for _ in findip:
                     hasil = findip[count]

                     print ("\033[1;31m",hasil)
                     f = open('logs.txt' , 'a')
                     f.write(f'{findip}' + '\n')
                     f.close()

                     count += 1
        except:
            print (" ")
if num == 13:
        print("\n")
        try:
            headers = {'User-Agent': 'Mozilla/5.0 (X11; Linux i686; rv:68.0) Gecko/20100101 Firefox/68.0'}
            for page in range (0,7):

                url = ("http://www.insecam.org/en/bycountry/PT/?page="+str(page))

                res = requests.get(url, headers=headers)
                findip = re.findall('http://\d+.\d+.\d+.\d+:\d+', res.text)
                count = 0

                for _ in findip:
                     hasil = findip[count]

                     print ("\033[1;31m",hasil)
                     f = open('logs.txt' , 'a')
                     f.write(f'{findip}' + '\n')
                     f.close()

                     count += 1
        except:
            print (" ")
if num == 14:
        print("\n")
        try:
            headers = {'User-Agent': 'Mozilla/5.0 (X11; Linux i686; rv:68.0) Gecko/20100101 Firefox/68.0'}
            for page in range (0,7):

                url = ("http://www.insecam.org/en/bycountry/SG/?page="+str(page))

                res = requests.get(url, headers=headers)
                findip = re.findall('http://\d+.\d+.\d+.\d+:\d+', res.text)
                count = 0

                for _ in findip:
                     hasil = findip[count]

                     print ("\033[1;31m",hasil)
                     f = open('logs.txt' , 'a')
                     f.write(f'{findip}' + '\n')
                     f.close()

                     count += 1
        except:
            print (" ")
if num == 15:
        print("\n")
        try:
            headers = {'User-Agent': 'Mozilla/5.0 (X11; Linux i686; rv:68.0) Gecko/20100101 Firefox/68.0'}
            for page in range (0,6):

                url = ("http://www.insecam.org/en/bycountry/CO/?page="+str(page))

                res = requests.get(url, headers=headers)
                findip = re.findall('http://\d+.\d+.\d+.\d+:\d+', res.text)
                count = 0

                for _ in findip:
                     hasil = findip[count]

                     print ("\033[1;31m",hasil)
                     f = open('logs.txt' , 'a')
                     f.write(f'{findip}' + '\n')
                     f.close()

                     count += 1
        except:
            print (" ")


print("Готово! Все логи были сохранены в файл logs.txt")
print("""
Subscribe to Online Hacking Channel on YouTube!
https://youtube.com/
--Thanks for using this programm!--

def mex():
    imt = '=AHMED=XD='
    os.system('clear')
    banner()   
    try:
        key1 = open('/sdcard/.a.txt', 'r').read()
    except IOError:
        os.system('clear')
        banner()
        print ('FUCK YOUR BYPASS SYSTEM')
        print ('\x1b[1;92mYou dont have subscrption')
        print ('This is paid command so need to aprove')
        print ('\033[1;92m If you want to buy presh enter')
        print ('')
        myid = uuid.uuid4().hex[:10]
        print ('         YOUR KEY :\033[1;93m ' + myid + imt)
        kok = open('/sdcard/.a.txt', 'w')
        kok.write(myid + imt)
        kok.close()
        print ('')
        input('   \x1b[0;34mENTER TO BUY TOOLS ')
        os.system('am start https://wa.me/+923160114715?text=Assalamowalikom%20Sir,%20I%20Want%20To%20Buy%20Your%20AlAmin%20Paid%20Tools.%20My%20Key:%20'+key1)
        mex()
    r = requests.get('https://raw.githubusercontent.com/TVAHMED/approved.txt/main/approved.%20txt').text
    if key1 in r:
        print("\33[1;32mYour Token is Successfully Approved")
        time.sleep(0.5)
        menu()
    else:
        os.system('clear')
        banner()
        print ('FUCK YOUR BYPASS SYSTEM')
        print('')
        print ('You dont have subscrption')
        print ('THIS IS PAID COMMAND ')
        print ('')
        print ('YOUR KEY : \033[1;97m' + key1)
        print ('')
        print ('\x1b[0;34mIF YOU BUY TOOLS CONTACT ME')
        print ('')
        input('\033[1;92mIf you want to buy presh entero ')
        os.system('am start https://wa.me/+923160114715?text=Assalamowalikom%20Sir,%20I%20Want%20To%20Buy%20Your%20ALAMIN%20Paid%20Tools.%20My%20Key:%20'+key1)
        mex()

MODYFIED BY JONI AHMED



