# Sc Make By Asraful Islam Hasan
#Gift By Hasan


import time
import requests
import bs4
import json
import os
import sys
import random
import datetime
import time
import re
from bs4 import BeautifulSoup as irfan
land = '23860'
hars = '703036'

def irfanx(z):
    for e in z + '\n':
        sys.stdout.write(e)
        sys.stdout.flush()
        time.sleep(0.0008)

os.system('clear')
print(f""" 
  \033[1;92m██   ██  █████  ███████  █████  ███    ██ 
  \033[1;92m██   ██ ██   ██ ██      ██   ██ ████   ██ 
  \033[1;92m███████ ███████ ███████ ███████ ██ ██  ██ 
  \033[1;92m██   ██ ██   ██      ██ ██   ██ ██  ██ ██ 
  \033[1;92m██   ██ ██   ██ ███████ ██   ██ ██   ████ 
         
 \033[1;93m×××××××××××××××××××××××××××××××××××××××××××××××××
 \033[1;93m|     \033[1;96m[✓] CREATED BY\33[0;m   :  \033[1;96mASRAFUL ISLAM HASAN   \033[1;93m|
 \033[1;93m|     \033[1;32m[✓] FACEBOK      : \033[1;34m Hasa N                \033[1;93m|
 \033[1;93m|     \033[1;35m[✓] GITHUB       :  \033[1;35mKgHasan               \033[1;93m|
 \033[1;93m|     \033[1;36m[✓] TOOL STATUS  : \033[1;36m Auto Cookie           \033[1;93m|
 \033[1;93m|     \033[1;35m[✓] TEAM         :  \033[1;35mKST                   \033[1;93m|
 \033[1;93m|     \033[1;36m[✓] TOOL VIRSION :  \033[1;36m0.0                   \033[1;93m|
 \033[1;93m×××××××××××××××××××××××××××××××××××××××××××××××××
 \033[1;91m[\033[1;97m•\033[1;91m]\033[1;32m PLZ SAPPORT ME BRO....
 \033[1;91m[\033[1;97m•\033[1;91m]\033[1;32m HASAN TERMUX HELPING ZONE....
 \033[1;93m××××××××××××××××\033[1;93m×××××××××××××××\033[1;93m×××××××××××××××××
   \033[1;91m<===>\033[1;41m\033[1;97m Auto Cookie Tools Creact By HASAN\033[;0m\033[1;91m<===>\033[1;92m""")
print(' \033[1;93m×××××××××××××××××××××××××××××××××××××××××××××××××')
print('       \033[38;5;195mJOIN MY HASAN SCRIPT AND ID GIFT ZONE')
print(' \033[1;93m×××××××××××××××××××××××××××××××××××××××××××××××××')
x = input('                  \033[38;5;46m Typ Entar')
os.system('xdg-open https://facebook.com/groups/920428789151086/')
time.sleep(0.7)
print(' \033[1;93m×××××××××××××××××××××××××××××××××××××××××××××××××')
print ('         \033[38;5;195mJOIN MY HASAN TERMUX HALPING ZONE')
print(' \033[1;93m×××××××××××××××××××××××××××××××××××××××××××××××××')
x = input('                  \033[38;5;46m Typ Entar')
time.sleep(0.5)
os.system('xdg-open https://facebook.com/groups/551365756758487/')
print(' \033[38;5;45m×××××××××××××××××××××××××××××××××××××××××××××××××')
print('                    \033[38;5;196m! \033[38;5;192mNOTE \033[38;5;196m!                \n                \033[38;5;46mAssalamu Alaikum \n  \033[38;5;192mThis cookies script is only created to create \n     file cloning files that require cookies.\n   Do not take cookies other than file creation')
print(' \033[38;5;45m×××××××××××××××××××××××××××××××××××××××××××××××××')
x = input('               \033[38;5;46m Press The Entar')

print(' \033[1;93m×××××××××××××××××××××××××××××××××××××××××××××××××')
x = input(' \033[38;5;196m[\033[38;5;195m1\033[38;5;196m]\033[38;5;46m Auto Cookie \033[38;5;196m[\033[38;5;195mV1\033[38;5;196m] \n \033[38;5;196m[\033[38;5;195m2\033[38;5;196m]\033[38;5;46m Auto Cookie \033[38;5;196m[\033[38;5;195mV2\033[38;5;196m] \n \033[38;5;196m[\033[38;5;195m3\033[38;5;196m]\033[38;5;46m Auto Cookie \033[38;5;196m[\033[38;5;195mV3\033[38;5;196m] \n \033[1;93m××××××××××××××××××××××××××××××××××××××××××××××××× \n \033[38;5;196m[\033[38;5;195m•\033[38;5;196m]\033[38;5;45m Choose : ')
print(' \033[1;93m×××××××××××××××××××××××××××××××××××××××××××××××××')
ses = requests.Session()
url = irfan(ses.get(f'''https://www.facebook.com/100032386028880/posts/pfbid028x4o9HTdDJfPXKiH52a9aXJjz8iz8oXMSKRL1io3X2A5vhVDKdYmx4ofBrDTMWEsl/?app=fbl''').text, 'html.parser')
data = re.findall('"text":"(.*?)"', str(url))
n = 0
for O in data:
    time.sleep(1)
    n += 1
ses = requests.Session()
url = irfan(ses.get(f'''https://www.facebook.com/103400442502880/posts/pfbid0P9xr9u7CVLBZyoYKNF7qicivUchGDzfceL5SamHx7LWTaGQFBnqRoQW5xrAHzAHRl/?app=fbl''').text, 'html.parser')
data = re.findall('"text":"(.*?)"', str(url))
n = 0
for O in data:
    time.sleep(1)
    n += 2
ses = requests.Session()
url = irfan(ses.get(f'''https://www.facebook.com/100068286986970/posts/pfbid027j6VRFYqqSXtrPqtLJbfpVsPfxP69gNbA1Pg3yCmnfDg9EJ9NosZSgNJfYCMvWEFl/?app=fbl''').text, 'html.parser')
data = re.findall('"text":"(.*?)"', str(url))
n = 0
for O in data:
    time.sleep(1)
    n += 3
    irfanx(f'''\x1b[1;91m \033[38;5;196m[\033[38;5;195m{n}\033[38;5;196m] \033[38;5;196m[\033[38;5;45mHASAN_COOKIES\033[38;5;196m] \033[38;5;195m: \033[38;5;46m''' + O)
    print()
    x = input(' \033[1;93m××××××××××××××××××××××××××××××××××××××××××××××××× \n \033[1;91m<===>\033[1;41m\033[1;97m Cookie Copy Koro And Try Koro \033[;0m\033[1;91m<===>\033[1;92m\n \033[1;93m×××××××××××××××××××××××××××××××××××××××××××××××××\n \033[38;5;196m[\033[38;5;45m•\033[38;5;196m]\033[38;5;45m Choose : \033[38;5;46m')
    print()
